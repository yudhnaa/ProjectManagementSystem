﻿namespace PresentationLayer.CustomControls
{
    partial class CtrlCreateProject
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            Bunifu.UI.WinForms.BunifuButton.BunifuButton2.BorderEdges borderEdges1 = new Bunifu.UI.WinForms.BunifuButton.BunifuButton2.BorderEdges();
            Bunifu.UI.WinForms.BunifuButton.BunifuButton2.BorderEdges borderEdges2 = new Bunifu.UI.WinForms.BunifuButton.BunifuButton2.BorderEdges();
            Bunifu.UI.WinForms.BunifuButton.BunifuButton2.BorderEdges borderEdges3 = new Bunifu.UI.WinForms.BunifuButton.BunifuButton2.BorderEdges();
            Bunifu.UI.WinForms.BunifuButton.BunifuButton2.BorderEdges borderEdges4 = new Bunifu.UI.WinForms.BunifuButton.BunifuButton2.BorderEdges();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(CtrlCreateProject));
            Bunifu.UI.WinForms.BunifuTextBox.StateProperties stateProperties1 = new Bunifu.UI.WinForms.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextBox.StateProperties stateProperties2 = new Bunifu.UI.WinForms.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextBox.StateProperties stateProperties3 = new Bunifu.UI.WinForms.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextBox.StateProperties stateProperties4 = new Bunifu.UI.WinForms.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextBox.StateProperties stateProperties5 = new Bunifu.UI.WinForms.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextBox.StateProperties stateProperties6 = new Bunifu.UI.WinForms.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextBox.StateProperties stateProperties7 = new Bunifu.UI.WinForms.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextBox.StateProperties stateProperties8 = new Bunifu.UI.WinForms.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextBox.StateProperties stateProperties9 = new Bunifu.UI.WinForms.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextBox.StateProperties stateProperties10 = new Bunifu.UI.WinForms.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextBox.StateProperties stateProperties11 = new Bunifu.UI.WinForms.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextBox.StateProperties stateProperties12 = new Bunifu.UI.WinForms.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextBox.StateProperties stateProperties13 = new Bunifu.UI.WinForms.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextBox.StateProperties stateProperties14 = new Bunifu.UI.WinForms.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextBox.StateProperties stateProperties15 = new Bunifu.UI.WinForms.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextBox.StateProperties stateProperties16 = new Bunifu.UI.WinForms.BunifuTextBox.StateProperties();
            this.cbRole = new System.Windows.Forms.ComboBox();
            this.listviewMembers = new System.Windows.Forms.ListView();
            this.id = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.name = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.role = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.cbMember = new System.Windows.Forms.ComboBox();
            this.cbStatus = new System.Windows.Forms.ComboBox();
            this.datePickerEnd = new Bunifu.UI.WinForms.BunifuDatePicker();
            this.bunifuCustomLabel9 = new Bunifu.Framework.UI.BunifuCustomLabel();
            this.datePickerStart = new Bunifu.UI.WinForms.BunifuDatePicker();
            this.bunifuCustomLabel8 = new Bunifu.Framework.UI.BunifuCustomLabel();
            this.bunifuCustomLabel7 = new Bunifu.Framework.UI.BunifuCustomLabel();
            this.btCreateProject = new Bunifu.UI.WinForms.BunifuButton.BunifuButton2();
            this.btCancelProject = new Bunifu.UI.WinForms.BunifuButton.BunifuButton2();
            this.bunifuCustomLabel11 = new Bunifu.Framework.UI.BunifuCustomLabel();
            this.flowLayoutPanel1 = new System.Windows.Forms.FlowLayoutPanel();
            this.btnAddMember = new Bunifu.UI.WinForms.BunifuButton.BunifuButton2();
            this.bunifuButton21 = new Bunifu.UI.WinForms.BunifuButton.BunifuButton2();
            this.bunifuCustomLabel5 = new Bunifu.Framework.UI.BunifuCustomLabel();
            this.bunifuCustomLabel2 = new Bunifu.Framework.UI.BunifuCustomLabel();
            this.tbProjectName = new Bunifu.UI.WinForms.BunifuTextBox();
            this.tbProjectCode = new Bunifu.UI.WinForms.BunifuTextBox();
            this.bunifuCustomLabel3 = new Bunifu.Framework.UI.BunifuCustomLabel();
            this.bunifuCustomLabel4 = new Bunifu.Framework.UI.BunifuCustomLabel();
            this.tbBudget = new Bunifu.UI.WinForms.BunifuTextBox();
            this.cbPriority = new System.Windows.Forms.ComboBox();
            this.bunifuCustomLabel10 = new Bunifu.Framework.UI.BunifuCustomLabel();
            this.tbProjectDesrciption = new Bunifu.UI.WinForms.BunifuTextBox();
            this.bunifuCustomLabel1 = new Bunifu.Framework.UI.BunifuCustomLabel();
            this.bunifuCustomLabel6 = new Bunifu.Framework.UI.BunifuCustomLabel();
            this.tableLayoutPanel1 = new System.Windows.Forms.TableLayoutPanel();
            this.flowLayoutPanel1.SuspendLayout();
            this.tableLayoutPanel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // cbRole
            // 
            this.cbRole.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.cbRole.FormattingEnabled = true;
            this.cbRole.Location = new System.Drawing.Point(622, 172);
            this.cbRole.Margin = new System.Windows.Forms.Padding(10);
            this.cbRole.Name = "cbRole";
            this.cbRole.Size = new System.Drawing.Size(196, 46);
            this.cbRole.TabIndex = 13;
            // 
            // listviewMembers
            // 
            this.listviewMembers.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.listviewMembers.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.id,
            this.name,
            this.role});
            this.tableLayoutPanel1.SetColumnSpan(this.listviewMembers, 2);
            this.listviewMembers.HideSelection = false;
            this.listviewMembers.Location = new System.Drawing.Point(418, 272);
            this.listviewMembers.Margin = new System.Windows.Forms.Padding(10);
            this.listviewMembers.Name = "listviewMembers";
            this.tableLayoutPanel1.SetRowSpan(this.listviewMembers, 3);
            this.listviewMembers.Size = new System.Drawing.Size(404, 284);
            this.listviewMembers.TabIndex = 12;
            this.listviewMembers.UseCompatibleStateImageBehavior = false;
            this.listviewMembers.View = System.Windows.Forms.View.Details;
            // 
            // id
            // 
            this.id.Text = "ID";
            this.id.Width = 123;
            // 
            // name
            // 
            this.name.Text = "Name";
            this.name.Width = 137;
            // 
            // role
            // 
            this.role.Text = "Role";
            this.role.Width = 136;
            // 
            // cbMember
            // 
            this.cbMember.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.cbMember.FormattingEnabled = true;
            this.cbMember.Location = new System.Drawing.Point(418, 172);
            this.cbMember.Margin = new System.Windows.Forms.Padding(10);
            this.cbMember.Name = "cbMember";
            this.cbMember.Size = new System.Drawing.Size(184, 46);
            this.cbMember.TabIndex = 13;
            this.cbMember.TextChanged += new System.EventHandler(this.cbMember_TextChanged);
            // 
            // cbStatus
            // 
            this.cbStatus.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.cbStatus.FormattingEnabled = true;
            this.cbStatus.Location = new System.Drawing.Point(219, 172);
            this.cbStatus.Margin = new System.Windows.Forms.Padding(10);
            this.cbStatus.Name = "cbStatus";
            this.cbStatus.Size = new System.Drawing.Size(151, 46);
            this.cbStatus.TabIndex = 13;
            // 
            // datePickerEnd
            // 
            this.datePickerEnd.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.datePickerEnd.BackColor = System.Drawing.Color.White;
            this.datePickerEnd.BorderColor = System.Drawing.Color.Silver;
            this.datePickerEnd.BorderRadius = 17;
            this.datePickerEnd.CalendarFont = new System.Drawing.Font("Segoe UI", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.datePickerEnd.CausesValidation = false;
            this.datePickerEnd.Color = System.Drawing.Color.Silver;
            this.datePickerEnd.CustomFormat = "DD/MM/YYYY";
            this.datePickerEnd.DateBorderThickness = Bunifu.UI.WinForms.BunifuDatePicker.BorderThickness.Thin;
            this.datePickerEnd.DateTextAlign = Bunifu.UI.WinForms.BunifuDatePicker.TextAlign.Left;
            this.datePickerEnd.DisabledColor = System.Drawing.Color.Gray;
            this.datePickerEnd.DisplayWeekNumbers = false;
            this.datePickerEnd.DPHeight = 0;
            this.datePickerEnd.DropDownAlign = System.Windows.Forms.LeftRightAlignment.Right;
            this.datePickerEnd.FillDatePicker = false;
            this.datePickerEnd.Font = new System.Drawing.Font("Segoe UI", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.datePickerEnd.ForeColor = System.Drawing.Color.Black;
            this.datePickerEnd.Icon = ((System.Drawing.Image)(resources.GetObject("datePickerEnd.Icon")));
            this.datePickerEnd.IconColor = System.Drawing.Color.Gray;
            this.datePickerEnd.IconLocation = Bunifu.UI.WinForms.BunifuDatePicker.Indicator.Right;
            this.datePickerEnd.LeftTextMargin = 5;
            this.datePickerEnd.Location = new System.Drawing.Point(622, 55);
            this.datePickerEnd.Margin = new System.Windows.Forms.Padding(10);
            this.datePickerEnd.MinimumSize = new System.Drawing.Size(0, 32);
            this.datePickerEnd.Name = "datePickerEnd";
            this.datePickerEnd.Size = new System.Drawing.Size(200, 42);
            this.datePickerEnd.TabIndex = 3;
            this.datePickerEnd.Value = new System.DateTime(2025, 4, 9, 21, 27, 0, 0);
            // 
            // bunifuCustomLabel9
            // 
            this.bunifuCustomLabel9.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.bunifuCustomLabel9.AutoSize = true;
            this.bunifuCustomLabel9.BackColor = System.Drawing.Color.Transparent;
            this.bunifuCustomLabel9.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuCustomLabel9.Location = new System.Drawing.Point(622, 118);
            this.bunifuCustomLabel9.Margin = new System.Windows.Forms.Padding(10);
            this.bunifuCustomLabel9.Name = "bunifuCustomLabel9";
            this.bunifuCustomLabel9.Size = new System.Drawing.Size(55, 25);
            this.bunifuCustomLabel9.TabIndex = 2;
            this.bunifuCustomLabel9.Text = "Role";
            this.bunifuCustomLabel9.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // datePickerStart
            // 
            this.datePickerStart.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.datePickerStart.BackColor = System.Drawing.Color.White;
            this.datePickerStart.BorderColor = System.Drawing.Color.Silver;
            this.datePickerStart.BorderRadius = 17;
            this.datePickerStart.CalendarFont = new System.Drawing.Font("Segoe UI", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.datePickerStart.Color = System.Drawing.Color.Silver;
            this.datePickerStart.DateBorderThickness = Bunifu.UI.WinForms.BunifuDatePicker.BorderThickness.Thin;
            this.datePickerStart.DateTextAlign = Bunifu.UI.WinForms.BunifuDatePicker.TextAlign.Left;
            this.datePickerStart.DisabledColor = System.Drawing.Color.Gray;
            this.datePickerStart.DisplayWeekNumbers = false;
            this.datePickerStart.DPHeight = 0;
            this.datePickerStart.DropDownAlign = System.Windows.Forms.LeftRightAlignment.Right;
            this.datePickerStart.FillDatePicker = false;
            this.datePickerStart.Font = new System.Drawing.Font("Segoe UI", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.datePickerStart.ForeColor = System.Drawing.Color.Black;
            this.datePickerStart.Icon = ((System.Drawing.Image)(resources.GetObject("datePickerStart.Icon")));
            this.datePickerStart.IconColor = System.Drawing.Color.Gray;
            this.datePickerStart.IconLocation = Bunifu.UI.WinForms.BunifuDatePicker.Indicator.Right;
            this.datePickerStart.LeftTextMargin = 5;
            this.datePickerStart.Location = new System.Drawing.Point(418, 55);
            this.datePickerStart.Margin = new System.Windows.Forms.Padding(10);
            this.datePickerStart.MinimumSize = new System.Drawing.Size(0, 32);
            this.datePickerStart.Name = "datePickerStart";
            this.datePickerStart.Size = new System.Drawing.Size(170, 42);
            this.datePickerStart.TabIndex = 3;
            this.datePickerStart.Value = new System.DateTime(2025, 4, 9, 21, 27, 0, 0);
            // 
            // bunifuCustomLabel8
            // 
            this.bunifuCustomLabel8.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.bunifuCustomLabel8.AutoSize = true;
            this.bunifuCustomLabel8.BackColor = System.Drawing.Color.Transparent;
            this.bunifuCustomLabel8.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuCustomLabel8.Location = new System.Drawing.Point(418, 118);
            this.bunifuCustomLabel8.Margin = new System.Windows.Forms.Padding(10);
            this.bunifuCustomLabel8.Name = "bunifuCustomLabel8";
            this.bunifuCustomLabel8.Size = new System.Drawing.Size(90, 25);
            this.bunifuCustomLabel8.TabIndex = 2;
            this.bunifuCustomLabel8.Text = "Member";
            this.bunifuCustomLabel8.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // bunifuCustomLabel7
            // 
            this.bunifuCustomLabel7.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.bunifuCustomLabel7.AutoSize = true;
            this.bunifuCustomLabel7.BackColor = System.Drawing.Color.Transparent;
            this.bunifuCustomLabel7.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuCustomLabel7.Location = new System.Drawing.Point(192, 118);
            this.bunifuCustomLabel7.Margin = new System.Windows.Forms.Padding(10);
            this.bunifuCustomLabel7.Name = "bunifuCustomLabel7";
            this.bunifuCustomLabel7.Size = new System.Drawing.Size(74, 25);
            this.bunifuCustomLabel7.TabIndex = 2;
            this.bunifuCustomLabel7.Text = "Status";
            this.bunifuCustomLabel7.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // btCreateProject
            // 
            this.btCreateProject.AllowAnimations = true;
            this.btCreateProject.AllowMouseEffects = true;
            this.btCreateProject.AllowToggling = false;
            this.btCreateProject.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.btCreateProject.AnimationSpeed = 200;
            this.btCreateProject.AutoGenerateColors = false;
            this.btCreateProject.AutoRoundBorders = false;
            this.btCreateProject.AutoSizeLeftIcon = true;
            this.btCreateProject.AutoSizeRightIcon = true;
            this.btCreateProject.BackColor = System.Drawing.Color.Transparent;
            this.btCreateProject.BackColor1 = System.Drawing.Color.DodgerBlue;
            this.btCreateProject.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btCreateProject.BackgroundImage")));
            this.btCreateProject.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton2.BorderStyles.Solid;
            this.btCreateProject.ButtonText = "Create";
            this.btCreateProject.ButtonTextMarginLeft = 0;
            this.btCreateProject.ColorContrastOnClick = 45;
            this.btCreateProject.ColorContrastOnHover = 45;
            this.btCreateProject.Cursor = System.Windows.Forms.Cursors.Default;
            borderEdges1.BottomLeft = true;
            borderEdges1.BottomRight = true;
            borderEdges1.TopLeft = true;
            borderEdges1.TopRight = true;
            this.btCreateProject.CustomizableEdges = borderEdges1;
            this.btCreateProject.DialogResult = System.Windows.Forms.DialogResult.None;
            this.btCreateProject.DisabledBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(191)))), ((int)(((byte)(191)))), ((int)(((byte)(191)))));
            this.btCreateProject.DisabledFillColor = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(204)))), ((int)(((byte)(204)))));
            this.btCreateProject.DisabledForecolor = System.Drawing.Color.FromArgb(((int)(((byte)(168)))), ((int)(((byte)(160)))), ((int)(((byte)(168)))));
            this.btCreateProject.FocusState = Bunifu.UI.WinForms.BunifuButton.BunifuButton2.ButtonStates.Pressed;
            this.btCreateProject.Font = new System.Drawing.Font("Segoe UI", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btCreateProject.ForeColor = System.Drawing.Color.White;
            this.btCreateProject.IconLeftAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btCreateProject.IconLeftCursor = System.Windows.Forms.Cursors.Default;
            this.btCreateProject.IconLeftPadding = new System.Windows.Forms.Padding(11, 3, 3, 3);
            this.btCreateProject.IconMarginLeft = 11;
            this.btCreateProject.IconPadding = 10;
            this.btCreateProject.IconRightAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btCreateProject.IconRightCursor = System.Windows.Forms.Cursors.Default;
            this.btCreateProject.IconRightPadding = new System.Windows.Forms.Padding(3, 3, 7, 3);
            this.btCreateProject.IconSize = 25;
            this.btCreateProject.IdleBorderColor = System.Drawing.Color.DodgerBlue;
            this.btCreateProject.IdleBorderRadius = 40;
            this.btCreateProject.IdleBorderThickness = 1;
            this.btCreateProject.IdleFillColor = System.Drawing.Color.DodgerBlue;
            this.btCreateProject.IdleIconLeftImage = null;
            this.btCreateProject.IdleIconRightImage = null;
            this.btCreateProject.IndicateFocus = false;
            this.btCreateProject.Location = new System.Drawing.Point(435, 638);
            this.btCreateProject.Margin = new System.Windows.Forms.Padding(10);
            this.btCreateProject.Name = "btCreateProject";
            this.btCreateProject.OnDisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(191)))), ((int)(((byte)(191)))), ((int)(((byte)(191)))));
            this.btCreateProject.OnDisabledState.BorderRadius = 40;
            this.btCreateProject.OnDisabledState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton2.BorderStyles.Solid;
            this.btCreateProject.OnDisabledState.BorderThickness = 1;
            this.btCreateProject.OnDisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(204)))), ((int)(((byte)(204)))));
            this.btCreateProject.OnDisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(168)))), ((int)(((byte)(160)))), ((int)(((byte)(168)))));
            this.btCreateProject.OnDisabledState.IconLeftImage = null;
            this.btCreateProject.OnDisabledState.IconRightImage = null;
            this.btCreateProject.onHoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(105)))), ((int)(((byte)(181)))), ((int)(((byte)(255)))));
            this.btCreateProject.onHoverState.BorderRadius = 40;
            this.btCreateProject.onHoverState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton2.BorderStyles.Solid;
            this.btCreateProject.onHoverState.BorderThickness = 1;
            this.btCreateProject.onHoverState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(105)))), ((int)(((byte)(181)))), ((int)(((byte)(255)))));
            this.btCreateProject.onHoverState.ForeColor = System.Drawing.Color.White;
            this.btCreateProject.onHoverState.IconLeftImage = null;
            this.btCreateProject.onHoverState.IconRightImage = null;
            this.btCreateProject.OnIdleState.BorderColor = System.Drawing.Color.DodgerBlue;
            this.btCreateProject.OnIdleState.BorderRadius = 40;
            this.btCreateProject.OnIdleState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton2.BorderStyles.Solid;
            this.btCreateProject.OnIdleState.BorderThickness = 1;
            this.btCreateProject.OnIdleState.FillColor = System.Drawing.Color.DodgerBlue;
            this.btCreateProject.OnIdleState.ForeColor = System.Drawing.Color.White;
            this.btCreateProject.OnIdleState.IconLeftImage = null;
            this.btCreateProject.OnIdleState.IconRightImage = null;
            this.btCreateProject.OnPressedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(96)))), ((int)(((byte)(144)))));
            this.btCreateProject.OnPressedState.BorderRadius = 40;
            this.btCreateProject.OnPressedState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton2.BorderStyles.Solid;
            this.btCreateProject.OnPressedState.BorderThickness = 1;
            this.btCreateProject.OnPressedState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(96)))), ((int)(((byte)(144)))));
            this.btCreateProject.OnPressedState.ForeColor = System.Drawing.Color.White;
            this.btCreateProject.OnPressedState.IconLeftImage = null;
            this.btCreateProject.OnPressedState.IconRightImage = null;
            this.btCreateProject.Size = new System.Drawing.Size(150, 39);
            this.btCreateProject.TabIndex = 19;
            this.btCreateProject.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.btCreateProject.TextAlignment = System.Windows.Forms.HorizontalAlignment.Center;
            this.btCreateProject.TextMarginLeft = 0;
            this.btCreateProject.TextPadding = new System.Windows.Forms.Padding(0);
            this.btCreateProject.UseDefaultRadiusAndThickness = true;
            this.btCreateProject.Click += new System.EventHandler(this.btCreateProject_Click);
            // 
            // btCancelProject
            // 
            this.btCancelProject.AllowAnimations = true;
            this.btCancelProject.AllowMouseEffects = true;
            this.btCancelProject.AllowToggling = false;
            this.btCancelProject.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.btCancelProject.AnimationSpeed = 200;
            this.btCancelProject.AutoGenerateColors = false;
            this.btCancelProject.AutoRoundBorders = false;
            this.btCancelProject.AutoSizeLeftIcon = true;
            this.btCancelProject.AutoSizeRightIcon = true;
            this.btCancelProject.BackColor = System.Drawing.Color.Transparent;
            this.btCancelProject.BackColor1 = System.Drawing.Color.Gainsboro;
            this.btCancelProject.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btCancelProject.BackgroundImage")));
            this.btCancelProject.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton2.BorderStyles.Solid;
            this.btCancelProject.ButtonText = "Cancel";
            this.btCancelProject.ButtonTextMarginLeft = 0;
            this.btCancelProject.ColorContrastOnClick = 45;
            this.btCancelProject.ColorContrastOnHover = 45;
            this.btCancelProject.Cursor = System.Windows.Forms.Cursors.Default;
            borderEdges2.BottomLeft = true;
            borderEdges2.BottomRight = true;
            borderEdges2.TopLeft = true;
            borderEdges2.TopRight = true;
            this.btCancelProject.CustomizableEdges = borderEdges2;
            this.btCancelProject.DialogResult = System.Windows.Forms.DialogResult.None;
            this.btCancelProject.DisabledBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(191)))), ((int)(((byte)(191)))), ((int)(((byte)(191)))));
            this.btCancelProject.DisabledFillColor = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(204)))), ((int)(((byte)(204)))));
            this.btCancelProject.DisabledForecolor = System.Drawing.Color.FromArgb(((int)(((byte)(168)))), ((int)(((byte)(160)))), ((int)(((byte)(168)))));
            this.btCancelProject.FocusState = Bunifu.UI.WinForms.BunifuButton.BunifuButton2.ButtonStates.Pressed;
            this.btCancelProject.Font = new System.Drawing.Font("Segoe UI", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btCancelProject.ForeColor = System.Drawing.Color.DodgerBlue;
            this.btCancelProject.IconLeftAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btCancelProject.IconLeftCursor = System.Windows.Forms.Cursors.Default;
            this.btCancelProject.IconLeftPadding = new System.Windows.Forms.Padding(11, 3, 3, 3);
            this.btCancelProject.IconMarginLeft = 11;
            this.btCancelProject.IconPadding = 10;
            this.btCancelProject.IconRightAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btCancelProject.IconRightCursor = System.Windows.Forms.Cursors.Default;
            this.btCancelProject.IconRightPadding = new System.Windows.Forms.Padding(3, 3, 7, 3);
            this.btCancelProject.IconSize = 25;
            this.btCancelProject.IdleBorderColor = System.Drawing.Color.Gainsboro;
            this.btCancelProject.IdleBorderRadius = 40;
            this.btCancelProject.IdleBorderThickness = 1;
            this.btCancelProject.IdleFillColor = System.Drawing.Color.Gainsboro;
            this.btCancelProject.IdleIconLeftImage = null;
            this.btCancelProject.IdleIconRightImage = null;
            this.btCancelProject.IndicateFocus = false;
            this.btCancelProject.Location = new System.Drawing.Point(622, 638);
            this.btCancelProject.Margin = new System.Windows.Forms.Padding(10);
            this.btCancelProject.Name = "btCancelProject";
            this.btCancelProject.OnDisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(191)))), ((int)(((byte)(191)))), ((int)(((byte)(191)))));
            this.btCancelProject.OnDisabledState.BorderRadius = 40;
            this.btCancelProject.OnDisabledState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton2.BorderStyles.Solid;
            this.btCancelProject.OnDisabledState.BorderThickness = 1;
            this.btCancelProject.OnDisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(204)))), ((int)(((byte)(204)))));
            this.btCancelProject.OnDisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(168)))), ((int)(((byte)(160)))), ((int)(((byte)(168)))));
            this.btCancelProject.OnDisabledState.IconLeftImage = null;
            this.btCancelProject.OnDisabledState.IconRightImage = null;
            this.btCancelProject.onHoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(105)))), ((int)(((byte)(181)))), ((int)(((byte)(255)))));
            this.btCancelProject.onHoverState.BorderRadius = 40;
            this.btCancelProject.onHoverState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton2.BorderStyles.Solid;
            this.btCancelProject.onHoverState.BorderThickness = 1;
            this.btCancelProject.onHoverState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(105)))), ((int)(((byte)(181)))), ((int)(((byte)(255)))));
            this.btCancelProject.onHoverState.ForeColor = System.Drawing.Color.White;
            this.btCancelProject.onHoverState.IconLeftImage = null;
            this.btCancelProject.onHoverState.IconRightImage = null;
            this.btCancelProject.OnIdleState.BorderColor = System.Drawing.Color.Gainsboro;
            this.btCancelProject.OnIdleState.BorderRadius = 40;
            this.btCancelProject.OnIdleState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton2.BorderStyles.Solid;
            this.btCancelProject.OnIdleState.BorderThickness = 1;
            this.btCancelProject.OnIdleState.FillColor = System.Drawing.Color.Gainsboro;
            this.btCancelProject.OnIdleState.ForeColor = System.Drawing.Color.DodgerBlue;
            this.btCancelProject.OnIdleState.IconLeftImage = null;
            this.btCancelProject.OnIdleState.IconRightImage = null;
            this.btCancelProject.OnPressedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(96)))), ((int)(((byte)(144)))));
            this.btCancelProject.OnPressedState.BorderRadius = 40;
            this.btCancelProject.OnPressedState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton2.BorderStyles.Solid;
            this.btCancelProject.OnPressedState.BorderThickness = 1;
            this.btCancelProject.OnPressedState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(96)))), ((int)(((byte)(144)))));
            this.btCancelProject.OnPressedState.ForeColor = System.Drawing.Color.White;
            this.btCancelProject.OnPressedState.IconLeftImage = null;
            this.btCancelProject.OnPressedState.IconRightImage = null;
            this.btCancelProject.Size = new System.Drawing.Size(150, 39);
            this.btCancelProject.TabIndex = 21;
            this.btCancelProject.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.btCancelProject.TextAlignment = System.Windows.Forms.HorizontalAlignment.Center;
            this.btCancelProject.TextMarginLeft = 0;
            this.btCancelProject.TextPadding = new System.Windows.Forms.Padding(0);
            this.btCancelProject.UseDefaultRadiusAndThickness = true;
            this.btCancelProject.Click += new System.EventHandler(this.btCancelProject_Click);
            // 
            // bunifuCustomLabel11
            // 
            this.bunifuCustomLabel11.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.bunifuCustomLabel11.AutoSize = true;
            this.bunifuCustomLabel11.BackColor = System.Drawing.Color.Transparent;
            this.bunifuCustomLabel11.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuCustomLabel11.Location = new System.Drawing.Point(418, 226);
            this.bunifuCustomLabel11.Margin = new System.Windows.Forms.Padding(10);
            this.bunifuCustomLabel11.Name = "bunifuCustomLabel11";
            this.bunifuCustomLabel11.Size = new System.Drawing.Size(141, 25);
            this.bunifuCustomLabel11.TabIndex = 2;
            this.bunifuCustomLabel11.Text = "Members List";
            this.bunifuCustomLabel11.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // flowLayoutPanel1
            // 
            this.flowLayoutPanel1.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.flowLayoutPanel1.Controls.Add(this.btnAddMember);
            this.flowLayoutPanel1.Controls.Add(this.bunifuButton21);
            this.flowLayoutPanel1.FlowDirection = System.Windows.Forms.FlowDirection.RightToLeft;
            this.flowLayoutPanel1.Location = new System.Drawing.Point(615, 571);
            this.flowLayoutPanel1.Name = "flowLayoutPanel1";
            this.flowLayoutPanel1.Size = new System.Drawing.Size(203, 54);
            this.flowLayoutPanel1.TabIndex = 20;
            // 
            // btnAddMember
            // 
            this.btnAddMember.AllowAnimations = true;
            this.btnAddMember.AllowMouseEffects = true;
            this.btnAddMember.AllowToggling = false;
            this.btnAddMember.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.btnAddMember.AnimationSpeed = 200;
            this.btnAddMember.AutoGenerateColors = false;
            this.btnAddMember.AutoRoundBorders = false;
            this.btnAddMember.AutoSizeLeftIcon = true;
            this.btnAddMember.AutoSizeRightIcon = true;
            this.btnAddMember.BackColor = System.Drawing.Color.Transparent;
            this.btnAddMember.BackColor1 = System.Drawing.Color.DodgerBlue;
            this.btnAddMember.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnAddMember.BackgroundImage")));
            this.btnAddMember.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton2.BorderStyles.Solid;
            this.btnAddMember.ButtonText = "Add";
            this.btnAddMember.ButtonTextMarginLeft = 0;
            this.btnAddMember.ColorContrastOnClick = 45;
            this.btnAddMember.ColorContrastOnHover = 45;
            this.btnAddMember.Cursor = System.Windows.Forms.Cursors.Default;
            borderEdges3.BottomLeft = true;
            borderEdges3.BottomRight = true;
            borderEdges3.TopLeft = true;
            borderEdges3.TopRight = true;
            this.btnAddMember.CustomizableEdges = borderEdges3;
            this.btnAddMember.DialogResult = System.Windows.Forms.DialogResult.None;
            this.btnAddMember.DisabledBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(191)))), ((int)(((byte)(191)))), ((int)(((byte)(191)))));
            this.btnAddMember.DisabledFillColor = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(204)))), ((int)(((byte)(204)))));
            this.btnAddMember.DisabledForecolor = System.Drawing.Color.FromArgb(((int)(((byte)(168)))), ((int)(((byte)(160)))), ((int)(((byte)(168)))));
            this.btnAddMember.FocusState = Bunifu.UI.WinForms.BunifuButton.BunifuButton2.ButtonStates.Pressed;
            this.btnAddMember.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAddMember.ForeColor = System.Drawing.Color.White;
            this.btnAddMember.IconLeftAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnAddMember.IconLeftCursor = System.Windows.Forms.Cursors.Default;
            this.btnAddMember.IconLeftPadding = new System.Windows.Forms.Padding(11, 3, 3, 3);
            this.btnAddMember.IconMarginLeft = 11;
            this.btnAddMember.IconPadding = 10;
            this.btnAddMember.IconRightAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnAddMember.IconRightCursor = System.Windows.Forms.Cursors.Default;
            this.btnAddMember.IconRightPadding = new System.Windows.Forms.Padding(3, 3, 7, 3);
            this.btnAddMember.IconSize = 25;
            this.btnAddMember.IdleBorderColor = System.Drawing.Color.DodgerBlue;
            this.btnAddMember.IdleBorderRadius = 40;
            this.btnAddMember.IdleBorderThickness = 1;
            this.btnAddMember.IdleFillColor = System.Drawing.Color.DodgerBlue;
            this.btnAddMember.IdleIconLeftImage = null;
            this.btnAddMember.IdleIconRightImage = null;
            this.btnAddMember.IndicateFocus = false;
            this.btnAddMember.Location = new System.Drawing.Point(118, 10);
            this.btnAddMember.Margin = new System.Windows.Forms.Padding(10);
            this.btnAddMember.Name = "btnAddMember";
            this.btnAddMember.OnDisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(191)))), ((int)(((byte)(191)))), ((int)(((byte)(191)))));
            this.btnAddMember.OnDisabledState.BorderRadius = 40;
            this.btnAddMember.OnDisabledState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton2.BorderStyles.Solid;
            this.btnAddMember.OnDisabledState.BorderThickness = 1;
            this.btnAddMember.OnDisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(204)))), ((int)(((byte)(204)))));
            this.btnAddMember.OnDisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(168)))), ((int)(((byte)(160)))), ((int)(((byte)(168)))));
            this.btnAddMember.OnDisabledState.IconLeftImage = null;
            this.btnAddMember.OnDisabledState.IconRightImage = null;
            this.btnAddMember.onHoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(105)))), ((int)(((byte)(181)))), ((int)(((byte)(255)))));
            this.btnAddMember.onHoverState.BorderRadius = 40;
            this.btnAddMember.onHoverState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton2.BorderStyles.Solid;
            this.btnAddMember.onHoverState.BorderThickness = 1;
            this.btnAddMember.onHoverState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(105)))), ((int)(((byte)(181)))), ((int)(((byte)(255)))));
            this.btnAddMember.onHoverState.ForeColor = System.Drawing.Color.White;
            this.btnAddMember.onHoverState.IconLeftImage = null;
            this.btnAddMember.onHoverState.IconRightImage = null;
            this.btnAddMember.OnIdleState.BorderColor = System.Drawing.Color.DodgerBlue;
            this.btnAddMember.OnIdleState.BorderRadius = 40;
            this.btnAddMember.OnIdleState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton2.BorderStyles.Solid;
            this.btnAddMember.OnIdleState.BorderThickness = 1;
            this.btnAddMember.OnIdleState.FillColor = System.Drawing.Color.DodgerBlue;
            this.btnAddMember.OnIdleState.ForeColor = System.Drawing.Color.White;
            this.btnAddMember.OnIdleState.IconLeftImage = null;
            this.btnAddMember.OnIdleState.IconRightImage = null;
            this.btnAddMember.OnPressedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(96)))), ((int)(((byte)(144)))));
            this.btnAddMember.OnPressedState.BorderRadius = 40;
            this.btnAddMember.OnPressedState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton2.BorderStyles.Solid;
            this.btnAddMember.OnPressedState.BorderThickness = 1;
            this.btnAddMember.OnPressedState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(96)))), ((int)(((byte)(144)))));
            this.btnAddMember.OnPressedState.ForeColor = System.Drawing.Color.White;
            this.btnAddMember.OnPressedState.IconLeftImage = null;
            this.btnAddMember.OnPressedState.IconRightImage = null;
            this.btnAddMember.Size = new System.Drawing.Size(75, 33);
            this.btnAddMember.TabIndex = 18;
            this.btnAddMember.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.btnAddMember.TextAlignment = System.Windows.Forms.HorizontalAlignment.Center;
            this.btnAddMember.TextMarginLeft = 0;
            this.btnAddMember.TextPadding = new System.Windows.Forms.Padding(0);
            this.btnAddMember.UseDefaultRadiusAndThickness = true;
            this.btnAddMember.Click += new System.EventHandler(this.btnAddMember_Click);
            // 
            // bunifuButton21
            // 
            this.bunifuButton21.AllowAnimations = true;
            this.bunifuButton21.AllowMouseEffects = true;
            this.bunifuButton21.AllowToggling = false;
            this.bunifuButton21.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.bunifuButton21.AnimationSpeed = 200;
            this.bunifuButton21.AutoGenerateColors = false;
            this.bunifuButton21.AutoRoundBorders = false;
            this.bunifuButton21.AutoSizeLeftIcon = true;
            this.bunifuButton21.AutoSizeRightIcon = true;
            this.bunifuButton21.BackColor = System.Drawing.Color.Transparent;
            this.bunifuButton21.BackColor1 = System.Drawing.Color.Gainsboro;
            this.bunifuButton21.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("bunifuButton21.BackgroundImage")));
            this.bunifuButton21.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton2.BorderStyles.Solid;
            this.bunifuButton21.ButtonText = "Remove";
            this.bunifuButton21.ButtonTextMarginLeft = 0;
            this.bunifuButton21.ColorContrastOnClick = 45;
            this.bunifuButton21.ColorContrastOnHover = 45;
            this.bunifuButton21.Cursor = System.Windows.Forms.Cursors.Default;
            borderEdges4.BottomLeft = true;
            borderEdges4.BottomRight = true;
            borderEdges4.TopLeft = true;
            borderEdges4.TopRight = true;
            this.bunifuButton21.CustomizableEdges = borderEdges4;
            this.bunifuButton21.DialogResult = System.Windows.Forms.DialogResult.None;
            this.bunifuButton21.DisabledBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(191)))), ((int)(((byte)(191)))), ((int)(((byte)(191)))));
            this.bunifuButton21.DisabledFillColor = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(204)))), ((int)(((byte)(204)))));
            this.bunifuButton21.DisabledForecolor = System.Drawing.Color.FromArgb(((int)(((byte)(168)))), ((int)(((byte)(160)))), ((int)(((byte)(168)))));
            this.bunifuButton21.FocusState = Bunifu.UI.WinForms.BunifuButton.BunifuButton2.ButtonStates.Pressed;
            this.bunifuButton21.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuButton21.ForeColor = System.Drawing.Color.DodgerBlue;
            this.bunifuButton21.IconLeftAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.bunifuButton21.IconLeftCursor = System.Windows.Forms.Cursors.Default;
            this.bunifuButton21.IconLeftPadding = new System.Windows.Forms.Padding(11, 3, 3, 3);
            this.bunifuButton21.IconMarginLeft = 11;
            this.bunifuButton21.IconPadding = 10;
            this.bunifuButton21.IconRightAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.bunifuButton21.IconRightCursor = System.Windows.Forms.Cursors.Default;
            this.bunifuButton21.IconRightPadding = new System.Windows.Forms.Padding(3, 3, 7, 3);
            this.bunifuButton21.IconSize = 25;
            this.bunifuButton21.IdleBorderColor = System.Drawing.Color.Gainsboro;
            this.bunifuButton21.IdleBorderRadius = 40;
            this.bunifuButton21.IdleBorderThickness = 1;
            this.bunifuButton21.IdleFillColor = System.Drawing.Color.Gainsboro;
            this.bunifuButton21.IdleIconLeftImage = null;
            this.bunifuButton21.IdleIconRightImage = null;
            this.bunifuButton21.IndicateFocus = false;
            this.bunifuButton21.Location = new System.Drawing.Point(19, 10);
            this.bunifuButton21.Margin = new System.Windows.Forms.Padding(10);
            this.bunifuButton21.Name = "bunifuButton21";
            this.bunifuButton21.OnDisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(191)))), ((int)(((byte)(191)))), ((int)(((byte)(191)))));
            this.bunifuButton21.OnDisabledState.BorderRadius = 40;
            this.bunifuButton21.OnDisabledState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton2.BorderStyles.Solid;
            this.bunifuButton21.OnDisabledState.BorderThickness = 1;
            this.bunifuButton21.OnDisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(204)))), ((int)(((byte)(204)))));
            this.bunifuButton21.OnDisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(168)))), ((int)(((byte)(160)))), ((int)(((byte)(168)))));
            this.bunifuButton21.OnDisabledState.IconLeftImage = null;
            this.bunifuButton21.OnDisabledState.IconRightImage = null;
            this.bunifuButton21.onHoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(105)))), ((int)(((byte)(181)))), ((int)(((byte)(255)))));
            this.bunifuButton21.onHoverState.BorderRadius = 40;
            this.bunifuButton21.onHoverState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton2.BorderStyles.Solid;
            this.bunifuButton21.onHoverState.BorderThickness = 1;
            this.bunifuButton21.onHoverState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(105)))), ((int)(((byte)(181)))), ((int)(((byte)(255)))));
            this.bunifuButton21.onHoverState.ForeColor = System.Drawing.Color.White;
            this.bunifuButton21.onHoverState.IconLeftImage = null;
            this.bunifuButton21.onHoverState.IconRightImage = null;
            this.bunifuButton21.OnIdleState.BorderColor = System.Drawing.Color.Gainsboro;
            this.bunifuButton21.OnIdleState.BorderRadius = 40;
            this.bunifuButton21.OnIdleState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton2.BorderStyles.Solid;
            this.bunifuButton21.OnIdleState.BorderThickness = 1;
            this.bunifuButton21.OnIdleState.FillColor = System.Drawing.Color.Gainsboro;
            this.bunifuButton21.OnIdleState.ForeColor = System.Drawing.Color.DodgerBlue;
            this.bunifuButton21.OnIdleState.IconLeftImage = null;
            this.bunifuButton21.OnIdleState.IconRightImage = null;
            this.bunifuButton21.OnPressedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(96)))), ((int)(((byte)(144)))));
            this.bunifuButton21.OnPressedState.BorderRadius = 40;
            this.bunifuButton21.OnPressedState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton2.BorderStyles.Solid;
            this.bunifuButton21.OnPressedState.BorderThickness = 1;
            this.bunifuButton21.OnPressedState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(96)))), ((int)(((byte)(144)))));
            this.bunifuButton21.OnPressedState.ForeColor = System.Drawing.Color.White;
            this.bunifuButton21.OnPressedState.IconLeftImage = null;
            this.bunifuButton21.OnPressedState.IconRightImage = null;
            this.bunifuButton21.Size = new System.Drawing.Size(79, 33);
            this.bunifuButton21.TabIndex = 10;
            this.bunifuButton21.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.bunifuButton21.TextAlignment = System.Windows.Forms.HorizontalAlignment.Center;
            this.bunifuButton21.TextMarginLeft = 0;
            this.bunifuButton21.TextPadding = new System.Windows.Forms.Padding(0);
            this.bunifuButton21.UseDefaultRadiusAndThickness = true;
            this.bunifuButton21.Click += new System.EventHandler(this.btnRemoveMember_Click);
            // 
            // bunifuCustomLabel5
            // 
            this.bunifuCustomLabel5.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.bunifuCustomLabel5.AutoSize = true;
            this.bunifuCustomLabel5.BackColor = System.Drawing.Color.Transparent;
            this.bunifuCustomLabel5.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuCustomLabel5.Location = new System.Drawing.Point(192, 10);
            this.bunifuCustomLabel5.Margin = new System.Windows.Forms.Padding(10);
            this.bunifuCustomLabel5.Name = "bunifuCustomLabel5";
            this.bunifuCustomLabel5.Size = new System.Drawing.Size(68, 25);
            this.bunifuCustomLabel5.TabIndex = 7;
            this.bunifuCustomLabel5.Text = "Name";
            this.bunifuCustomLabel5.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // bunifuCustomLabel2
            // 
            this.bunifuCustomLabel2.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.bunifuCustomLabel2.BackColor = System.Drawing.Color.Transparent;
            this.bunifuCustomLabel2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuCustomLabel2.Location = new System.Drawing.Point(10, 120);
            this.bunifuCustomLabel2.Margin = new System.Windows.Forms.Padding(10);
            this.bunifuCustomLabel2.Name = "bunifuCustomLabel2";
            this.bunifuCustomLabel2.Size = new System.Drawing.Size(67, 20);
            this.bunifuCustomLabel2.TabIndex = 2;
            this.bunifuCustomLabel2.Text = "Budget";
            this.bunifuCustomLabel2.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // tbProjectName
            // 
            this.tbProjectName.AcceptsReturn = false;
            this.tbProjectName.AcceptsTab = false;
            this.tbProjectName.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.tbProjectName.AnimationSpeed = 200;
            this.tbProjectName.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.None;
            this.tbProjectName.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.None;
            this.tbProjectName.AutoSizeHeight = true;
            this.tbProjectName.BackColor = System.Drawing.Color.Transparent;
            this.tbProjectName.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("tbProjectName.BackgroundImage")));
            this.tbProjectName.BorderColorActive = System.Drawing.Color.DodgerBlue;
            this.tbProjectName.BorderColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(204)))), ((int)(((byte)(204)))));
            this.tbProjectName.BorderColorHover = System.Drawing.Color.FromArgb(((int)(((byte)(105)))), ((int)(((byte)(181)))), ((int)(((byte)(255)))));
            this.tbProjectName.BorderColorIdle = System.Drawing.Color.Silver;
            this.tbProjectName.BorderRadius = 30;
            this.tbProjectName.BorderThickness = 1;
            this.tbProjectName.CharacterCase = Bunifu.UI.WinForms.BunifuTextBox.CharacterCases.Normal;
            this.tbProjectName.CharacterCasing = System.Windows.Forms.CharacterCasing.Normal;
            this.tbProjectName.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.tbProjectName.DefaultFont = new System.Drawing.Font("Segoe UI", 9.25F);
            this.tbProjectName.DefaultText = "";
            this.tbProjectName.FillColor = System.Drawing.Color.White;
            this.tbProjectName.HideSelection = true;
            this.tbProjectName.IconLeft = null;
            this.tbProjectName.IconLeftCursor = System.Windows.Forms.Cursors.IBeam;
            this.tbProjectName.IconPadding = 10;
            this.tbProjectName.IconRight = null;
            this.tbProjectName.IconRightCursor = System.Windows.Forms.Cursors.IBeam;
            this.tbProjectName.Lines = new string[0];
            this.tbProjectName.Location = new System.Drawing.Point(219, 55);
            this.tbProjectName.Margin = new System.Windows.Forms.Padding(10);
            this.tbProjectName.MaxLength = 32767;
            this.tbProjectName.MinimumSize = new System.Drawing.Size(1, 1);
            this.tbProjectName.Modified = false;
            this.tbProjectName.Multiline = false;
            this.tbProjectName.Name = "tbProjectName";
            stateProperties1.BorderColor = System.Drawing.Color.DodgerBlue;
            stateProperties1.FillColor = System.Drawing.Color.Empty;
            stateProperties1.ForeColor = System.Drawing.Color.Empty;
            stateProperties1.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.tbProjectName.OnActiveState = stateProperties1;
            stateProperties2.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(204)))), ((int)(((byte)(204)))));
            stateProperties2.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(240)))), ((int)(((byte)(240)))), ((int)(((byte)(240)))));
            stateProperties2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            stateProperties2.PlaceholderForeColor = System.Drawing.Color.DarkGray;
            this.tbProjectName.OnDisabledState = stateProperties2;
            stateProperties3.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(105)))), ((int)(((byte)(181)))), ((int)(((byte)(255)))));
            stateProperties3.FillColor = System.Drawing.Color.Empty;
            stateProperties3.ForeColor = System.Drawing.Color.Empty;
            stateProperties3.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.tbProjectName.OnHoverState = stateProperties3;
            stateProperties4.BorderColor = System.Drawing.Color.Silver;
            stateProperties4.FillColor = System.Drawing.Color.White;
            stateProperties4.ForeColor = System.Drawing.Color.Empty;
            stateProperties4.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.tbProjectName.OnIdleState = stateProperties4;
            this.tbProjectName.Padding = new System.Windows.Forms.Padding(3);
            this.tbProjectName.PasswordChar = '\0';
            this.tbProjectName.PlaceholderForeColor = System.Drawing.Color.Silver;
            this.tbProjectName.PlaceholderText = "";
            this.tbProjectName.ReadOnly = false;
            this.tbProjectName.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.tbProjectName.SelectedText = "";
            this.tbProjectName.SelectionLength = 0;
            this.tbProjectName.SelectionStart = 0;
            this.tbProjectName.ShortcutsEnabled = true;
            this.tbProjectName.Size = new System.Drawing.Size(151, 43);
            this.tbProjectName.Style = Bunifu.UI.WinForms.BunifuTextBox._Style.Bunifu;
            this.tbProjectName.TabIndex = 3;
            this.tbProjectName.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.tbProjectName.TextMarginBottom = 0;
            this.tbProjectName.TextMarginLeft = 3;
            this.tbProjectName.TextMarginTop = 1;
            this.tbProjectName.TextPlaceholder = "";
            this.tbProjectName.UseSystemPasswordChar = false;
            this.tbProjectName.WordWrap = true;
            // 
            // tbProjectCode
            // 
            this.tbProjectCode.AcceptsReturn = false;
            this.tbProjectCode.AcceptsTab = false;
            this.tbProjectCode.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.tbProjectCode.AnimationSpeed = 200;
            this.tbProjectCode.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.None;
            this.tbProjectCode.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.None;
            this.tbProjectCode.AutoSizeHeight = true;
            this.tbProjectCode.BackColor = System.Drawing.Color.Transparent;
            this.tbProjectCode.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("tbProjectCode.BackgroundImage")));
            this.tbProjectCode.BorderColorActive = System.Drawing.Color.DodgerBlue;
            this.tbProjectCode.BorderColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(204)))), ((int)(((byte)(204)))));
            this.tbProjectCode.BorderColorHover = System.Drawing.Color.FromArgb(((int)(((byte)(105)))), ((int)(((byte)(181)))), ((int)(((byte)(255)))));
            this.tbProjectCode.BorderColorIdle = System.Drawing.Color.Silver;
            this.tbProjectCode.BorderRadius = 30;
            this.tbProjectCode.BorderThickness = 1;
            this.tbProjectCode.CharacterCase = Bunifu.UI.WinForms.BunifuTextBox.CharacterCases.Normal;
            this.tbProjectCode.CharacterCasing = System.Windows.Forms.CharacterCasing.Normal;
            this.tbProjectCode.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.tbProjectCode.DefaultFont = new System.Drawing.Font("Segoe UI", 9.25F);
            this.tbProjectCode.DefaultText = "";
            this.tbProjectCode.FillColor = System.Drawing.Color.White;
            this.tbProjectCode.HideSelection = true;
            this.tbProjectCode.IconLeft = null;
            this.tbProjectCode.IconLeftCursor = System.Windows.Forms.Cursors.IBeam;
            this.tbProjectCode.IconPadding = 10;
            this.tbProjectCode.IconRight = null;
            this.tbProjectCode.IconRightCursor = System.Windows.Forms.Cursors.IBeam;
            this.tbProjectCode.Lines = new string[0];
            this.tbProjectCode.Location = new System.Drawing.Point(14, 55);
            this.tbProjectCode.Margin = new System.Windows.Forms.Padding(10);
            this.tbProjectCode.MaxLength = 32767;
            this.tbProjectCode.MinimumSize = new System.Drawing.Size(1, 1);
            this.tbProjectCode.Modified = false;
            this.tbProjectCode.Multiline = false;
            this.tbProjectCode.Name = "tbProjectCode";
            stateProperties5.BorderColor = System.Drawing.Color.DodgerBlue;
            stateProperties5.FillColor = System.Drawing.Color.Empty;
            stateProperties5.ForeColor = System.Drawing.Color.Empty;
            stateProperties5.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.tbProjectCode.OnActiveState = stateProperties5;
            stateProperties6.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(204)))), ((int)(((byte)(204)))));
            stateProperties6.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(240)))), ((int)(((byte)(240)))), ((int)(((byte)(240)))));
            stateProperties6.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            stateProperties6.PlaceholderForeColor = System.Drawing.Color.DarkGray;
            this.tbProjectCode.OnDisabledState = stateProperties6;
            stateProperties7.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(105)))), ((int)(((byte)(181)))), ((int)(((byte)(255)))));
            stateProperties7.FillColor = System.Drawing.Color.Empty;
            stateProperties7.ForeColor = System.Drawing.Color.Empty;
            stateProperties7.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.tbProjectCode.OnHoverState = stateProperties7;
            stateProperties8.BorderColor = System.Drawing.Color.Silver;
            stateProperties8.FillColor = System.Drawing.Color.White;
            stateProperties8.ForeColor = System.Drawing.Color.Empty;
            stateProperties8.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.tbProjectCode.OnIdleState = stateProperties8;
            this.tbProjectCode.Padding = new System.Windows.Forms.Padding(3);
            this.tbProjectCode.PasswordChar = '\0';
            this.tbProjectCode.PlaceholderForeColor = System.Drawing.Color.Silver;
            this.tbProjectCode.PlaceholderText = "";
            this.tbProjectCode.ReadOnly = false;
            this.tbProjectCode.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.tbProjectCode.SelectedText = "";
            this.tbProjectCode.SelectionLength = 0;
            this.tbProjectCode.SelectionStart = 0;
            this.tbProjectCode.ShortcutsEnabled = true;
            this.tbProjectCode.Size = new System.Drawing.Size(154, 43);
            this.tbProjectCode.Style = Bunifu.UI.WinForms.BunifuTextBox._Style.Bunifu;
            this.tbProjectCode.TabIndex = 4;
            this.tbProjectCode.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.tbProjectCode.TextMarginBottom = 0;
            this.tbProjectCode.TextMarginLeft = 3;
            this.tbProjectCode.TextMarginTop = 1;
            this.tbProjectCode.TextPlaceholder = "";
            this.tbProjectCode.UseSystemPasswordChar = false;
            this.tbProjectCode.WordWrap = true;
            // 
            // bunifuCustomLabel3
            // 
            this.bunifuCustomLabel3.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.bunifuCustomLabel3.AutoSize = true;
            this.bunifuCustomLabel3.BackColor = System.Drawing.Color.Transparent;
            this.bunifuCustomLabel3.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuCustomLabel3.Location = new System.Drawing.Point(418, 10);
            this.bunifuCustomLabel3.Margin = new System.Windows.Forms.Padding(10);
            this.bunifuCustomLabel3.Name = "bunifuCustomLabel3";
            this.bunifuCustomLabel3.Size = new System.Drawing.Size(109, 25);
            this.bunifuCustomLabel3.TabIndex = 5;
            this.bunifuCustomLabel3.Text = "Start Date";
            this.bunifuCustomLabel3.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // bunifuCustomLabel4
            // 
            this.bunifuCustomLabel4.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.bunifuCustomLabel4.AutoSize = true;
            this.bunifuCustomLabel4.BackColor = System.Drawing.Color.Transparent;
            this.bunifuCustomLabel4.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuCustomLabel4.Location = new System.Drawing.Point(622, 10);
            this.bunifuCustomLabel4.Margin = new System.Windows.Forms.Padding(10);
            this.bunifuCustomLabel4.Name = "bunifuCustomLabel4";
            this.bunifuCustomLabel4.Size = new System.Drawing.Size(101, 25);
            this.bunifuCustomLabel4.TabIndex = 6;
            this.bunifuCustomLabel4.Text = "End Date";
            this.bunifuCustomLabel4.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // tbBudget
            // 
            this.tbBudget.AcceptsReturn = false;
            this.tbBudget.AcceptsTab = false;
            this.tbBudget.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.tbBudget.AnimationSpeed = 200;
            this.tbBudget.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.None;
            this.tbBudget.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.None;
            this.tbBudget.AutoSizeHeight = true;
            this.tbBudget.BackColor = System.Drawing.Color.Transparent;
            this.tbBudget.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("tbBudget.BackgroundImage")));
            this.tbBudget.BorderColorActive = System.Drawing.Color.DodgerBlue;
            this.tbBudget.BorderColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(204)))), ((int)(((byte)(204)))));
            this.tbBudget.BorderColorHover = System.Drawing.Color.FromArgb(((int)(((byte)(105)))), ((int)(((byte)(181)))), ((int)(((byte)(255)))));
            this.tbBudget.BorderColorIdle = System.Drawing.Color.Silver;
            this.tbBudget.BorderRadius = 30;
            this.tbBudget.BorderThickness = 1;
            this.tbBudget.CharacterCase = Bunifu.UI.WinForms.BunifuTextBox.CharacterCases.Normal;
            this.tbBudget.CharacterCasing = System.Windows.Forms.CharacterCasing.Normal;
            this.tbBudget.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.tbBudget.DefaultFont = new System.Drawing.Font("Segoe UI", 9.25F);
            this.tbBudget.DefaultText = "";
            this.tbBudget.FillColor = System.Drawing.Color.White;
            this.tbBudget.HideSelection = true;
            this.tbBudget.IconLeft = null;
            this.tbBudget.IconLeftCursor = System.Windows.Forms.Cursors.IBeam;
            this.tbBudget.IconPadding = 10;
            this.tbBudget.IconRight = null;
            this.tbBudget.IconRightCursor = System.Windows.Forms.Cursors.IBeam;
            this.tbBudget.Lines = new string[0];
            this.tbBudget.Location = new System.Drawing.Point(15, 163);
            this.tbBudget.Margin = new System.Windows.Forms.Padding(10);
            this.tbBudget.MaxLength = 32767;
            this.tbBudget.MinimumSize = new System.Drawing.Size(1, 1);
            this.tbBudget.Modified = false;
            this.tbBudget.Multiline = false;
            this.tbBudget.Name = "tbBudget";
            stateProperties9.BorderColor = System.Drawing.Color.DodgerBlue;
            stateProperties9.FillColor = System.Drawing.Color.Empty;
            stateProperties9.ForeColor = System.Drawing.Color.Empty;
            stateProperties9.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.tbBudget.OnActiveState = stateProperties9;
            stateProperties10.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(204)))), ((int)(((byte)(204)))));
            stateProperties10.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(240)))), ((int)(((byte)(240)))), ((int)(((byte)(240)))));
            stateProperties10.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            stateProperties10.PlaceholderForeColor = System.Drawing.Color.DarkGray;
            this.tbBudget.OnDisabledState = stateProperties10;
            stateProperties11.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(105)))), ((int)(((byte)(181)))), ((int)(((byte)(255)))));
            stateProperties11.FillColor = System.Drawing.Color.Empty;
            stateProperties11.ForeColor = System.Drawing.Color.Empty;
            stateProperties11.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.tbBudget.OnHoverState = stateProperties11;
            stateProperties12.BorderColor = System.Drawing.Color.Silver;
            stateProperties12.FillColor = System.Drawing.Color.White;
            stateProperties12.ForeColor = System.Drawing.Color.Empty;
            stateProperties12.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.tbBudget.OnIdleState = stateProperties12;
            this.tbBudget.Padding = new System.Windows.Forms.Padding(3);
            this.tbBudget.PasswordChar = '\0';
            this.tbBudget.PlaceholderForeColor = System.Drawing.Color.Silver;
            this.tbBudget.PlaceholderText = "";
            this.tbBudget.ReadOnly = false;
            this.tbBudget.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.tbBudget.SelectedText = "";
            this.tbBudget.SelectionLength = 0;
            this.tbBudget.SelectionStart = 0;
            this.tbBudget.ShortcutsEnabled = true;
            this.tbBudget.Size = new System.Drawing.Size(151, 43);
            this.tbBudget.Style = Bunifu.UI.WinForms.BunifuTextBox._Style.Bunifu;
            this.tbBudget.TabIndex = 8;
            this.tbBudget.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.tbBudget.TextMarginBottom = 0;
            this.tbBudget.TextMarginLeft = 3;
            this.tbBudget.TextMarginTop = 1;
            this.tbBudget.TextPlaceholder = "";
            this.tbBudget.UseSystemPasswordChar = false;
            this.tbBudget.WordWrap = true;
            // 
            // cbPriority
            // 
            this.cbPriority.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.cbPriority.FormattingEnabled = true;
            this.cbPriority.Location = new System.Drawing.Point(15, 271);
            this.cbPriority.Margin = new System.Windows.Forms.Padding(10);
            this.cbPriority.Name = "cbPriority";
            this.cbPriority.Size = new System.Drawing.Size(151, 46);
            this.cbPriority.TabIndex = 15;
            // 
            // bunifuCustomLabel10
            // 
            this.bunifuCustomLabel10.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.bunifuCustomLabel10.AutoSize = true;
            this.bunifuCustomLabel10.BackColor = System.Drawing.Color.Transparent;
            this.bunifuCustomLabel10.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuCustomLabel10.Location = new System.Drawing.Point(10, 226);
            this.bunifuCustomLabel10.Margin = new System.Windows.Forms.Padding(10);
            this.bunifuCustomLabel10.Name = "bunifuCustomLabel10";
            this.bunifuCustomLabel10.Size = new System.Drawing.Size(79, 25);
            this.bunifuCustomLabel10.TabIndex = 14;
            this.bunifuCustomLabel10.Text = "Priority";
            this.bunifuCustomLabel10.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // tbProjectDesrciption
            // 
            this.tbProjectDesrciption.AcceptsReturn = false;
            this.tbProjectDesrciption.AcceptsTab = false;
            this.tbProjectDesrciption.AnimationSpeed = 200;
            this.tbProjectDesrciption.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.None;
            this.tbProjectDesrciption.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.None;
            this.tbProjectDesrciption.AutoSizeHeight = true;
            this.tbProjectDesrciption.BackColor = System.Drawing.Color.Transparent;
            this.tbProjectDesrciption.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("tbProjectDesrciption.BackgroundImage")));
            this.tbProjectDesrciption.BorderColorActive = System.Drawing.Color.DodgerBlue;
            this.tbProjectDesrciption.BorderColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(204)))), ((int)(((byte)(204)))));
            this.tbProjectDesrciption.BorderColorHover = System.Drawing.Color.FromArgb(((int)(((byte)(105)))), ((int)(((byte)(181)))), ((int)(((byte)(255)))));
            this.tbProjectDesrciption.BorderColorIdle = System.Drawing.Color.Silver;
            this.tbProjectDesrciption.BorderRadius = 30;
            this.tbProjectDesrciption.BorderThickness = 1;
            this.tbProjectDesrciption.CharacterCase = Bunifu.UI.WinForms.BunifuTextBox.CharacterCases.Normal;
            this.tbProjectDesrciption.CharacterCasing = System.Windows.Forms.CharacterCasing.Normal;
            this.tableLayoutPanel1.SetColumnSpan(this.tbProjectDesrciption, 2);
            this.tbProjectDesrciption.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.tbProjectDesrciption.DefaultFont = new System.Drawing.Font("Segoe UI", 9.25F);
            this.tbProjectDesrciption.DefaultText = "";
            this.tbProjectDesrciption.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tbProjectDesrciption.FillColor = System.Drawing.Color.White;
            this.tbProjectDesrciption.HideSelection = true;
            this.tbProjectDesrciption.IconLeft = null;
            this.tbProjectDesrciption.IconLeftCursor = System.Windows.Forms.Cursors.IBeam;
            this.tbProjectDesrciption.IconPadding = 10;
            this.tbProjectDesrciption.IconRight = null;
            this.tbProjectDesrciption.IconRightCursor = System.Windows.Forms.Cursors.IBeam;
            this.tbProjectDesrciption.Lines = new string[0];
            this.tbProjectDesrciption.Location = new System.Drawing.Point(10, 369);
            this.tbProjectDesrciption.Margin = new System.Windows.Forms.Padding(10);
            this.tbProjectDesrciption.MaxLength = 32767;
            this.tbProjectDesrciption.MinimumSize = new System.Drawing.Size(1, 1);
            this.tbProjectDesrciption.Modified = false;
            this.tbProjectDesrciption.Multiline = true;
            this.tbProjectDesrciption.Name = "tbProjectDesrciption";
            stateProperties13.BorderColor = System.Drawing.Color.DodgerBlue;
            stateProperties13.FillColor = System.Drawing.Color.Empty;
            stateProperties13.ForeColor = System.Drawing.Color.Empty;
            stateProperties13.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.tbProjectDesrciption.OnActiveState = stateProperties13;
            stateProperties14.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(204)))), ((int)(((byte)(204)))));
            stateProperties14.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(240)))), ((int)(((byte)(240)))), ((int)(((byte)(240)))));
            stateProperties14.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            stateProperties14.PlaceholderForeColor = System.Drawing.Color.DarkGray;
            this.tbProjectDesrciption.OnDisabledState = stateProperties14;
            stateProperties15.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(105)))), ((int)(((byte)(181)))), ((int)(((byte)(255)))));
            stateProperties15.FillColor = System.Drawing.Color.Empty;
            stateProperties15.ForeColor = System.Drawing.Color.Empty;
            stateProperties15.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.tbProjectDesrciption.OnHoverState = stateProperties15;
            stateProperties16.BorderColor = System.Drawing.Color.Silver;
            stateProperties16.FillColor = System.Drawing.Color.White;
            stateProperties16.ForeColor = System.Drawing.Color.Empty;
            stateProperties16.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.tbProjectDesrciption.OnIdleState = stateProperties16;
            this.tbProjectDesrciption.Padding = new System.Windows.Forms.Padding(3);
            this.tbProjectDesrciption.PasswordChar = '\0';
            this.tbProjectDesrciption.PlaceholderForeColor = System.Drawing.Color.Silver;
            this.tbProjectDesrciption.PlaceholderText = "";
            this.tbProjectDesrciption.ReadOnly = false;
            this.tbProjectDesrciption.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.tbProjectDesrciption.SelectedText = "";
            this.tbProjectDesrciption.SelectionLength = 0;
            this.tbProjectDesrciption.SelectionStart = 0;
            this.tbProjectDesrciption.ShortcutsEnabled = true;
            this.tbProjectDesrciption.Size = new System.Drawing.Size(388, 189);
            this.tbProjectDesrciption.Style = Bunifu.UI.WinForms.BunifuTextBox._Style.Bunifu;
            this.tbProjectDesrciption.TabIndex = 16;
            this.tbProjectDesrciption.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.tbProjectDesrciption.TextMarginBottom = 0;
            this.tbProjectDesrciption.TextMarginLeft = 3;
            this.tbProjectDesrciption.TextMarginTop = 1;
            this.tbProjectDesrciption.TextPlaceholder = "";
            this.tbProjectDesrciption.UseSystemPasswordChar = false;
            this.tbProjectDesrciption.WordWrap = true;
            // 
            // bunifuCustomLabel1
            // 
            this.bunifuCustomLabel1.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.bunifuCustomLabel1.BackColor = System.Drawing.Color.Transparent;
            this.bunifuCustomLabel1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuCustomLabel1.Location = new System.Drawing.Point(10, 12);
            this.bunifuCustomLabel1.Margin = new System.Windows.Forms.Padding(10);
            this.bunifuCustomLabel1.Name = "bunifuCustomLabel1";
            this.bunifuCustomLabel1.Size = new System.Drawing.Size(51, 20);
            this.bunifuCustomLabel1.TabIndex = 2;
            this.bunifuCustomLabel1.Text = "Code";
            this.bunifuCustomLabel1.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // bunifuCustomLabel6
            // 
            this.bunifuCustomLabel6.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.bunifuCustomLabel6.BackColor = System.Drawing.Color.Transparent;
            this.bunifuCustomLabel6.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuCustomLabel6.Location = new System.Drawing.Point(10, 315);
            this.bunifuCustomLabel6.Margin = new System.Windows.Forms.Padding(10);
            this.bunifuCustomLabel6.Name = "bunifuCustomLabel6";
            this.bunifuCustomLabel6.Size = new System.Drawing.Size(162, 34);
            this.bunifuCustomLabel6.TabIndex = 17;
            this.bunifuCustomLabel6.Text = "Project Description";
            this.bunifuCustomLabel6.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // tableLayoutPanel1
            // 
            this.tableLayoutPanel1.ColumnCount = 4;
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle());
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle());
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle());
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle());
            this.tableLayoutPanel1.Controls.Add(this.cbRole, 3, 3);
            this.tableLayoutPanel1.Controls.Add(this.listviewMembers, 2, 5);
            this.tableLayoutPanel1.Controls.Add(this.bunifuCustomLabel5, 1, 0);
            this.tableLayoutPanel1.Controls.Add(this.bunifuCustomLabel1, 0, 0);
            this.tableLayoutPanel1.Controls.Add(this.cbMember, 2, 3);
            this.tableLayoutPanel1.Controls.Add(this.cbStatus, 1, 3);
            this.tableLayoutPanel1.Controls.Add(this.bunifuCustomLabel2, 0, 2);
            this.tableLayoutPanel1.Controls.Add(this.tbProjectName, 1, 1);
            this.tableLayoutPanel1.Controls.Add(this.tbProjectCode, 0, 1);
            this.tableLayoutPanel1.Controls.Add(this.bunifuCustomLabel3, 2, 0);
            this.tableLayoutPanel1.Controls.Add(this.bunifuCustomLabel4, 3, 0);
            this.tableLayoutPanel1.Controls.Add(this.tbBudget, 0, 3);
            this.tableLayoutPanel1.Controls.Add(this.cbPriority, 0, 5);
            this.tableLayoutPanel1.Controls.Add(this.datePickerEnd, 3, 1);
            this.tableLayoutPanel1.Controls.Add(this.bunifuCustomLabel9, 3, 2);
            this.tableLayoutPanel1.Controls.Add(this.datePickerStart, 2, 1);
            this.tableLayoutPanel1.Controls.Add(this.bunifuCustomLabel10, 0, 4);
            this.tableLayoutPanel1.Controls.Add(this.bunifuCustomLabel6, 0, 6);
            this.tableLayoutPanel1.Controls.Add(this.bunifuCustomLabel8, 2, 2);
            this.tableLayoutPanel1.Controls.Add(this.tbProjectDesrciption, 0, 7);
            this.tableLayoutPanel1.Controls.Add(this.bunifuCustomLabel7, 1, 2);
            this.tableLayoutPanel1.Controls.Add(this.btCreateProject, 2, 10);
            this.tableLayoutPanel1.Controls.Add(this.btCancelProject, 3, 10);
            this.tableLayoutPanel1.Controls.Add(this.bunifuCustomLabel11, 2, 4);
            this.tableLayoutPanel1.Controls.Add(this.flowLayoutPanel1, 3, 9);
            this.tableLayoutPanel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel1.Location = new System.Drawing.Point(0, 0);
            this.tableLayoutPanel1.Name = "tableLayoutPanel1";
            this.tableLayoutPanel1.RowCount = 12;
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel1.Size = new System.Drawing.Size(834, 735);
            this.tableLayoutPanel1.TabIndex = 1;
            // 
            // CtrlCreateProject
            // 
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None;
            this.BackColor = System.Drawing.Color.White;
            this.Controls.Add(this.tableLayoutPanel1);
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 19.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Name = "CtrlCreateProject";
            this.Size = new System.Drawing.Size(834, 735);
            this.Load += new System.EventHandler(this.ctrlCreateProject_Load);
            this.flowLayoutPanel1.ResumeLayout(false);
            this.tableLayoutPanel1.ResumeLayout(false);
            this.tableLayoutPanel1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.ComboBox cbRole;
        private System.Windows.Forms.ListView listviewMembers;
        private System.Windows.Forms.ColumnHeader id;
        private System.Windows.Forms.ColumnHeader name;
        private System.Windows.Forms.ColumnHeader role;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel1;
        private Bunifu.Framework.UI.BunifuCustomLabel bunifuCustomLabel5;
        private Bunifu.Framework.UI.BunifuCustomLabel bunifuCustomLabel1;
        private System.Windows.Forms.ComboBox cbMember;
        private System.Windows.Forms.ComboBox cbStatus;
        private Bunifu.Framework.UI.BunifuCustomLabel bunifuCustomLabel2;
        private Bunifu.UI.WinForms.BunifuTextBox tbProjectName;
        private Bunifu.UI.WinForms.BunifuTextBox tbProjectCode;
        private Bunifu.Framework.UI.BunifuCustomLabel bunifuCustomLabel3;
        private Bunifu.Framework.UI.BunifuCustomLabel bunifuCustomLabel4;
        private Bunifu.UI.WinForms.BunifuTextBox tbBudget;
        private System.Windows.Forms.ComboBox cbPriority;
        private Bunifu.UI.WinForms.BunifuDatePicker datePickerEnd;
        private Bunifu.Framework.UI.BunifuCustomLabel bunifuCustomLabel9;
        private Bunifu.UI.WinForms.BunifuDatePicker datePickerStart;
        private Bunifu.Framework.UI.BunifuCustomLabel bunifuCustomLabel10;
        private Bunifu.Framework.UI.BunifuCustomLabel bunifuCustomLabel6;
        private Bunifu.Framework.UI.BunifuCustomLabel bunifuCustomLabel8;
        private Bunifu.UI.WinForms.BunifuTextBox tbProjectDesrciption;
        private Bunifu.Framework.UI.BunifuCustomLabel bunifuCustomLabel7;
        private Bunifu.UI.WinForms.BunifuButton.BunifuButton2 btCreateProject;
        private Bunifu.UI.WinForms.BunifuButton.BunifuButton2 btCancelProject;
        private Bunifu.Framework.UI.BunifuCustomLabel bunifuCustomLabel11;
        private System.Windows.Forms.FlowLayoutPanel flowLayoutPanel1;
        private Bunifu.UI.WinForms.BunifuButton.BunifuButton2 btnAddMember;
        private Bunifu.UI.WinForms.BunifuButton.BunifuButton2 bunifuButton21;
    }
}
