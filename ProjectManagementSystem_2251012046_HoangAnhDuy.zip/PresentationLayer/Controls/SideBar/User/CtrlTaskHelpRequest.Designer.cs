﻿namespace PresentationLayer.Controls.SideBar.User
{
    partial class CtrlPanelTaskRequestHelp
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(CtrlPanelTaskRequestHelp));
            Bunifu.UI.WinForms.BunifuTextBox.StateProperties stateProperties1 = new Bunifu.UI.WinForms.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextBox.StateProperties stateProperties2 = new Bunifu.UI.WinForms.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextBox.StateProperties stateProperties3 = new Bunifu.UI.WinForms.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextBox.StateProperties stateProperties4 = new Bunifu.UI.WinForms.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderEdges borderEdges1 = new Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderEdges();
            Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderEdges borderEdges2 = new Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderEdges();
            Bunifu.UI.WinForms.BunifuTextBox.StateProperties stateProperties5 = new Bunifu.UI.WinForms.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextBox.StateProperties stateProperties6 = new Bunifu.UI.WinForms.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextBox.StateProperties stateProperties7 = new Bunifu.UI.WinForms.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextBox.StateProperties stateProperties8 = new Bunifu.UI.WinForms.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextBox.StateProperties stateProperties9 = new Bunifu.UI.WinForms.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextBox.StateProperties stateProperties10 = new Bunifu.UI.WinForms.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextBox.StateProperties stateProperties11 = new Bunifu.UI.WinForms.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextBox.StateProperties stateProperties12 = new Bunifu.UI.WinForms.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderEdges borderEdges3 = new Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderEdges();
            this.splitContainer1 = new System.Windows.Forms.SplitContainer();
            this.dgvItems = new Bunifu.UI.WinForms.BunifuDataGridView();
            this.panel1 = new System.Windows.Forms.Panel();
            this.tbSearch = new Bunifu.UI.WinForms.BunifuTextBox();
            this.roundedLabel1 = new PresentationLayer.CustomControls.RoundedLabel();
            this.tableLayoutPanel1 = new System.Windows.Forms.TableLayoutPanel();
            this.lbName = new Bunifu.Framework.UI.BunifuCustomLabel();
            this.lbPriority = new PresentationLayer.CustomControls.RoundedLabel();
            this.cbStatus = new Bunifu.UI.WinForms.BunifuDropdown();
            this.lbTaskProject = new Bunifu.UI.WinForms.BunifuLabel();
            this.bunifuLabel4 = new Bunifu.UI.WinForms.BunifuLabel();
            this.bunifuLabel3 = new Bunifu.UI.WinForms.BunifuLabel();
            this.btnDocLink = new Bunifu.UI.WinForms.BunifuButton.BunifuButton();
            this.btnAttachment = new Bunifu.UI.WinForms.BunifuButton.BunifuButton();
            this.tbDescription = new Bunifu.UI.WinForms.BunifuTextBox();
            this.lbComment = new Bunifu.UI.WinForms.BunifuLabel();
            this.lbOwner = new System.Windows.Forms.Label();
            this.lbCreatedBy = new System.Windows.Forms.Label();
            this.lbDueDate = new System.Windows.Forms.Label();
            this.labelWithImage1 = new PresentationLayer.Controls.Others.LabelWithImage();
            this.labelWithImage2 = new PresentationLayer.Controls.Others.LabelWithImage();
            this.labelWithImage3 = new PresentationLayer.Controls.Others.LabelWithImage();
            this.labelWithImage4 = new PresentationLayer.Controls.Others.LabelWithImage();
            this.labelWithImage5 = new PresentationLayer.Controls.Others.LabelWithImage();
            this.panel2 = new System.Windows.Forms.Panel();
            this.panelComments = new System.Windows.Forms.FlowLayoutPanel();
            this.bunifuSeparator1 = new Bunifu.UI.WinForms.BunifuSeparator();
            this.bunifuSeparator2 = new Bunifu.UI.WinForms.BunifuSeparator();
            this.tbComment = new Bunifu.UI.WinForms.BunifuTextBox();
            this.btnSendComment = new Bunifu.UI.WinForms.BunifuButton.BunifuButton();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer1)).BeginInit();
            this.splitContainer1.Panel1.SuspendLayout();
            this.splitContainer1.Panel2.SuspendLayout();
            this.splitContainer1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvItems)).BeginInit();
            this.panel1.SuspendLayout();
            this.tableLayoutPanel1.SuspendLayout();
            this.panel2.SuspendLayout();
            this.panelComments.SuspendLayout();
            this.SuspendLayout();
            // 
            // splitContainer1
            // 
            this.splitContainer1.BackColor = System.Drawing.Color.White;
            this.splitContainer1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitContainer1.Location = new System.Drawing.Point(0, 0);
            this.splitContainer1.Name = "splitContainer1";
            // 
            // splitContainer1.Panel1
            // 
            this.splitContainer1.Panel1.Controls.Add(this.dgvItems);
            this.splitContainer1.Panel1.Controls.Add(this.panel1);
            this.splitContainer1.Panel1.Cursor = System.Windows.Forms.Cursors.Default;
            this.splitContainer1.Panel1.Padding = new System.Windows.Forms.Padding(10);
            // 
            // splitContainer1.Panel2
            // 
            this.splitContainer1.Panel2.Controls.Add(this.tableLayoutPanel1);
            this.splitContainer1.Size = new System.Drawing.Size(1347, 931);
            this.splitContainer1.SplitterDistance = 723;
            this.splitContainer1.TabIndex = 0;
            this.splitContainer1.Paint += new System.Windows.Forms.PaintEventHandler(this.splitContainer1_Paint);
            // 
            // dgvItems
            // 
            this.dgvItems.AllowCustomTheming = false;
            dataGridViewCellStyle1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(248)))), ((int)(((byte)(251)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle1.ForeColor = System.Drawing.Color.Black;
            this.dgvItems.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle1;
            this.dgvItems.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgvItems.BackgroundColor = System.Drawing.Color.WhiteSmoke;
            this.dgvItems.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.dgvItems.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.SingleHorizontal;
            this.dgvItems.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle2.BackColor = System.Drawing.Color.DodgerBlue;
            dataGridViewCellStyle2.Font = new System.Drawing.Font("Segoe UI Semibold", 11.75F, System.Drawing.FontStyle.Bold);
            dataGridViewCellStyle2.ForeColor = System.Drawing.Color.White;
            dataGridViewCellStyle2.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(24)))), ((int)(((byte)(115)))), ((int)(((byte)(204)))));
            dataGridViewCellStyle2.SelectionForeColor = System.Drawing.Color.White;
            dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvItems.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle2;
            this.dgvItems.ColumnHeadersHeight = 40;
            this.dgvItems.CurrentTheme.AlternatingRowsStyle.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(248)))), ((int)(((byte)(251)))), ((int)(((byte)(255)))));
            this.dgvItems.CurrentTheme.AlternatingRowsStyle.Font = new System.Drawing.Font("Segoe UI Semibold", 9.75F, System.Drawing.FontStyle.Bold);
            this.dgvItems.CurrentTheme.AlternatingRowsStyle.ForeColor = System.Drawing.Color.Black;
            this.dgvItems.CurrentTheme.AlternatingRowsStyle.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(210)))), ((int)(((byte)(232)))), ((int)(((byte)(255)))));
            this.dgvItems.CurrentTheme.AlternatingRowsStyle.SelectionForeColor = System.Drawing.Color.Black;
            this.dgvItems.CurrentTheme.BackColor = System.Drawing.Color.White;
            this.dgvItems.CurrentTheme.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(221)))), ((int)(((byte)(238)))), ((int)(((byte)(255)))));
            this.dgvItems.CurrentTheme.HeaderStyle.BackColor = System.Drawing.Color.DodgerBlue;
            this.dgvItems.CurrentTheme.HeaderStyle.Font = new System.Drawing.Font("Segoe UI Semibold", 11.75F, System.Drawing.FontStyle.Bold);
            this.dgvItems.CurrentTheme.HeaderStyle.ForeColor = System.Drawing.Color.White;
            this.dgvItems.CurrentTheme.HeaderStyle.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(24)))), ((int)(((byte)(115)))), ((int)(((byte)(204)))));
            this.dgvItems.CurrentTheme.HeaderStyle.SelectionForeColor = System.Drawing.Color.White;
            this.dgvItems.CurrentTheme.Name = null;
            this.dgvItems.CurrentTheme.RowsStyle.BackColor = System.Drawing.Color.White;
            this.dgvItems.CurrentTheme.RowsStyle.Font = new System.Drawing.Font("Segoe UI Semibold", 9.75F, System.Drawing.FontStyle.Bold);
            this.dgvItems.CurrentTheme.RowsStyle.ForeColor = System.Drawing.Color.Black;
            this.dgvItems.CurrentTheme.RowsStyle.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(210)))), ((int)(((byte)(232)))), ((int)(((byte)(255)))));
            this.dgvItems.CurrentTheme.RowsStyle.SelectionForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle3.BackColor = System.Drawing.Color.White;
            dataGridViewCellStyle3.Font = new System.Drawing.Font("Segoe UI Semibold", 9.75F, System.Drawing.FontStyle.Bold);
            dataGridViewCellStyle3.ForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle3.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(210)))), ((int)(((byte)(232)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle3.SelectionForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle3.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dgvItems.DefaultCellStyle = dataGridViewCellStyle3;
            this.dgvItems.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dgvItems.EnableHeadersVisualStyles = false;
            this.dgvItems.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(221)))), ((int)(((byte)(238)))), ((int)(((byte)(255)))));
            this.dgvItems.HeaderBackColor = System.Drawing.Color.DodgerBlue;
            this.dgvItems.HeaderBgColor = System.Drawing.Color.Empty;
            this.dgvItems.HeaderForeColor = System.Drawing.Color.White;
            this.dgvItems.Location = new System.Drawing.Point(10, 99);
            this.dgvItems.Name = "dgvItems";
            this.dgvItems.RowHeadersVisible = false;
            this.dgvItems.RowHeadersWidth = 62;
            this.dgvItems.RowTemplate.Height = 40;
            this.dgvItems.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvItems.Size = new System.Drawing.Size(703, 822);
            this.dgvItems.TabIndex = 8;
            this.dgvItems.Theme = Bunifu.UI.WinForms.BunifuDataGridView.PresetThemes.Light;
            this.dgvItems.SelectionChanged += new System.EventHandler(this.dgvItems_SelectionChanged);
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.White;
            this.panel1.Controls.Add(this.tbSearch);
            this.panel1.Controls.Add(this.roundedLabel1);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel1.Location = new System.Drawing.Point(10, 10);
            this.panel1.Name = "panel1";
            this.panel1.Padding = new System.Windows.Forms.Padding(1, 1, 1, 8);
            this.panel1.Size = new System.Drawing.Size(703, 89);
            this.panel1.TabIndex = 7;
            // 
            // tbSearch
            // 
            this.tbSearch.AcceptsReturn = false;
            this.tbSearch.AcceptsTab = false;
            this.tbSearch.AnimationSpeed = 200;
            this.tbSearch.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.None;
            this.tbSearch.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.None;
            this.tbSearch.AutoSizeHeight = true;
            this.tbSearch.BackColor = System.Drawing.Color.Transparent;
            this.tbSearch.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("tbSearch.BackgroundImage")));
            this.tbSearch.BorderColorActive = System.Drawing.Color.DodgerBlue;
            this.tbSearch.BorderColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(204)))), ((int)(((byte)(204)))));
            this.tbSearch.BorderColorHover = System.Drawing.Color.FromArgb(((int)(((byte)(105)))), ((int)(((byte)(181)))), ((int)(((byte)(255)))));
            this.tbSearch.BorderColorIdle = System.Drawing.Color.Silver;
            this.tbSearch.BorderRadius = 25;
            this.tbSearch.BorderThickness = 1;
            this.tbSearch.CharacterCase = Bunifu.UI.WinForms.BunifuTextBox.CharacterCases.Normal;
            this.tbSearch.CharacterCasing = System.Windows.Forms.CharacterCasing.Normal;
            this.tbSearch.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.tbSearch.DefaultFont = new System.Drawing.Font("Segoe UI", 9.25F);
            this.tbSearch.DefaultText = "";
            this.tbSearch.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tbSearch.FillColor = System.Drawing.Color.White;
            this.tbSearch.HideSelection = true;
            this.tbSearch.IconLeft = null;
            this.tbSearch.IconLeftCursor = System.Windows.Forms.Cursors.IBeam;
            this.tbSearch.IconPadding = 10;
            this.tbSearch.IconRight = null;
            this.tbSearch.IconRightCursor = System.Windows.Forms.Cursors.IBeam;
            this.tbSearch.Lines = new string[0];
            this.tbSearch.Location = new System.Drawing.Point(1, 25);
            this.tbSearch.MaxLength = 32767;
            this.tbSearch.MinimumSize = new System.Drawing.Size(1, 1);
            this.tbSearch.Modified = false;
            this.tbSearch.Multiline = false;
            this.tbSearch.Name = "tbSearch";
            stateProperties1.BorderColor = System.Drawing.Color.DodgerBlue;
            stateProperties1.FillColor = System.Drawing.Color.Empty;
            stateProperties1.ForeColor = System.Drawing.Color.Empty;
            stateProperties1.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.tbSearch.OnActiveState = stateProperties1;
            stateProperties2.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(204)))), ((int)(((byte)(204)))));
            stateProperties2.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(240)))), ((int)(((byte)(240)))), ((int)(((byte)(240)))));
            stateProperties2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            stateProperties2.PlaceholderForeColor = System.Drawing.Color.DarkGray;
            this.tbSearch.OnDisabledState = stateProperties2;
            stateProperties3.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(105)))), ((int)(((byte)(181)))), ((int)(((byte)(255)))));
            stateProperties3.FillColor = System.Drawing.Color.Empty;
            stateProperties3.ForeColor = System.Drawing.Color.Empty;
            stateProperties3.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.tbSearch.OnHoverState = stateProperties3;
            stateProperties4.BorderColor = System.Drawing.Color.Silver;
            stateProperties4.FillColor = System.Drawing.Color.White;
            stateProperties4.ForeColor = System.Drawing.Color.Empty;
            stateProperties4.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.tbSearch.OnIdleState = stateProperties4;
            this.tbSearch.Padding = new System.Windows.Forms.Padding(3);
            this.tbSearch.PasswordChar = '\0';
            this.tbSearch.PlaceholderForeColor = System.Drawing.Color.Silver;
            this.tbSearch.PlaceholderText = "Enter text";
            this.tbSearch.ReadOnly = false;
            this.tbSearch.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.tbSearch.SelectedText = "";
            this.tbSearch.SelectionLength = 0;
            this.tbSearch.SelectionStart = 0;
            this.tbSearch.ShortcutsEnabled = true;
            this.tbSearch.Size = new System.Drawing.Size(701, 56);
            this.tbSearch.Style = Bunifu.UI.WinForms.BunifuTextBox._Style.Bunifu;
            this.tbSearch.TabIndex = 5;
            this.tbSearch.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.tbSearch.TextMarginBottom = 0;
            this.tbSearch.TextMarginLeft = 3;
            this.tbSearch.TextMarginTop = 1;
            this.tbSearch.TextPlaceholder = "Enter text";
            this.tbSearch.UseSystemPasswordChar = false;
            this.tbSearch.WordWrap = true;
            this.tbSearch.KeyDown += new System.Windows.Forms.KeyEventHandler(this.tbSearch_KeyDown);
            // 
            // roundedLabel1
            // 
            this.roundedLabel1._BackColor = System.Drawing.Color.Empty;
            this.roundedLabel1._TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.roundedLabel1.AutoSize = true;
            this.roundedLabel1.Dock = System.Windows.Forms.DockStyle.Top;
            this.roundedLabel1.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold);
            this.roundedLabel1.Location = new System.Drawing.Point(1, 1);
            this.roundedLabel1.Name = "roundedLabel1";
            this.roundedLabel1.Size = new System.Drawing.Size(197, 24);
            this.roundedLabel1.TabIndex = 0;
            this.roundedLabel1.Text = "Task Help Requests";
            // 
            // tableLayoutPanel1
            // 
            this.tableLayoutPanel1.AutoScroll = true;
            this.tableLayoutPanel1.ColumnCount = 3;
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 40.82882F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 58.18108F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 0.990099F));
            this.tableLayoutPanel1.Controls.Add(this.lbName, 0, 1);
            this.tableLayoutPanel1.Controls.Add(this.lbPriority, 1, 2);
            this.tableLayoutPanel1.Controls.Add(this.cbStatus, 1, 3);
            this.tableLayoutPanel1.Controls.Add(this.lbTaskProject, 0, 0);
            this.tableLayoutPanel1.Controls.Add(this.bunifuLabel4, 0, 10);
            this.tableLayoutPanel1.Controls.Add(this.bunifuLabel3, 0, 7);
            this.tableLayoutPanel1.Controls.Add(this.btnDocLink, 0, 8);
            this.tableLayoutPanel1.Controls.Add(this.btnAttachment, 0, 9);
            this.tableLayoutPanel1.Controls.Add(this.tbDescription, 0, 11);
            this.tableLayoutPanel1.Controls.Add(this.lbComment, 0, 12);
            this.tableLayoutPanel1.Controls.Add(this.lbOwner, 1, 4);
            this.tableLayoutPanel1.Controls.Add(this.lbCreatedBy, 1, 5);
            this.tableLayoutPanel1.Controls.Add(this.lbDueDate, 1, 6);
            this.tableLayoutPanel1.Controls.Add(this.labelWithImage1, 0, 2);
            this.tableLayoutPanel1.Controls.Add(this.labelWithImage2, 0, 3);
            this.tableLayoutPanel1.Controls.Add(this.labelWithImage3, 0, 4);
            this.tableLayoutPanel1.Controls.Add(this.labelWithImage4, 0, 5);
            this.tableLayoutPanel1.Controls.Add(this.labelWithImage5, 0, 6);
            this.tableLayoutPanel1.Controls.Add(this.panel2, 0, 13);
            this.tableLayoutPanel1.Controls.Add(this.btnSendComment, 1, 14);
            this.tableLayoutPanel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel1.Location = new System.Drawing.Point(0, 0);
            this.tableLayoutPanel1.Name = "tableLayoutPanel1";
            this.tableLayoutPanel1.RowCount = 16;
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 5F));
            this.tableLayoutPanel1.Size = new System.Drawing.Size(620, 931);
            this.tableLayoutPanel1.TabIndex = 2;
            // 
            // lbName
            // 
            this.lbName.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.tableLayoutPanel1.SetColumnSpan(this.lbName, 2);
            this.lbName.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lbName.Font = new System.Drawing.Font("Segoe UI Semibold", 25F, System.Drawing.FontStyle.Bold);
            this.lbName.Location = new System.Drawing.Point(10, 50);
            this.lbName.Margin = new System.Windows.Forms.Padding(10);
            this.lbName.Name = "lbName";
            this.lbName.Size = new System.Drawing.Size(593, 49);
            this.lbName.TabIndex = 29;
            this.lbName.Text = "Make a Suitable form";
            this.lbName.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // lbPriority
            // 
            this.lbPriority._BackColor = System.Drawing.Color.Empty;
            this.lbPriority._TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lbPriority.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.lbPriority.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbPriority.Location = new System.Drawing.Point(263, 123);
            this.lbPriority.Margin = new System.Windows.Forms.Padding(10);
            this.lbPriority.Name = "lbPriority";
            this.lbPriority.Padding = new System.Windows.Forms.Padding(10, 5, 10, 5);
            this.lbPriority.Size = new System.Drawing.Size(206, 30);
            this.lbPriority.TabIndex = 34;
            this.lbPriority.Text = "Priority";
            this.lbPriority.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // cbStatus
            // 
            this.cbStatus.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.cbStatus.BackColor = System.Drawing.Color.Transparent;
            this.cbStatus.BackgroundColor = System.Drawing.Color.White;
            this.cbStatus.BorderColor = System.Drawing.Color.Silver;
            this.cbStatus.BorderRadius = 17;
            this.cbStatus.Color = System.Drawing.Color.Silver;
            this.cbStatus.Direction = Bunifu.UI.WinForms.BunifuDropdown.Directions.Down;
            this.cbStatus.DisabledBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(240)))), ((int)(((byte)(240)))), ((int)(((byte)(240)))));
            this.cbStatus.DisabledBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(204)))), ((int)(((byte)(204)))));
            this.cbStatus.DisabledColor = System.Drawing.Color.FromArgb(((int)(((byte)(240)))), ((int)(((byte)(240)))), ((int)(((byte)(240)))));
            this.cbStatus.DisabledForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            this.cbStatus.DisabledIndicatorColor = System.Drawing.Color.DarkGray;
            this.cbStatus.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawFixed;
            this.cbStatus.DropdownBorderThickness = Bunifu.UI.WinForms.BunifuDropdown.BorderThickness.Thin;
            this.cbStatus.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbStatus.DropDownTextAlign = Bunifu.UI.WinForms.BunifuDropdown.TextAlign.Left;
            this.cbStatus.FillDropDown = true;
            this.cbStatus.FillIndicator = false;
            this.cbStatus.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.cbStatus.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.cbStatus.ForeColor = System.Drawing.Color.Black;
            this.cbStatus.FormattingEnabled = true;
            this.cbStatus.Icon = null;
            this.cbStatus.IndicatorAlignment = Bunifu.UI.WinForms.BunifuDropdown.Indicator.Right;
            this.cbStatus.IndicatorColor = System.Drawing.Color.DarkGray;
            this.cbStatus.IndicatorLocation = Bunifu.UI.WinForms.BunifuDropdown.Indicator.Right;
            this.cbStatus.IndicatorThickness = 2;
            this.cbStatus.IsDropdownOpened = false;
            this.cbStatus.ItemBackColor = System.Drawing.Color.White;
            this.cbStatus.ItemBorderColor = System.Drawing.Color.White;
            this.cbStatus.ItemForeColor = System.Drawing.Color.Black;
            this.cbStatus.ItemHeight = 26;
            this.cbStatus.ItemHighLightColor = System.Drawing.Color.DodgerBlue;
            this.cbStatus.ItemHighLightForeColor = System.Drawing.Color.White;
            this.cbStatus.ItemTopMargin = 3;
            this.cbStatus.Location = new System.Drawing.Point(256, 181);
            this.cbStatus.Name = "cbStatus";
            this.cbStatus.Size = new System.Drawing.Size(180, 32);
            this.cbStatus.TabIndex = 33;
            this.cbStatus.Text = null;
            this.cbStatus.TextAlignment = Bunifu.UI.WinForms.BunifuDropdown.TextAlign.Left;
            this.cbStatus.TextLeftMargin = 5;
            // 
            // lbTaskProject
            // 
            this.lbTaskProject.AllowParentOverrides = false;
            this.lbTaskProject.AutoEllipsis = false;
            this.lbTaskProject.AutoSize = false;
            this.lbTaskProject.AutoSizeHeightOnly = true;
            this.lbTaskProject.Cursor = System.Windows.Forms.Cursors.Default;
            this.lbTaskProject.CursorType = System.Windows.Forms.Cursors.Default;
            this.lbTaskProject.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lbTaskProject.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.lbTaskProject.ForeColor = System.Drawing.SystemColors.ButtonShadow;
            this.lbTaskProject.Location = new System.Drawing.Point(10, 10);
            this.lbTaskProject.Margin = new System.Windows.Forms.Padding(10);
            this.lbTaskProject.Name = "lbTaskProject";
            this.lbTaskProject.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.lbTaskProject.Size = new System.Drawing.Size(233, 20);
            this.lbTaskProject.TabIndex = 0;
            this.lbTaskProject.Text = "Project / TaskID - 1234";
            this.lbTaskProject.TextAlignment = System.Drawing.ContentAlignment.TopLeft;
            this.lbTaskProject.TextFormat = Bunifu.UI.WinForms.BunifuLabel.TextFormattingOptions.Default;
            // 
            // bunifuLabel4
            // 
            this.bunifuLabel4.AllowParentOverrides = false;
            this.bunifuLabel4.AutoEllipsis = false;
            this.bunifuLabel4.AutoSize = false;
            this.tableLayoutPanel1.SetColumnSpan(this.bunifuLabel4, 2);
            this.bunifuLabel4.CursorType = null;
            this.bunifuLabel4.Dock = System.Windows.Forms.DockStyle.Fill;
            this.bunifuLabel4.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold);
            this.bunifuLabel4.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.bunifuLabel4.Location = new System.Drawing.Point(10, 577);
            this.bunifuLabel4.Margin = new System.Windows.Forms.Padding(10);
            this.bunifuLabel4.Name = "bunifuLabel4";
            this.bunifuLabel4.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.bunifuLabel4.Size = new System.Drawing.Size(593, 25);
            this.bunifuLabel4.TabIndex = 12;
            this.bunifuLabel4.Text = "Description";
            this.bunifuLabel4.TextAlignment = System.Drawing.ContentAlignment.TopLeft;
            this.bunifuLabel4.TextFormat = Bunifu.UI.WinForms.BunifuLabel.TextFormattingOptions.Default;
            // 
            // bunifuLabel3
            // 
            this.bunifuLabel3.AllowParentOverrides = false;
            this.bunifuLabel3.AutoEllipsis = false;
            this.bunifuLabel3.AutoSize = false;
            this.tableLayoutPanel1.SetColumnSpan(this.bunifuLabel3, 2);
            this.bunifuLabel3.CursorType = null;
            this.bunifuLabel3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.bunifuLabel3.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold);
            this.bunifuLabel3.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.bunifuLabel3.Location = new System.Drawing.Point(10, 414);
            this.bunifuLabel3.Margin = new System.Windows.Forms.Padding(10);
            this.bunifuLabel3.Name = "bunifuLabel3";
            this.bunifuLabel3.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.bunifuLabel3.Size = new System.Drawing.Size(593, 25);
            this.bunifuLabel3.TabIndex = 12;
            this.bunifuLabel3.Text = "Attachment";
            this.bunifuLabel3.TextAlignment = System.Drawing.ContentAlignment.TopLeft;
            this.bunifuLabel3.TextFormat = Bunifu.UI.WinForms.BunifuLabel.TextFormattingOptions.Default;
            // 
            // btnDocLink
            // 
            this.btnDocLink.AllowAnimations = true;
            this.btnDocLink.AllowMouseEffects = true;
            this.btnDocLink.AllowToggling = false;
            this.btnDocLink.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.btnDocLink.AnimationSpeed = 200;
            this.btnDocLink.AutoGenerateColors = false;
            this.btnDocLink.AutoRoundBorders = false;
            this.btnDocLink.AutoSizeLeftIcon = true;
            this.btnDocLink.AutoSizeRightIcon = true;
            this.btnDocLink.BackColor = System.Drawing.Color.Transparent;
            this.btnDocLink.BackColor1 = System.Drawing.Color.FromArgb(((int)(((byte)(51)))), ((int)(((byte)(122)))), ((int)(((byte)(183)))));
            this.btnDocLink.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnDocLink.BackgroundImage")));
            this.btnDocLink.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
            this.btnDocLink.ButtonText = "Ducument Links";
            this.btnDocLink.ButtonTextMarginLeft = 0;
            this.btnDocLink.ColorContrastOnClick = 45;
            this.btnDocLink.ColorContrastOnHover = 45;
            this.btnDocLink.Cursor = System.Windows.Forms.Cursors.Default;
            borderEdges1.BottomLeft = true;
            borderEdges1.BottomRight = true;
            borderEdges1.TopLeft = true;
            borderEdges1.TopRight = true;
            this.btnDocLink.CustomizableEdges = borderEdges1;
            this.btnDocLink.DialogResult = System.Windows.Forms.DialogResult.None;
            this.btnDocLink.DisabledBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(191)))), ((int)(((byte)(191)))), ((int)(((byte)(191)))));
            this.btnDocLink.DisabledFillColor = System.Drawing.Color.Empty;
            this.btnDocLink.DisabledForecolor = System.Drawing.Color.Empty;
            this.btnDocLink.FocusState = Bunifu.UI.WinForms.BunifuButton.BunifuButton.ButtonStates.Pressed;
            this.btnDocLink.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnDocLink.ForeColor = System.Drawing.Color.Black;
            this.btnDocLink.IconLeft = ((System.Drawing.Image)(resources.GetObject("btnDocLink.IconLeft")));
            this.btnDocLink.IconLeftAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnDocLink.IconLeftCursor = System.Windows.Forms.Cursors.Default;
            this.btnDocLink.IconLeftPadding = new System.Windows.Forms.Padding(11, 3, 3, 3);
            this.btnDocLink.IconMarginLeft = 11;
            this.btnDocLink.IconPadding = 10;
            this.btnDocLink.IconRight = null;
            this.btnDocLink.IconRightAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnDocLink.IconRightCursor = System.Windows.Forms.Cursors.Default;
            this.btnDocLink.IconRightPadding = new System.Windows.Forms.Padding(3, 3, 7, 3);
            this.btnDocLink.IconSize = 25;
            this.btnDocLink.IdleBorderColor = System.Drawing.Color.Empty;
            this.btnDocLink.IdleBorderRadius = 0;
            this.btnDocLink.IdleBorderThickness = 0;
            this.btnDocLink.IdleFillColor = System.Drawing.Color.Empty;
            this.btnDocLink.IdleIconLeftImage = ((System.Drawing.Image)(resources.GetObject("btnDocLink.IdleIconLeftImage")));
            this.btnDocLink.IdleIconRightImage = null;
            this.btnDocLink.IndicateFocus = false;
            this.btnDocLink.Location = new System.Drawing.Point(10, 459);
            this.btnDocLink.Margin = new System.Windows.Forms.Padding(10);
            this.btnDocLink.Name = "btnDocLink";
            this.btnDocLink.OnDisabledState.BorderColor = System.Drawing.Color.Transparent;
            this.btnDocLink.OnDisabledState.BorderRadius = 1;
            this.btnDocLink.OnDisabledState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
            this.btnDocLink.OnDisabledState.BorderThickness = 1;
            this.btnDocLink.OnDisabledState.FillColor = System.Drawing.Color.Transparent;
            this.btnDocLink.OnDisabledState.ForeColor = System.Drawing.Color.Black;
            this.btnDocLink.OnDisabledState.IconLeftImage = null;
            this.btnDocLink.OnDisabledState.IconRightImage = null;
            this.btnDocLink.onHoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(150)))), ((int)(((byte)(255)))));
            this.btnDocLink.onHoverState.BorderRadius = 1;
            this.btnDocLink.onHoverState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
            this.btnDocLink.onHoverState.BorderThickness = 1;
            this.btnDocLink.onHoverState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(150)))), ((int)(((byte)(255)))));
            this.btnDocLink.onHoverState.ForeColor = System.Drawing.Color.White;
            this.btnDocLink.onHoverState.IconLeftImage = null;
            this.btnDocLink.onHoverState.IconRightImage = null;
            this.btnDocLink.OnIdleState.BorderColor = System.Drawing.Color.Transparent;
            this.btnDocLink.OnIdleState.BorderRadius = 1;
            this.btnDocLink.OnIdleState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
            this.btnDocLink.OnIdleState.BorderThickness = 1;
            this.btnDocLink.OnIdleState.FillColor = System.Drawing.Color.White;
            this.btnDocLink.OnIdleState.ForeColor = System.Drawing.Color.Black;
            this.btnDocLink.OnIdleState.IconLeftImage = ((System.Drawing.Image)(resources.GetObject("btnDocLink.OnIdleState.IconLeftImage")));
            this.btnDocLink.OnIdleState.IconRightImage = null;
            this.btnDocLink.OnPressedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(96)))), ((int)(((byte)(144)))));
            this.btnDocLink.OnPressedState.BorderRadius = 1;
            this.btnDocLink.OnPressedState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
            this.btnDocLink.OnPressedState.BorderThickness = 1;
            this.btnDocLink.OnPressedState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(96)))), ((int)(((byte)(144)))));
            this.btnDocLink.OnPressedState.ForeColor = System.Drawing.Color.White;
            this.btnDocLink.OnPressedState.IconLeftImage = null;
            this.btnDocLink.OnPressedState.IconRightImage = null;
            this.btnDocLink.Size = new System.Drawing.Size(166, 39);
            this.btnDocLink.TabIndex = 1;
            this.btnDocLink.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnDocLink.TextAlignment = System.Windows.Forms.HorizontalAlignment.Center;
            this.btnDocLink.TextMarginLeft = 0;
            this.btnDocLink.TextPadding = new System.Windows.Forms.Padding(0);
            this.btnDocLink.UseDefaultRadiusAndThickness = true;
            // 
            // btnAttachment
            // 
            this.btnAttachment.AllowAnimations = true;
            this.btnAttachment.AllowMouseEffects = true;
            this.btnAttachment.AllowToggling = false;
            this.btnAttachment.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.btnAttachment.AnimationSpeed = 200;
            this.btnAttachment.AutoGenerateColors = false;
            this.btnAttachment.AutoRoundBorders = false;
            this.btnAttachment.AutoSizeLeftIcon = true;
            this.btnAttachment.AutoSizeRightIcon = true;
            this.btnAttachment.BackColor = System.Drawing.Color.Transparent;
            this.btnAttachment.BackColor1 = System.Drawing.Color.FromArgb(((int)(((byte)(51)))), ((int)(((byte)(122)))), ((int)(((byte)(183)))));
            this.btnAttachment.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnAttachment.BackgroundImage")));
            this.btnAttachment.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
            this.btnAttachment.ButtonText = "Add Attachment";
            this.btnAttachment.ButtonTextMarginLeft = 0;
            this.btnAttachment.ColorContrastOnClick = 45;
            this.btnAttachment.ColorContrastOnHover = 45;
            this.btnAttachment.Cursor = System.Windows.Forms.Cursors.Default;
            borderEdges2.BottomLeft = true;
            borderEdges2.BottomRight = true;
            borderEdges2.TopLeft = true;
            borderEdges2.TopRight = true;
            this.btnAttachment.CustomizableEdges = borderEdges2;
            this.btnAttachment.DialogResult = System.Windows.Forms.DialogResult.None;
            this.btnAttachment.DisabledBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(191)))), ((int)(((byte)(191)))), ((int)(((byte)(191)))));
            this.btnAttachment.DisabledFillColor = System.Drawing.Color.Empty;
            this.btnAttachment.DisabledForecolor = System.Drawing.Color.Empty;
            this.btnAttachment.FocusState = Bunifu.UI.WinForms.BunifuButton.BunifuButton.ButtonStates.Pressed;
            this.btnAttachment.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAttachment.ForeColor = System.Drawing.Color.Black;
            this.btnAttachment.IconLeft = ((System.Drawing.Image)(resources.GetObject("btnAttachment.IconLeft")));
            this.btnAttachment.IconLeftAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnAttachment.IconLeftCursor = System.Windows.Forms.Cursors.Default;
            this.btnAttachment.IconLeftPadding = new System.Windows.Forms.Padding(11, 3, 3, 3);
            this.btnAttachment.IconMarginLeft = 11;
            this.btnAttachment.IconPadding = 10;
            this.btnAttachment.IconRight = null;
            this.btnAttachment.IconRightAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnAttachment.IconRightCursor = System.Windows.Forms.Cursors.Default;
            this.btnAttachment.IconRightPadding = new System.Windows.Forms.Padding(3, 3, 7, 3);
            this.btnAttachment.IconSize = 25;
            this.btnAttachment.IdleBorderColor = System.Drawing.Color.Empty;
            this.btnAttachment.IdleBorderRadius = 0;
            this.btnAttachment.IdleBorderThickness = 0;
            this.btnAttachment.IdleFillColor = System.Drawing.Color.Empty;
            this.btnAttachment.IdleIconLeftImage = ((System.Drawing.Image)(resources.GetObject("btnAttachment.IdleIconLeftImage")));
            this.btnAttachment.IdleIconRightImage = null;
            this.btnAttachment.IndicateFocus = false;
            this.btnAttachment.Location = new System.Drawing.Point(10, 518);
            this.btnAttachment.Margin = new System.Windows.Forms.Padding(10);
            this.btnAttachment.Name = "btnAttachment";
            this.btnAttachment.OnDisabledState.BorderColor = System.Drawing.Color.Transparent;
            this.btnAttachment.OnDisabledState.BorderRadius = 1;
            this.btnAttachment.OnDisabledState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
            this.btnAttachment.OnDisabledState.BorderThickness = 1;
            this.btnAttachment.OnDisabledState.FillColor = System.Drawing.Color.Transparent;
            this.btnAttachment.OnDisabledState.ForeColor = System.Drawing.Color.Black;
            this.btnAttachment.OnDisabledState.IconLeftImage = null;
            this.btnAttachment.OnDisabledState.IconRightImage = null;
            this.btnAttachment.onHoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(150)))), ((int)(((byte)(255)))));
            this.btnAttachment.onHoverState.BorderRadius = 1;
            this.btnAttachment.onHoverState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
            this.btnAttachment.onHoverState.BorderThickness = 1;
            this.btnAttachment.onHoverState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(150)))), ((int)(((byte)(255)))));
            this.btnAttachment.onHoverState.ForeColor = System.Drawing.Color.White;
            this.btnAttachment.onHoverState.IconLeftImage = null;
            this.btnAttachment.onHoverState.IconRightImage = null;
            this.btnAttachment.OnIdleState.BorderColor = System.Drawing.Color.Transparent;
            this.btnAttachment.OnIdleState.BorderRadius = 1;
            this.btnAttachment.OnIdleState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
            this.btnAttachment.OnIdleState.BorderThickness = 1;
            this.btnAttachment.OnIdleState.FillColor = System.Drawing.Color.White;
            this.btnAttachment.OnIdleState.ForeColor = System.Drawing.Color.Black;
            this.btnAttachment.OnIdleState.IconLeftImage = ((System.Drawing.Image)(resources.GetObject("btnAttachment.OnIdleState.IconLeftImage")));
            this.btnAttachment.OnIdleState.IconRightImage = null;
            this.btnAttachment.OnPressedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(96)))), ((int)(((byte)(144)))));
            this.btnAttachment.OnPressedState.BorderRadius = 1;
            this.btnAttachment.OnPressedState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
            this.btnAttachment.OnPressedState.BorderThickness = 1;
            this.btnAttachment.OnPressedState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(96)))), ((int)(((byte)(144)))));
            this.btnAttachment.OnPressedState.ForeColor = System.Drawing.Color.White;
            this.btnAttachment.OnPressedState.IconLeftImage = null;
            this.btnAttachment.OnPressedState.IconRightImage = null;
            this.btnAttachment.Size = new System.Drawing.Size(166, 39);
            this.btnAttachment.TabIndex = 1;
            this.btnAttachment.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnAttachment.TextAlignment = System.Windows.Forms.HorizontalAlignment.Center;
            this.btnAttachment.TextMarginLeft = 0;
            this.btnAttachment.TextPadding = new System.Windows.Forms.Padding(0);
            this.btnAttachment.UseDefaultRadiusAndThickness = true;
            // 
            // tbDescription
            // 
            this.tbDescription.AcceptsReturn = false;
            this.tbDescription.AcceptsTab = false;
            this.tbDescription.AnimationSpeed = 200;
            this.tbDescription.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.None;
            this.tbDescription.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.None;
            this.tbDescription.AutoSizeHeight = true;
            this.tbDescription.BackColor = System.Drawing.Color.Transparent;
            this.tbDescription.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("tbDescription.BackgroundImage")));
            this.tbDescription.BorderColorActive = System.Drawing.Color.DodgerBlue;
            this.tbDescription.BorderColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(204)))), ((int)(((byte)(204)))));
            this.tbDescription.BorderColorHover = System.Drawing.Color.FromArgb(((int)(((byte)(105)))), ((int)(((byte)(181)))), ((int)(((byte)(255)))));
            this.tbDescription.BorderColorIdle = System.Drawing.Color.Silver;
            this.tbDescription.BorderRadius = 25;
            this.tbDescription.BorderThickness = 1;
            this.tbDescription.CharacterCase = Bunifu.UI.WinForms.BunifuTextBox.CharacterCases.Normal;
            this.tbDescription.CharacterCasing = System.Windows.Forms.CharacterCasing.Normal;
            this.tableLayoutPanel1.SetColumnSpan(this.tbDescription, 2);
            this.tbDescription.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.tbDescription.DefaultFont = new System.Drawing.Font("Segoe UI", 9.25F);
            this.tbDescription.DefaultText = "";
            this.tbDescription.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tbDescription.FillColor = System.Drawing.Color.White;
            this.tbDescription.HideSelection = true;
            this.tbDescription.IconLeft = null;
            this.tbDescription.IconLeftCursor = System.Windows.Forms.Cursors.IBeam;
            this.tbDescription.IconPadding = 10;
            this.tbDescription.IconRight = null;
            this.tbDescription.IconRightCursor = System.Windows.Forms.Cursors.IBeam;
            this.tbDescription.Lines = new string[0];
            this.tbDescription.Location = new System.Drawing.Point(10, 622);
            this.tbDescription.Margin = new System.Windows.Forms.Padding(10);
            this.tbDescription.MaxLength = 32767;
            this.tbDescription.MinimumSize = new System.Drawing.Size(1, 1);
            this.tbDescription.Modified = false;
            this.tbDescription.Multiline = true;
            this.tbDescription.Name = "tbDescription";
            stateProperties5.BorderColor = System.Drawing.Color.DodgerBlue;
            stateProperties5.FillColor = System.Drawing.Color.Empty;
            stateProperties5.ForeColor = System.Drawing.Color.Empty;
            stateProperties5.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.tbDescription.OnActiveState = stateProperties5;
            stateProperties6.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(204)))), ((int)(((byte)(204)))));
            stateProperties6.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(240)))), ((int)(((byte)(240)))), ((int)(((byte)(240)))));
            stateProperties6.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            stateProperties6.PlaceholderForeColor = System.Drawing.Color.DarkGray;
            this.tbDescription.OnDisabledState = stateProperties6;
            stateProperties7.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(105)))), ((int)(((byte)(181)))), ((int)(((byte)(255)))));
            stateProperties7.FillColor = System.Drawing.Color.Empty;
            stateProperties7.ForeColor = System.Drawing.Color.Empty;
            stateProperties7.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.tbDescription.OnHoverState = stateProperties7;
            stateProperties8.BorderColor = System.Drawing.Color.Silver;
            stateProperties8.FillColor = System.Drawing.Color.White;
            stateProperties8.ForeColor = System.Drawing.Color.Empty;
            stateProperties8.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.tbDescription.OnIdleState = stateProperties8;
            this.tbDescription.Padding = new System.Windows.Forms.Padding(10);
            this.tbDescription.PasswordChar = '\0';
            this.tbDescription.PlaceholderForeColor = System.Drawing.Color.Silver;
            this.tbDescription.PlaceholderText = "Enter text";
            this.tbDescription.ReadOnly = false;
            this.tbDescription.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.tbDescription.SelectedText = "";
            this.tbDescription.SelectionLength = 0;
            this.tbDescription.SelectionStart = 0;
            this.tbDescription.ShortcutsEnabled = true;
            this.tbDescription.Size = new System.Drawing.Size(593, 52);
            this.tbDescription.Style = Bunifu.UI.WinForms.BunifuTextBox._Style.Bunifu;
            this.tbDescription.TabIndex = 13;
            this.tbDescription.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.tbDescription.TextMarginBottom = 0;
            this.tbDescription.TextMarginLeft = 3;
            this.tbDescription.TextMarginTop = 1;
            this.tbDescription.TextPlaceholder = "Enter text";
            this.tbDescription.UseSystemPasswordChar = false;
            this.tbDescription.WordWrap = true;
            // 
            // lbComment
            // 
            this.lbComment.AllowParentOverrides = false;
            this.lbComment.AutoEllipsis = false;
            this.lbComment.AutoSize = false;
            this.lbComment.CursorType = null;
            this.lbComment.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lbComment.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold);
            this.lbComment.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.lbComment.Location = new System.Drawing.Point(10, 694);
            this.lbComment.Margin = new System.Windows.Forms.Padding(10);
            this.lbComment.Name = "lbComment";
            this.lbComment.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.lbComment.Size = new System.Drawing.Size(233, 25);
            this.lbComment.TabIndex = 12;
            this.lbComment.Text = " Comments";
            this.lbComment.TextAlignment = System.Drawing.ContentAlignment.TopLeft;
            this.lbComment.TextFormat = Bunifu.UI.WinForms.BunifuLabel.TextFormattingOptions.Default;
            // 
            // lbOwner
            // 
            this.lbOwner.AutoSize = true;
            this.lbOwner.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lbOwner.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbOwner.Location = new System.Drawing.Point(256, 227);
            this.lbOwner.Name = "lbOwner";
            this.lbOwner.Size = new System.Drawing.Size(354, 59);
            this.lbOwner.TabIndex = 20;
            this.lbOwner.Text = "label2";
            this.lbOwner.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // lbCreatedBy
            // 
            this.lbCreatedBy.AutoSize = true;
            this.lbCreatedBy.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lbCreatedBy.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbCreatedBy.Location = new System.Drawing.Point(256, 286);
            this.lbCreatedBy.Name = "lbCreatedBy";
            this.lbCreatedBy.Size = new System.Drawing.Size(354, 59);
            this.lbCreatedBy.TabIndex = 19;
            this.lbCreatedBy.Text = "lbComment";
            this.lbCreatedBy.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // lbDueDate
            // 
            this.lbDueDate.AutoSize = true;
            this.lbDueDate.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lbDueDate.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbDueDate.Location = new System.Drawing.Point(256, 345);
            this.lbDueDate.Name = "lbDueDate";
            this.lbDueDate.Size = new System.Drawing.Size(354, 59);
            this.lbDueDate.TabIndex = 21;
            this.lbDueDate.Text = "label3";
            this.lbDueDate.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // labelWithImage1
            // 
            this.labelWithImage1.Image = global::PresentationLayer.Properties.Resources.priority;
            this.labelWithImage1.Location = new System.Drawing.Point(10, 119);
            this.labelWithImage1.Margin = new System.Windows.Forms.Padding(10);
            this.labelWithImage1.Name = "labelWithImage1";
            this.labelWithImage1.Size = new System.Drawing.Size(166, 39);
            this.labelWithImage1.TabIndex = 35;
            this.labelWithImage1.TextLabel = "Priority";
            // 
            // labelWithImage2
            // 
            this.labelWithImage2.Image = global::PresentationLayer.Properties.Resources.status;
            this.labelWithImage2.Location = new System.Drawing.Point(10, 178);
            this.labelWithImage2.Margin = new System.Windows.Forms.Padding(10);
            this.labelWithImage2.Name = "labelWithImage2";
            this.labelWithImage2.Size = new System.Drawing.Size(166, 39);
            this.labelWithImage2.TabIndex = 35;
            this.labelWithImage2.TextLabel = "Status";
            // 
            // labelWithImage3
            // 
            this.labelWithImage3.Image = global::PresentationLayer.Properties.Resources.owner;
            this.labelWithImage3.Location = new System.Drawing.Point(10, 237);
            this.labelWithImage3.Margin = new System.Windows.Forms.Padding(10);
            this.labelWithImage3.Name = "labelWithImage3";
            this.labelWithImage3.Size = new System.Drawing.Size(166, 39);
            this.labelWithImage3.TabIndex = 35;
            this.labelWithImage3.TextLabel = "Owner";
            // 
            // labelWithImage4
            // 
            this.labelWithImage4.Image = global::PresentationLayer.Properties.Resources.createBy;
            this.labelWithImage4.Location = new System.Drawing.Point(10, 296);
            this.labelWithImage4.Margin = new System.Windows.Forms.Padding(10);
            this.labelWithImage4.Name = "labelWithImage4";
            this.labelWithImage4.Size = new System.Drawing.Size(166, 39);
            this.labelWithImage4.TabIndex = 35;
            this.labelWithImage4.TextLabel = "Create By";
            // 
            // labelWithImage5
            // 
            this.labelWithImage5.Image = global::PresentationLayer.Properties.Resources.dueDate;
            this.labelWithImage5.Location = new System.Drawing.Point(10, 355);
            this.labelWithImage5.Margin = new System.Windows.Forms.Padding(10);
            this.labelWithImage5.Name = "labelWithImage5";
            this.labelWithImage5.Size = new System.Drawing.Size(166, 39);
            this.labelWithImage5.TabIndex = 35;
            this.labelWithImage5.TextLabel = "Due Date";
            // 
            // panel2
            // 
            this.tableLayoutPanel1.SetColumnSpan(this.panel2, 2);
            this.panel2.Controls.Add(this.panelComments);
            this.panel2.Controls.Add(this.tbComment);
            this.panel2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel2.Location = new System.Drawing.Point(3, 732);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(607, 278);
            this.panel2.TabIndex = 37;
            // 
            // panelComments
            // 
            this.panelComments.AutoScroll = true;
            this.panelComments.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panelComments.Controls.Add(this.bunifuSeparator1);
            this.panelComments.Controls.Add(this.bunifuSeparator2);
            this.panelComments.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panelComments.FlowDirection = System.Windows.Forms.FlowDirection.TopDown;
            this.panelComments.Location = new System.Drawing.Point(0, 0);
            this.panelComments.Name = "panelComments";
            this.panelComments.Size = new System.Drawing.Size(607, 219);
            this.panelComments.TabIndex = 41;
            this.panelComments.WrapContents = false;
            // 
            // bunifuSeparator1
            // 
            this.bunifuSeparator1.BackColor = System.Drawing.Color.Transparent;
            this.bunifuSeparator1.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("bunifuSeparator1.BackgroundImage")));
            this.bunifuSeparator1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.bunifuSeparator1.DashCap = Bunifu.UI.WinForms.BunifuSeparator.CapStyles.Flat;
            this.bunifuSeparator1.LineColor = System.Drawing.Color.Transparent;
            this.bunifuSeparator1.LineStyle = Bunifu.UI.WinForms.BunifuSeparator.LineStyles.Solid;
            this.bunifuSeparator1.LineThickness = 1;
            this.bunifuSeparator1.Location = new System.Drawing.Point(0, 0);
            this.bunifuSeparator1.Margin = new System.Windows.Forms.Padding(0);
            this.bunifuSeparator1.Name = "bunifuSeparator1";
            this.bunifuSeparator1.Orientation = Bunifu.UI.WinForms.BunifuSeparator.LineOrientation.Horizontal;
            this.bunifuSeparator1.Size = new System.Drawing.Size(587, 0);
            this.bunifuSeparator1.TabIndex = 0;
            // 
            // bunifuSeparator2
            // 
            this.bunifuSeparator2.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.bunifuSeparator2.BackColor = System.Drawing.Color.Transparent;
            this.bunifuSeparator2.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("bunifuSeparator2.BackgroundImage")));
            this.bunifuSeparator2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.bunifuSeparator2.DashCap = Bunifu.UI.WinForms.BunifuSeparator.CapStyles.Flat;
            this.bunifuSeparator2.LineColor = System.Drawing.Color.Transparent;
            this.bunifuSeparator2.LineStyle = Bunifu.UI.WinForms.BunifuSeparator.LineStyles.Solid;
            this.bunifuSeparator2.LineThickness = 1;
            this.bunifuSeparator2.Location = new System.Drawing.Point(0, 0);
            this.bunifuSeparator2.Margin = new System.Windows.Forms.Padding(0);
            this.bunifuSeparator2.Name = "bunifuSeparator2";
            this.bunifuSeparator2.Orientation = Bunifu.UI.WinForms.BunifuSeparator.LineOrientation.Horizontal;
            this.bunifuSeparator2.Size = new System.Drawing.Size(587, 0);
            this.bunifuSeparator2.TabIndex = 1;
            // 
            // tbComment
            // 
            this.tbComment.AcceptsReturn = false;
            this.tbComment.AcceptsTab = false;
            this.tbComment.AnimationSpeed = 200;
            this.tbComment.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.None;
            this.tbComment.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.None;
            this.tbComment.AutoSizeHeight = true;
            this.tbComment.BackColor = System.Drawing.Color.Transparent;
            this.tbComment.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("tbComment.BackgroundImage")));
            this.tbComment.BorderColorActive = System.Drawing.Color.DodgerBlue;
            this.tbComment.BorderColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(204)))), ((int)(((byte)(204)))));
            this.tbComment.BorderColorHover = System.Drawing.Color.FromArgb(((int)(((byte)(105)))), ((int)(((byte)(181)))), ((int)(((byte)(255)))));
            this.tbComment.BorderColorIdle = System.Drawing.Color.Silver;
            this.tbComment.BorderRadius = 25;
            this.tbComment.BorderThickness = 1;
            this.tbComment.CharacterCase = Bunifu.UI.WinForms.BunifuTextBox.CharacterCases.Normal;
            this.tbComment.CharacterCasing = System.Windows.Forms.CharacterCasing.Normal;
            this.tbComment.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.tbComment.DefaultFont = new System.Drawing.Font("Segoe UI", 9.25F);
            this.tbComment.DefaultText = "";
            this.tbComment.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.tbComment.FillColor = System.Drawing.Color.White;
            this.tbComment.HideSelection = true;
            this.tbComment.IconLeft = null;
            this.tbComment.IconLeftCursor = System.Windows.Forms.Cursors.IBeam;
            this.tbComment.IconPadding = 10;
            this.tbComment.IconRight = null;
            this.tbComment.IconRightCursor = System.Windows.Forms.Cursors.IBeam;
            this.tbComment.Lines = new string[0];
            this.tbComment.Location = new System.Drawing.Point(0, 219);
            this.tbComment.Margin = new System.Windows.Forms.Padding(10);
            this.tbComment.MaxLength = 32767;
            this.tbComment.MinimumSize = new System.Drawing.Size(1, 1);
            this.tbComment.Modified = false;
            this.tbComment.Multiline = true;
            this.tbComment.Name = "tbComment";
            stateProperties9.BorderColor = System.Drawing.Color.DodgerBlue;
            stateProperties9.FillColor = System.Drawing.Color.Empty;
            stateProperties9.ForeColor = System.Drawing.Color.Empty;
            stateProperties9.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.tbComment.OnActiveState = stateProperties9;
            stateProperties10.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(204)))), ((int)(((byte)(204)))));
            stateProperties10.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(240)))), ((int)(((byte)(240)))), ((int)(((byte)(240)))));
            stateProperties10.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            stateProperties10.PlaceholderForeColor = System.Drawing.Color.DarkGray;
            this.tbComment.OnDisabledState = stateProperties10;
            stateProperties11.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(105)))), ((int)(((byte)(181)))), ((int)(((byte)(255)))));
            stateProperties11.FillColor = System.Drawing.Color.Empty;
            stateProperties11.ForeColor = System.Drawing.Color.Empty;
            stateProperties11.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.tbComment.OnHoverState = stateProperties11;
            stateProperties12.BorderColor = System.Drawing.Color.Silver;
            stateProperties12.FillColor = System.Drawing.Color.White;
            stateProperties12.ForeColor = System.Drawing.Color.Empty;
            stateProperties12.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.tbComment.OnIdleState = stateProperties12;
            this.tbComment.Padding = new System.Windows.Forms.Padding(10);
            this.tbComment.PasswordChar = '\0';
            this.tbComment.PlaceholderForeColor = System.Drawing.Color.Silver;
            this.tbComment.PlaceholderText = "Enter text";
            this.tbComment.ReadOnly = false;
            this.tbComment.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.tbComment.SelectedText = "";
            this.tbComment.SelectionLength = 0;
            this.tbComment.SelectionStart = 0;
            this.tbComment.ShortcutsEnabled = true;
            this.tbComment.Size = new System.Drawing.Size(607, 59);
            this.tbComment.Style = Bunifu.UI.WinForms.BunifuTextBox._Style.Bunifu;
            this.tbComment.TabIndex = 40;
            this.tbComment.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.tbComment.TextMarginBottom = 0;
            this.tbComment.TextMarginLeft = 3;
            this.tbComment.TextMarginTop = 1;
            this.tbComment.TextPlaceholder = "Enter text";
            this.tbComment.UseSystemPasswordChar = false;
            this.tbComment.WordWrap = true;
            // 
            // btnSendComment
            // 
            this.btnSendComment.AllowAnimations = true;
            this.btnSendComment.AllowMouseEffects = true;
            this.btnSendComment.AllowToggling = false;
            this.btnSendComment.AnimationSpeed = 200;
            this.btnSendComment.AutoGenerateColors = false;
            this.btnSendComment.AutoRoundBorders = false;
            this.btnSendComment.AutoSizeLeftIcon = true;
            this.btnSendComment.AutoSizeRightIcon = true;
            this.btnSendComment.BackColor = System.Drawing.Color.Transparent;
            this.btnSendComment.BackColor1 = System.Drawing.Color.FromArgb(((int)(((byte)(51)))), ((int)(((byte)(122)))), ((int)(((byte)(183)))));
            this.btnSendComment.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnSendComment.BackgroundImage")));
            this.btnSendComment.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
            this.btnSendComment.ButtonText = "Send";
            this.btnSendComment.ButtonTextMarginLeft = 0;
            this.btnSendComment.ColorContrastOnClick = 45;
            this.btnSendComment.ColorContrastOnHover = 45;
            this.btnSendComment.Cursor = System.Windows.Forms.Cursors.Default;
            borderEdges3.BottomLeft = true;
            borderEdges3.BottomRight = true;
            borderEdges3.TopLeft = true;
            borderEdges3.TopRight = true;
            this.btnSendComment.CustomizableEdges = borderEdges3;
            this.btnSendComment.DialogResult = System.Windows.Forms.DialogResult.None;
            this.btnSendComment.DisabledBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(191)))), ((int)(((byte)(191)))), ((int)(((byte)(191)))));
            this.btnSendComment.DisabledFillColor = System.Drawing.Color.Empty;
            this.btnSendComment.DisabledForecolor = System.Drawing.Color.Empty;
            this.btnSendComment.FocusState = Bunifu.UI.WinForms.BunifuButton.BunifuButton.ButtonStates.Pressed;
            this.btnSendComment.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSendComment.ForeColor = System.Drawing.Color.Black;
            this.btnSendComment.IconLeft = null;
            this.btnSendComment.IconLeftAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnSendComment.IconLeftCursor = System.Windows.Forms.Cursors.Default;
            this.btnSendComment.IconLeftPadding = new System.Windows.Forms.Padding(11, 3, 3, 3);
            this.btnSendComment.IconMarginLeft = 11;
            this.btnSendComment.IconPadding = 10;
            this.btnSendComment.IconRight = null;
            this.btnSendComment.IconRightAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnSendComment.IconRightCursor = System.Windows.Forms.Cursors.Default;
            this.btnSendComment.IconRightPadding = new System.Windows.Forms.Padding(3, 3, 7, 3);
            this.btnSendComment.IconSize = 25;
            this.btnSendComment.IdleBorderColor = System.Drawing.Color.Empty;
            this.btnSendComment.IdleBorderRadius = 0;
            this.btnSendComment.IdleBorderThickness = 0;
            this.btnSendComment.IdleFillColor = System.Drawing.Color.Empty;
            this.btnSendComment.IdleIconLeftImage = null;
            this.btnSendComment.IdleIconRightImage = null;
            this.btnSendComment.IndicateFocus = false;
            this.btnSendComment.Location = new System.Drawing.Point(263, 1023);
            this.btnSendComment.Margin = new System.Windows.Forms.Padding(10);
            this.btnSendComment.Name = "btnSendComment";
            this.btnSendComment.OnDisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(191)))), ((int)(((byte)(191)))), ((int)(((byte)(191)))));
            this.btnSendComment.OnDisabledState.BorderRadius = 15;
            this.btnSendComment.OnDisabledState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
            this.btnSendComment.OnDisabledState.BorderThickness = 1;
            this.btnSendComment.OnDisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(204)))), ((int)(((byte)(204)))));
            this.btnSendComment.OnDisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(168)))), ((int)(((byte)(160)))), ((int)(((byte)(168)))));
            this.btnSendComment.OnDisabledState.IconLeftImage = null;
            this.btnSendComment.OnDisabledState.IconRightImage = null;
            this.btnSendComment.onHoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(150)))), ((int)(((byte)(255)))));
            this.btnSendComment.onHoverState.BorderRadius = 15;
            this.btnSendComment.onHoverState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
            this.btnSendComment.onHoverState.BorderThickness = 1;
            this.btnSendComment.onHoverState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(150)))), ((int)(((byte)(255)))));
            this.btnSendComment.onHoverState.ForeColor = System.Drawing.Color.White;
            this.btnSendComment.onHoverState.IconLeftImage = null;
            this.btnSendComment.onHoverState.IconRightImage = null;
            this.btnSendComment.OnIdleState.BorderColor = System.Drawing.Color.DodgerBlue;
            this.btnSendComment.OnIdleState.BorderRadius = 15;
            this.btnSendComment.OnIdleState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
            this.btnSendComment.OnIdleState.BorderThickness = 1;
            this.btnSendComment.OnIdleState.FillColor = System.Drawing.Color.LightSkyBlue;
            this.btnSendComment.OnIdleState.ForeColor = System.Drawing.Color.Black;
            this.btnSendComment.OnIdleState.IconLeftImage = null;
            this.btnSendComment.OnIdleState.IconRightImage = null;
            this.btnSendComment.OnPressedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(96)))), ((int)(((byte)(144)))));
            this.btnSendComment.OnPressedState.BorderRadius = 15;
            this.btnSendComment.OnPressedState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
            this.btnSendComment.OnPressedState.BorderThickness = 1;
            this.btnSendComment.OnPressedState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(96)))), ((int)(((byte)(144)))));
            this.btnSendComment.OnPressedState.ForeColor = System.Drawing.Color.White;
            this.btnSendComment.OnPressedState.IconLeftImage = null;
            this.btnSendComment.OnPressedState.IconRightImage = null;
            this.btnSendComment.Size = new System.Drawing.Size(131, 40);
            this.btnSendComment.TabIndex = 40;
            this.btnSendComment.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.btnSendComment.TextAlignment = System.Windows.Forms.HorizontalAlignment.Center;
            this.btnSendComment.TextMarginLeft = 0;
            this.btnSendComment.TextPadding = new System.Windows.Forms.Padding(0);
            this.btnSendComment.UseDefaultRadiusAndThickness = true;
            this.btnSendComment.Click += new System.EventHandler(this.btnSendComment_Click);
            // 
            // CtrlPanelTaskRequestHelp
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.splitContainer1);
            this.Name = "CtrlPanelTaskRequestHelp";
            this.Size = new System.Drawing.Size(1347, 931);
            this.Load += new System.EventHandler(this.CtrlPanelTaskAdminNew_Load);
            this.splitContainer1.Panel1.ResumeLayout(false);
            this.splitContainer1.Panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer1)).EndInit();
            this.splitContainer1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgvItems)).EndInit();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.tableLayoutPanel1.ResumeLayout(false);
            this.tableLayoutPanel1.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.panelComments.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.SplitContainer splitContainer1;
        private System.Windows.Forms.Panel panel1;
        private CustomControls.RoundedLabel lbProjects;
        private Bunifu.UI.WinForms.BunifuDataGridView dgvItems;
        private CustomControls.RoundedLabel roundedLabel1;
        private Bunifu.UI.WinForms.BunifuTextBox tbSearch;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel1;
        private Bunifu.Framework.UI.BunifuCustomLabel lbName;
        private CustomControls.RoundedLabel lbPriority;
        private Bunifu.UI.WinForms.BunifuDropdown cbStatus;
        private Bunifu.UI.WinForms.BunifuLabel lbTaskProject;
        private Bunifu.UI.WinForms.BunifuLabel bunifuLabel4;
        private Bunifu.UI.WinForms.BunifuLabel bunifuLabel3;
        private Bunifu.UI.WinForms.BunifuButton.BunifuButton btnDocLink;
        private Bunifu.UI.WinForms.BunifuButton.BunifuButton btnAttachment;
        private Bunifu.UI.WinForms.BunifuTextBox tbDescription;
        private Bunifu.UI.WinForms.BunifuLabel lbComment;
        private System.Windows.Forms.Label lbOwner;
        private System.Windows.Forms.Label lbCreatedBy;
        private System.Windows.Forms.Label lbDueDate;
        private Others.LabelWithImage labelWithImage1;
        private Others.LabelWithImage labelWithImage2;
        private Others.LabelWithImage labelWithImage3;
        private Others.LabelWithImage labelWithImage4;
        private Others.LabelWithImage labelWithImage5;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.FlowLayoutPanel panelComments;
        private Bunifu.UI.WinForms.BunifuSeparator bunifuSeparator1;
        private Bunifu.UI.WinForms.BunifuSeparator bunifuSeparator2;
        private Bunifu.UI.WinForms.BunifuTextBox tbComment;
        private Bunifu.UI.WinForms.BunifuButton.BunifuButton btnSendComment;
    }
}
