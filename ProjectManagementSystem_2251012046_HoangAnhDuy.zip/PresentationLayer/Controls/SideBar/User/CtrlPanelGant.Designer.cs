﻿
namespace PresentationLayer.UC_SideBar
{
    partial class CtrlPanelGant
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            C1.Win.C1GanttView.BarStyle barStyle1 = new C1.Win.C1GanttView.BarStyle();
            C1.Win.C1GanttView.TaskPropertyColumn taskPropertyColumn1 = new C1.Win.C1GanttView.TaskPropertyColumn();
            C1.Win.C1GanttView.TaskPropertyColumn taskPropertyColumn2 = new C1.Win.C1GanttView.TaskPropertyColumn();
            C1.Win.C1GanttView.TaskPropertyColumn taskPropertyColumn3 = new C1.Win.C1GanttView.TaskPropertyColumn();
            C1.Win.C1GanttView.TaskPropertyColumn taskPropertyColumn4 = new C1.Win.C1GanttView.TaskPropertyColumn();
            C1.Win.C1GanttView.TaskPropertyColumn taskPropertyColumn5 = new C1.Win.C1GanttView.TaskPropertyColumn();
            C1.Win.C1GanttView.TaskPropertyColumn taskPropertyColumn6 = new C1.Win.C1GanttView.TaskPropertyColumn();
            C1.Win.C1GanttView.TaskPropertyColumn taskPropertyColumn7 = new C1.Win.C1GanttView.TaskPropertyColumn();
            C1.Win.C1GanttView.TaskPropertyColumn taskPropertyColumn8 = new C1.Win.C1GanttView.TaskPropertyColumn();
            C1.Win.C1GanttView.TaskPropertyColumn taskPropertyColumn9 = new C1.Win.C1GanttView.TaskPropertyColumn();
            C1.Win.C1GanttView.TaskPropertyColumn taskPropertyColumn10 = new C1.Win.C1GanttView.TaskPropertyColumn();
            C1.Win.C1GanttView.TaskPropertyColumn taskPropertyColumn11 = new C1.Win.C1GanttView.TaskPropertyColumn();
            C1.Win.C1GanttView.TaskPropertyColumn taskPropertyColumn12 = new C1.Win.C1GanttView.TaskPropertyColumn();
            C1.Win.C1GanttView.TaskPropertyColumn taskPropertyColumn13 = new C1.Win.C1GanttView.TaskPropertyColumn();
            C1.Win.C1GanttView.TaskPropertyColumn taskPropertyColumn14 = new C1.Win.C1GanttView.TaskPropertyColumn();
            C1.Win.C1GanttView.Task task1 = new C1.Win.C1GanttView.Task();
            C1.Win.C1GanttView.Task task2 = new C1.Win.C1GanttView.Task();
            C1.Win.C1GanttView.Task task3 = new C1.Win.C1GanttView.Task();
            C1.Win.C1GanttView.Task task4 = new C1.Win.C1GanttView.Task();
            C1.Win.C1GanttView.Task task5 = new C1.Win.C1GanttView.Task();
            C1.Win.C1GanttView.Task task6 = new C1.Win.C1GanttView.Task();
            C1.Win.C1GanttView.Task task7 = new C1.Win.C1GanttView.Task();
            C1.Win.C1GanttView.Task task8 = new C1.Win.C1GanttView.Task();
            C1.Win.C1GanttView.Task task9 = new C1.Win.C1GanttView.Task();
            C1.Win.C1GanttView.Task task10 = new C1.Win.C1GanttView.Task();
            C1.Win.C1GanttView.Task task11 = new C1.Win.C1GanttView.Task();
            C1.Win.C1GanttView.Task task12 = new C1.Win.C1GanttView.Task();
            C1.Win.C1GanttView.Task task13 = new C1.Win.C1GanttView.Task();
            C1.Win.C1GanttView.Task task14 = new C1.Win.C1GanttView.Task();
            C1.Win.C1GanttView.Task task15 = new C1.Win.C1GanttView.Task();
            C1.Win.C1GanttView.Task task16 = new C1.Win.C1GanttView.Task();
            C1.Win.C1GanttView.Task task17 = new C1.Win.C1GanttView.Task();
            C1.Win.C1GanttView.Task task18 = new C1.Win.C1GanttView.Task();
            C1.Win.C1GanttView.Task task19 = new C1.Win.C1GanttView.Task();
            C1.Win.C1GanttView.Task task20 = new C1.Win.C1GanttView.Task();
            C1.Win.C1GanttView.Task task21 = new C1.Win.C1GanttView.Task();
            C1.Win.C1GanttView.Task task22 = new C1.Win.C1GanttView.Task();
            C1.Win.C1GanttView.Task task23 = new C1.Win.C1GanttView.Task();
            C1.Win.C1GanttView.Task task24 = new C1.Win.C1GanttView.Task();
            C1.Win.C1GanttView.Task task25 = new C1.Win.C1GanttView.Task();
            C1.Win.C1GanttView.Task task26 = new C1.Win.C1GanttView.Task();
            C1.Win.C1GanttView.Task task27 = new C1.Win.C1GanttView.Task();
            C1.Win.C1GanttView.Task task28 = new C1.Win.C1GanttView.Task();
            C1.Win.C1GanttView.Task task29 = new C1.Win.C1GanttView.Task();
            C1.Win.C1GanttView.Task task30 = new C1.Win.C1GanttView.Task();
            C1.Win.C1GanttView.Task task31 = new C1.Win.C1GanttView.Task();
            C1.Win.C1GanttView.Task task32 = new C1.Win.C1GanttView.Task();
            C1.Win.C1GanttView.Task task33 = new C1.Win.C1GanttView.Task();
            C1.Win.C1GanttView.Task task34 = new C1.Win.C1GanttView.Task();
            C1.Win.C1GanttView.Task task35 = new C1.Win.C1GanttView.Task();
            C1.Win.C1GanttView.Task task36 = new C1.Win.C1GanttView.Task();
            C1.Win.C1GanttView.Task task37 = new C1.Win.C1GanttView.Task();
            C1.Win.C1GanttView.Task task38 = new C1.Win.C1GanttView.Task();
            C1.Win.C1GanttView.Task task39 = new C1.Win.C1GanttView.Task();
            C1.Win.C1GanttView.Task task40 = new C1.Win.C1GanttView.Task();
            C1.Win.C1GanttView.Task task41 = new C1.Win.C1GanttView.Task();
            C1.Win.C1GanttView.Task task42 = new C1.Win.C1GanttView.Task();
            C1.Win.C1GanttView.Task task43 = new C1.Win.C1GanttView.Task();
            C1.Win.C1GanttView.Task task44 = new C1.Win.C1GanttView.Task();
            C1.Win.C1GanttView.Task task45 = new C1.Win.C1GanttView.Task();
            C1.Win.C1GanttView.Task task46 = new C1.Win.C1GanttView.Task();
            C1.Win.C1GanttView.Task task47 = new C1.Win.C1GanttView.Task();
            C1.Win.C1GanttView.Task task48 = new C1.Win.C1GanttView.Task();
            C1.Win.C1GanttView.Task task49 = new C1.Win.C1GanttView.Task();
            C1.Win.C1GanttView.Task task50 = new C1.Win.C1GanttView.Task();
            C1.Win.C1GanttView.Task task51 = new C1.Win.C1GanttView.Task();
            C1.Win.C1GanttView.Task task52 = new C1.Win.C1GanttView.Task();
            C1.Win.C1GanttView.Task task53 = new C1.Win.C1GanttView.Task();
            C1.Win.C1GanttView.Task task54 = new C1.Win.C1GanttView.Task();
            C1.Win.C1GanttView.Task task55 = new C1.Win.C1GanttView.Task();
            C1.Win.C1GanttView.Task task56 = new C1.Win.C1GanttView.Task();
            C1.Win.C1GanttView.Task task57 = new C1.Win.C1GanttView.Task();
            C1.Win.C1GanttView.Task task58 = new C1.Win.C1GanttView.Task();
            C1.Win.C1GanttView.Task task59 = new C1.Win.C1GanttView.Task();
            C1.Win.C1GanttView.Task task60 = new C1.Win.C1GanttView.Task();
            C1.Win.C1GanttView.Task task61 = new C1.Win.C1GanttView.Task();
            this.c1GanttView1 = new C1.Win.C1GanttView.C1GanttView();
            ((System.ComponentModel.ISupportInitialize)(this.c1GanttView1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.c1GanttView1.DataStorage.CalendarStorage)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.c1GanttView1.DataStorage.PropertyStorage)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.c1GanttView1.DataStorage.ResourceStorage)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.c1GanttView1.DataStorage.TasksStorage)).BeginInit();
            this.SuspendLayout();
            // 
            // c1GanttView1
            // 
            this.c1GanttView1.BackColor = System.Drawing.SystemColors.Window;
            this.c1GanttView1.BarStyles.Add(barStyle1);
            this.c1GanttView1.ChartViewZoomFactor = 6.846154F;
            taskPropertyColumn1.Caption = "Task Mode";
            taskPropertyColumn1.ID = 1317065904;
            taskPropertyColumn1.Property = C1.Win.C1GanttView.TaskProperty.Mode;
            taskPropertyColumn2.Caption = "Task Name";
            taskPropertyColumn2.ID = 1231769997;
            taskPropertyColumn2.Property = C1.Win.C1GanttView.TaskProperty.Name;
            taskPropertyColumn3.Caption = "Duration";
            taskPropertyColumn3.ID = 332122480;
            taskPropertyColumn3.Property = C1.Win.C1GanttView.TaskProperty.Duration;
            taskPropertyColumn3.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            taskPropertyColumn3.Visible = false;
            taskPropertyColumn4.Caption = "Duration Units";
            taskPropertyColumn4.ID = 439029996;
            taskPropertyColumn4.Property = C1.Win.C1GanttView.TaskProperty.DurationUnits;
            taskPropertyColumn4.Visible = false;
            taskPropertyColumn5.Caption = "Start";
            taskPropertyColumn5.ID = 1816248297;
            taskPropertyColumn5.Property = C1.Win.C1GanttView.TaskProperty.Start;
            taskPropertyColumn5.Visible = false;
            taskPropertyColumn6.Caption = "Finish";
            taskPropertyColumn6.ID = 847544388;
            taskPropertyColumn6.Property = C1.Win.C1GanttView.TaskProperty.Finish;
            taskPropertyColumn6.Visible = false;
            taskPropertyColumn7.Caption = "% Complete";
            taskPropertyColumn7.ID = 1740985556;
            taskPropertyColumn7.Property = C1.Win.C1GanttView.TaskProperty.PercentComplete;
            taskPropertyColumn7.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            taskPropertyColumn7.Visible = false;
            taskPropertyColumn8.Caption = "Constraint Type";
            taskPropertyColumn8.ID = 1356300852;
            taskPropertyColumn8.Property = C1.Win.C1GanttView.TaskProperty.ConstraintType;
            taskPropertyColumn8.Visible = false;
            taskPropertyColumn9.Caption = "Constraint Date";
            taskPropertyColumn9.ID = 485170150;
            taskPropertyColumn9.Property = C1.Win.C1GanttView.TaskProperty.ConstraintDate;
            taskPropertyColumn9.Visible = false;
            taskPropertyColumn10.Caption = "Predecessors";
            taskPropertyColumn10.ID = 1560320878;
            taskPropertyColumn10.Property = C1.Win.C1GanttView.TaskProperty.Predecessors;
            taskPropertyColumn10.Visible = false;
            taskPropertyColumn11.Caption = "Deadline";
            taskPropertyColumn11.ID = 1027030281;
            taskPropertyColumn11.Property = C1.Win.C1GanttView.TaskProperty.Deadline;
            taskPropertyColumn11.Visible = false;
            taskPropertyColumn12.Caption = "Calendar";
            taskPropertyColumn12.ID = 1159508801;
            taskPropertyColumn12.Property = C1.Win.C1GanttView.TaskProperty.Calendar;
            taskPropertyColumn12.Visible = false;
            taskPropertyColumn13.Caption = "Resource Names";
            taskPropertyColumn13.ID = 1316171344;
            taskPropertyColumn13.Property = C1.Win.C1GanttView.TaskProperty.ResourceNames;
            taskPropertyColumn13.Visible = false;
            taskPropertyColumn14.Caption = "Notes";
            taskPropertyColumn14.ID = 734639778;
            taskPropertyColumn14.Property = C1.Win.C1GanttView.TaskProperty.Notes;
            taskPropertyColumn14.Visible = false;
            this.c1GanttView1.Columns.Add(taskPropertyColumn1);
            this.c1GanttView1.Columns.Add(taskPropertyColumn2);
            this.c1GanttView1.Columns.Add(taskPropertyColumn3);
            this.c1GanttView1.Columns.Add(taskPropertyColumn4);
            this.c1GanttView1.Columns.Add(taskPropertyColumn5);
            this.c1GanttView1.Columns.Add(taskPropertyColumn6);
            this.c1GanttView1.Columns.Add(taskPropertyColumn7);
            this.c1GanttView1.Columns.Add(taskPropertyColumn8);
            this.c1GanttView1.Columns.Add(taskPropertyColumn9);
            this.c1GanttView1.Columns.Add(taskPropertyColumn10);
            this.c1GanttView1.Columns.Add(taskPropertyColumn11);
            this.c1GanttView1.Columns.Add(taskPropertyColumn12);
            this.c1GanttView1.Columns.Add(taskPropertyColumn13);
            this.c1GanttView1.Columns.Add(taskPropertyColumn14);
            // 
            // 
            // 
            this.c1GanttView1.DefaultWorkingTimes.Interval_1.Empty = false;
            this.c1GanttView1.DefaultWorkingTimes.Interval_1.From = new System.DateTime(1, 1, 1, 9, 0, 0, 0);
            this.c1GanttView1.DefaultWorkingTimes.Interval_1.To = new System.DateTime(1, 1, 1, 13, 0, 0, 0);
            this.c1GanttView1.DefaultWorkingTimes.Interval_2.Empty = false;
            this.c1GanttView1.DefaultWorkingTimes.Interval_2.From = new System.DateTime(1, 1, 1, 14, 0, 0, 0);
            this.c1GanttView1.DefaultWorkingTimes.Interval_2.To = new System.DateTime(1, 1, 1, 18, 0, 0, 0);
            this.c1GanttView1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.c1GanttView1.GroupColumn = null;
            this.c1GanttView1.Location = new System.Drawing.Point(0, 0);
            this.c1GanttView1.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.c1GanttView1.Name = "c1GanttView1";
            task1.ID = 2121818334;
            task1.Mode = C1.Win.C1GanttView.TaskMode.Automatic;
            task1.Name = "Project Summary Task";
            task1.NextID = 0;
            this.c1GanttView1.ProjectSummary = task1;
            this.c1GanttView1.Size = new System.Drawing.Size(1187, 466);
            this.c1GanttView1.StartDate = new System.DateTime(2025, 5, 3, 0, 0, 0, 0);
            this.c1GanttView1.TabIndex = 0;
            task2.ID = 1958198445;
            task2.NextID = 885427011;
            task3.ID = 885427011;
            task3.NextID = 623149364;
            task4.ID = 623149364;
            task4.NextID = 623293816;
            task5.ID = 623293816;
            task5.NextID = 685511354;
            task6.ID = 685511354;
            task6.NextID = 1691509059;
            task7.ID = 1691509059;
            task7.NextID = 219653654;
            task8.ID = 219653654;
            task8.NextID = 638784549;
            task9.ID = 638784549;
            task9.NextID = 566359534;
            task10.ID = 566359534;
            task10.NextID = 551364851;
            task11.ID = 551364851;
            task11.NextID = 54226789;
            task12.ID = 54226789;
            task12.NextID = 1290267310;
            task13.ID = 1290267310;
            task13.NextID = 1568912805;
            task14.ID = 1568912805;
            task14.NextID = 1471026793;
            task15.ID = 1471026793;
            task15.NextID = 293057823;
            task16.ID = 293057823;
            task16.NextID = 567917648;
            task17.ID = 567917648;
            task17.NextID = 1007645877;
            task18.ID = 1007645877;
            task18.NextID = 2134783316;
            task19.ID = 2134783316;
            task19.NextID = 849832375;
            task20.ID = 849832375;
            task20.NextID = 1738786332;
            task21.ID = 1738786332;
            task21.NextID = 670927742;
            task22.ID = 670927742;
            task22.NextID = 1785575039;
            task23.ID = 1785575039;
            task23.NextID = 1408036971;
            task24.ID = 1408036971;
            task24.NextID = 427035063;
            task25.ID = 427035063;
            task25.NextID = 1194617608;
            task26.ID = 1194617608;
            task26.NextID = 2088346026;
            task27.ID = 2088346026;
            task27.NextID = 374443156;
            task28.ID = 374443156;
            task28.NextID = 1135367305;
            task29.ID = 1135367305;
            task29.NextID = 306662070;
            task30.ID = 306662070;
            task30.NextID = 127329539;
            task31.ID = 127329539;
            task31.NextID = 882600202;
            task32.ID = 882600202;
            task32.NextID = 1354166049;
            task33.ID = 1354166049;
            task33.NextID = 1696765402;
            task34.ID = 1696765402;
            task34.NextID = 212611954;
            task35.ID = 212611954;
            task35.NextID = 985856644;
            task36.ID = 985856644;
            task36.NextID = 880220593;
            task37.ID = 880220593;
            task37.NextID = 1688371015;
            task38.ID = 1688371015;
            task38.NextID = 1995620724;
            task39.ID = 1995620724;
            task39.NextID = 818611973;
            task40.ID = 818611973;
            task40.NextID = 115192598;
            task41.ID = 115192598;
            task41.NextID = 1897451227;
            task42.ID = 1897451227;
            task42.NextID = 1327903079;
            task43.ID = 1327903079;
            task43.NextID = 871047397;
            task44.ID = 871047397;
            task44.NextID = 541759133;
            task45.ID = 541759133;
            task45.NextID = 1268643718;
            task46.ID = 1268643718;
            task46.NextID = 113032697;
            task47.ID = 113032697;
            task47.NextID = 1372202628;
            task48.ID = 1372202628;
            task48.NextID = 107187762;
            task49.ID = 107187762;
            task49.NextID = 1036710707;
            task50.ID = 1036710707;
            task50.NextID = 1859766048;
            task51.ID = 1859766048;
            task51.NextID = 1012715683;
            task52.ID = 1012715683;
            task52.NextID = 1766128920;
            task53.ID = 1766128920;
            task53.NextID = 1927616031;
            task54.ID = 1927616031;
            task54.NextID = 264027798;
            task55.ID = 264027798;
            task55.NextID = 1450890593;
            task56.ID = 1450890593;
            task56.NextID = 172623407;
            task57.ID = 172623407;
            task57.NextID = 1624873688;
            task58.ID = 1624873688;
            task58.NextID = 196114302;
            task59.ID = 196114302;
            task59.NextID = 1576159856;
            task60.ID = 1576159856;
            task60.NextID = 744648976;
            task61.ID = 744648976;
            task61.NextID = -1;
            this.c1GanttView1.Tasks.AddRange(new C1.Win.C1GanttView.Task[] {
            task2,
            task3,
            task4,
            task5,
            task6,
            task7,
            task8,
            task9,
            task10,
            task11,
            task12,
            task13,
            task14,
            task15,
            task16,
            task17,
            task18,
            task19,
            task20,
            task21,
            task22,
            task23,
            task24,
            task25,
            task26,
            task27,
            task28,
            task29,
            task30,
            task31,
            task32,
            task33,
            task34,
            task35,
            task36,
            task37,
            task38,
            task39,
            task40,
            task41,
            task42,
            task43,
            task44,
            task45,
            task46,
            task47,
            task48,
            task49,
            task50,
            task51,
            task52,
            task53,
            task54,
            task55,
            task56,
            task57,
            task58,
            task59,
            task60,
            task61});
            this.c1GanttView1.Timescale.BottomTier.Align = C1.Win.C1GanttView.ScaleLabelAlignment.Center;
            this.c1GanttView1.Timescale.BottomTier.Format = "w";
            this.c1GanttView1.Timescale.BottomTier.Visible = true;
            this.c1GanttView1.Timescale.MiddleTier.Format = "nnnn d";
            this.c1GanttView1.Timescale.MiddleTier.Units = C1.Win.C1GanttView.TimescaleUnits.Weeks;
            this.c1GanttView1.Timescale.MiddleTier.Visible = true;
            // 
            // CtrlPanelGant
            // 
            this.Controls.Add(this.c1GanttView1);
            this.Name = "CtrlPanelGant";
            this.Size = new System.Drawing.Size(1187, 466);
            ((System.ComponentModel.ISupportInitialize)(this.c1GanttView1.DataStorage.CalendarStorage)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.c1GanttView1.DataStorage.PropertyStorage)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.c1GanttView1.DataStorage.ResourceStorage)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.c1GanttView1.DataStorage.TasksStorage)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.c1GanttView1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private C1.Win.C1GanttView.C1GanttView c1GanttView1;


    }
}
