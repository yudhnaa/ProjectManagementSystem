﻿namespace PresentationLayer.Controls.SideBar.User
{
    partial class CtrlPanelProjectNew
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(CtrlPanelProjectNew));
            Bunifu.UI.WinForms.BunifuTextBox.StateProperties stateProperties1 = new Bunifu.UI.WinForms.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextBox.StateProperties stateProperties2 = new Bunifu.UI.WinForms.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextBox.StateProperties stateProperties3 = new Bunifu.UI.WinForms.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextBox.StateProperties stateProperties4 = new Bunifu.UI.WinForms.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextBox.StateProperties stateProperties5 = new Bunifu.UI.WinForms.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextBox.StateProperties stateProperties6 = new Bunifu.UI.WinForms.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextBox.StateProperties stateProperties7 = new Bunifu.UI.WinForms.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextBox.StateProperties stateProperties8 = new Bunifu.UI.WinForms.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextBox.StateProperties stateProperties9 = new Bunifu.UI.WinForms.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextBox.StateProperties stateProperties10 = new Bunifu.UI.WinForms.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextBox.StateProperties stateProperties11 = new Bunifu.UI.WinForms.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextBox.StateProperties stateProperties12 = new Bunifu.UI.WinForms.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextBox.StateProperties stateProperties13 = new Bunifu.UI.WinForms.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextBox.StateProperties stateProperties14 = new Bunifu.UI.WinForms.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextBox.StateProperties stateProperties15 = new Bunifu.UI.WinForms.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextBox.StateProperties stateProperties16 = new Bunifu.UI.WinForms.BunifuTextBox.StateProperties();
            this.splitContainer1 = new System.Windows.Forms.SplitContainer();
            this.dgvItems = new Bunifu.UI.WinForms.BunifuDataGridView();
            this.panel1 = new System.Windows.Forms.Panel();
            this.tbSearch = new Bunifu.UI.WinForms.BunifuTextBox();
            this.lbProjects = new PresentationLayer.CustomControls.RoundedLabel();
            this.tableLayoutPanel1 = new System.Windows.Forms.TableLayoutPanel();
            this.lbShortDescription = new Bunifu.UI.WinForms.BunifuLabel();
            this.lbPriority = new PresentationLayer.CustomControls.RoundedLabel();
            this.lbStatus = new PresentationLayer.CustomControls.RoundedLabel();
            this.tbProjectDesrciption = new Bunifu.UI.WinForms.BunifuTextBox();
            this.bunifuCustomLabel6 = new Bunifu.Framework.UI.BunifuCustomLabel();
            this.listviewMembers = new System.Windows.Forms.ListView();
            this.id = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.name = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.role = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.bunifuCustomLabel11 = new Bunifu.Framework.UI.BunifuCustomLabel();
            this.datePickerEnd = new Bunifu.UI.WinForms.BunifuDatePicker();
            this.datePickerStart = new Bunifu.UI.WinForms.BunifuDatePicker();
            this.tbProjectCode = new Bunifu.UI.WinForms.BunifuTextBox();
            this.tbBudget = new Bunifu.UI.WinForms.BunifuTextBox();
            this.lbName = new Bunifu.Framework.UI.BunifuCustomLabel();
            this.labelWithImage1 = new PresentationLayer.Controls.Others.LabelWithImage();
            this.labelWithImage2 = new PresentationLayer.Controls.Others.LabelWithImage();
            this.labelWithImage3 = new PresentationLayer.Controls.Others.LabelWithImage();
            this.labelWithImage4 = new PresentationLayer.Controls.Others.LabelWithImage();
            this.labelWithImage5 = new PresentationLayer.Controls.Others.LabelWithImage();
            this.labelWithImage6 = new PresentationLayer.Controls.Others.LabelWithImage();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer1)).BeginInit();
            this.splitContainer1.Panel1.SuspendLayout();
            this.splitContainer1.Panel2.SuspendLayout();
            this.splitContainer1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvItems)).BeginInit();
            this.panel1.SuspendLayout();
            this.tableLayoutPanel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // splitContainer1
            // 
            this.splitContainer1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitContainer1.Location = new System.Drawing.Point(0, 0);
            this.splitContainer1.Name = "splitContainer1";
            // 
            // splitContainer1.Panel1
            // 
            this.splitContainer1.Panel1.Controls.Add(this.dgvItems);
            this.splitContainer1.Panel1.Controls.Add(this.panel1);
            this.splitContainer1.Panel1.Padding = new System.Windows.Forms.Padding(10);
            // 
            // splitContainer1.Panel2
            // 
            this.splitContainer1.Panel2.AutoScroll = true;
            this.splitContainer1.Panel2.Controls.Add(this.tableLayoutPanel1);
            this.splitContainer1.Size = new System.Drawing.Size(1535, 899);
            this.splitContainer1.SplitterDistance = 1007;
            this.splitContainer1.TabIndex = 0;
            this.splitContainer1.Paint += new System.Windows.Forms.PaintEventHandler(this.splitContainer1_Paint);
            // 
            // dgvItems
            // 
            this.dgvItems.AllowCustomTheming = false;
            dataGridViewCellStyle1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(248)))), ((int)(((byte)(251)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle1.ForeColor = System.Drawing.Color.Black;
            this.dgvItems.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle1;
            this.dgvItems.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgvItems.BackgroundColor = System.Drawing.Color.WhiteSmoke;
            this.dgvItems.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.dgvItems.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.SingleHorizontal;
            this.dgvItems.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle2.BackColor = System.Drawing.Color.DodgerBlue;
            dataGridViewCellStyle2.Font = new System.Drawing.Font("Segoe UI Semibold", 11.75F, System.Drawing.FontStyle.Bold);
            dataGridViewCellStyle2.ForeColor = System.Drawing.Color.White;
            dataGridViewCellStyle2.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(24)))), ((int)(((byte)(115)))), ((int)(((byte)(204)))));
            dataGridViewCellStyle2.SelectionForeColor = System.Drawing.Color.White;
            dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvItems.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle2;
            this.dgvItems.ColumnHeadersHeight = 40;
            this.dgvItems.CurrentTheme.AlternatingRowsStyle.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(248)))), ((int)(((byte)(251)))), ((int)(((byte)(255)))));
            this.dgvItems.CurrentTheme.AlternatingRowsStyle.Font = new System.Drawing.Font("Segoe UI Semibold", 9.75F, System.Drawing.FontStyle.Bold);
            this.dgvItems.CurrentTheme.AlternatingRowsStyle.ForeColor = System.Drawing.Color.Black;
            this.dgvItems.CurrentTheme.AlternatingRowsStyle.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(210)))), ((int)(((byte)(232)))), ((int)(((byte)(255)))));
            this.dgvItems.CurrentTheme.AlternatingRowsStyle.SelectionForeColor = System.Drawing.Color.Black;
            this.dgvItems.CurrentTheme.BackColor = System.Drawing.Color.White;
            this.dgvItems.CurrentTheme.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(221)))), ((int)(((byte)(238)))), ((int)(((byte)(255)))));
            this.dgvItems.CurrentTheme.HeaderStyle.BackColor = System.Drawing.Color.DodgerBlue;
            this.dgvItems.CurrentTheme.HeaderStyle.Font = new System.Drawing.Font("Segoe UI Semibold", 11.75F, System.Drawing.FontStyle.Bold);
            this.dgvItems.CurrentTheme.HeaderStyle.ForeColor = System.Drawing.Color.White;
            this.dgvItems.CurrentTheme.HeaderStyle.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(24)))), ((int)(((byte)(115)))), ((int)(((byte)(204)))));
            this.dgvItems.CurrentTheme.HeaderStyle.SelectionForeColor = System.Drawing.Color.White;
            this.dgvItems.CurrentTheme.Name = null;
            this.dgvItems.CurrentTheme.RowsStyle.BackColor = System.Drawing.Color.White;
            this.dgvItems.CurrentTheme.RowsStyle.Font = new System.Drawing.Font("Segoe UI Semibold", 9.75F, System.Drawing.FontStyle.Bold);
            this.dgvItems.CurrentTheme.RowsStyle.ForeColor = System.Drawing.Color.Black;
            this.dgvItems.CurrentTheme.RowsStyle.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(210)))), ((int)(((byte)(232)))), ((int)(((byte)(255)))));
            this.dgvItems.CurrentTheme.RowsStyle.SelectionForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle3.BackColor = System.Drawing.Color.White;
            dataGridViewCellStyle3.Font = new System.Drawing.Font("Segoe UI Semibold", 9.75F, System.Drawing.FontStyle.Bold);
            dataGridViewCellStyle3.ForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle3.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(210)))), ((int)(((byte)(232)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle3.SelectionForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle3.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dgvItems.DefaultCellStyle = dataGridViewCellStyle3;
            this.dgvItems.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dgvItems.EnableHeadersVisualStyles = false;
            this.dgvItems.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(221)))), ((int)(((byte)(238)))), ((int)(((byte)(255)))));
            this.dgvItems.HeaderBackColor = System.Drawing.Color.DodgerBlue;
            this.dgvItems.HeaderBgColor = System.Drawing.Color.Empty;
            this.dgvItems.HeaderForeColor = System.Drawing.Color.White;
            this.dgvItems.Location = new System.Drawing.Point(10, 99);
            this.dgvItems.Name = "dgvItems";
            this.dgvItems.RowHeadersVisible = false;
            this.dgvItems.RowHeadersWidth = 62;
            this.dgvItems.RowTemplate.Height = 40;
            this.dgvItems.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvItems.Size = new System.Drawing.Size(987, 790);
            this.dgvItems.TabIndex = 6;
            this.dgvItems.Theme = Bunifu.UI.WinForms.BunifuDataGridView.PresetThemes.Light;
            this.dgvItems.SelectionChanged += new System.EventHandler(this.dgvItems_SelectionChanged);
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.tbSearch);
            this.panel1.Controls.Add(this.lbProjects);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel1.Location = new System.Drawing.Point(10, 10);
            this.panel1.Name = "panel1";
            this.panel1.Padding = new System.Windows.Forms.Padding(0, 0, 0, 8);
            this.panel1.Size = new System.Drawing.Size(987, 89);
            this.panel1.TabIndex = 5;
            // 
            // tbSearch
            // 
            this.tbSearch.AcceptsReturn = false;
            this.tbSearch.AcceptsTab = false;
            this.tbSearch.AnimationSpeed = 200;
            this.tbSearch.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.None;
            this.tbSearch.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.None;
            this.tbSearch.AutoSizeHeight = true;
            this.tbSearch.BackColor = System.Drawing.Color.Transparent;
            this.tbSearch.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("tbSearch.BackgroundImage")));
            this.tbSearch.BorderColorActive = System.Drawing.Color.DodgerBlue;
            this.tbSearch.BorderColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(204)))), ((int)(((byte)(204)))));
            this.tbSearch.BorderColorHover = System.Drawing.Color.FromArgb(((int)(((byte)(105)))), ((int)(((byte)(181)))), ((int)(((byte)(255)))));
            this.tbSearch.BorderColorIdle = System.Drawing.Color.Silver;
            this.tbSearch.BorderRadius = 25;
            this.tbSearch.BorderThickness = 1;
            this.tbSearch.CharacterCase = Bunifu.UI.WinForms.BunifuTextBox.CharacterCases.Normal;
            this.tbSearch.CharacterCasing = System.Windows.Forms.CharacterCasing.Normal;
            this.tbSearch.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.tbSearch.DefaultFont = new System.Drawing.Font("Segoe UI", 9.25F);
            this.tbSearch.DefaultText = "";
            this.tbSearch.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tbSearch.FillColor = System.Drawing.Color.White;
            this.tbSearch.HideSelection = true;
            this.tbSearch.IconLeft = null;
            this.tbSearch.IconLeftCursor = System.Windows.Forms.Cursors.IBeam;
            this.tbSearch.IconPadding = 10;
            this.tbSearch.IconRight = null;
            this.tbSearch.IconRightCursor = System.Windows.Forms.Cursors.IBeam;
            this.tbSearch.Lines = new string[0];
            this.tbSearch.Location = new System.Drawing.Point(0, 34);
            this.tbSearch.MaxLength = 32767;
            this.tbSearch.MinimumSize = new System.Drawing.Size(1, 1);
            this.tbSearch.Modified = false;
            this.tbSearch.Multiline = false;
            this.tbSearch.Name = "tbSearch";
            stateProperties1.BorderColor = System.Drawing.Color.DodgerBlue;
            stateProperties1.FillColor = System.Drawing.Color.Empty;
            stateProperties1.ForeColor = System.Drawing.Color.Empty;
            stateProperties1.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.tbSearch.OnActiveState = stateProperties1;
            stateProperties2.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(204)))), ((int)(((byte)(204)))));
            stateProperties2.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(240)))), ((int)(((byte)(240)))), ((int)(((byte)(240)))));
            stateProperties2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            stateProperties2.PlaceholderForeColor = System.Drawing.Color.DarkGray;
            this.tbSearch.OnDisabledState = stateProperties2;
            stateProperties3.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(105)))), ((int)(((byte)(181)))), ((int)(((byte)(255)))));
            stateProperties3.FillColor = System.Drawing.Color.Empty;
            stateProperties3.ForeColor = System.Drawing.Color.Empty;
            stateProperties3.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.tbSearch.OnHoverState = stateProperties3;
            stateProperties4.BorderColor = System.Drawing.Color.Silver;
            stateProperties4.FillColor = System.Drawing.Color.White;
            stateProperties4.ForeColor = System.Drawing.Color.Empty;
            stateProperties4.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.tbSearch.OnIdleState = stateProperties4;
            this.tbSearch.Padding = new System.Windows.Forms.Padding(3);
            this.tbSearch.PasswordChar = '\0';
            this.tbSearch.PlaceholderForeColor = System.Drawing.Color.Silver;
            this.tbSearch.PlaceholderText = "Enter text";
            this.tbSearch.ReadOnly = false;
            this.tbSearch.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.tbSearch.SelectedText = "";
            this.tbSearch.SelectionLength = 0;
            this.tbSearch.SelectionStart = 0;
            this.tbSearch.ShortcutsEnabled = true;
            this.tbSearch.Size = new System.Drawing.Size(987, 47);
            this.tbSearch.Style = Bunifu.UI.WinForms.BunifuTextBox._Style.Bunifu;
            this.tbSearch.TabIndex = 4;
            this.tbSearch.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.tbSearch.TextMarginBottom = 0;
            this.tbSearch.TextMarginLeft = 3;
            this.tbSearch.TextMarginTop = 1;
            this.tbSearch.TextPlaceholder = "Enter text";
            this.tbSearch.UseSystemPasswordChar = false;
            this.tbSearch.WordWrap = true;
            this.tbSearch.KeyDown += new System.Windows.Forms.KeyEventHandler(this.tbSearch_KeyDown);
            // 
            // lbProjects
            // 
            this.lbProjects._BackColor = System.Drawing.Color.Empty;
            this.lbProjects._TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.lbProjects.AutoSize = true;
            this.lbProjects.Dock = System.Windows.Forms.DockStyle.Top;
            this.lbProjects.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbProjects.Location = new System.Drawing.Point(0, 0);
            this.lbProjects.Name = "lbProjects";
            this.lbProjects.Padding = new System.Windows.Forms.Padding(0, 5, 0, 5);
            this.lbProjects.Size = new System.Drawing.Size(112, 34);
            this.lbProjects.TabIndex = 3;
            this.lbProjects.Text = "Project List";
            // 
            // tableLayoutPanel1
            // 
            this.tableLayoutPanel1.AutoScroll = true;
            this.tableLayoutPanel1.ColumnCount = 2;
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel1.Controls.Add(this.lbShortDescription, 0, 0);
            this.tableLayoutPanel1.Controls.Add(this.lbPriority, 1, 5);
            this.tableLayoutPanel1.Controls.Add(this.lbStatus, 1, 4);
            this.tableLayoutPanel1.Controls.Add(this.tbProjectDesrciption, 0, 11);
            this.tableLayoutPanel1.Controls.Add(this.bunifuCustomLabel6, 0, 10);
            this.tableLayoutPanel1.Controls.Add(this.listviewMembers, 0, 9);
            this.tableLayoutPanel1.Controls.Add(this.bunifuCustomLabel11, 0, 8);
            this.tableLayoutPanel1.Controls.Add(this.datePickerEnd, 1, 7);
            this.tableLayoutPanel1.Controls.Add(this.datePickerStart, 1, 6);
            this.tableLayoutPanel1.Controls.Add(this.tbProjectCode, 1, 2);
            this.tableLayoutPanel1.Controls.Add(this.tbBudget, 1, 3);
            this.tableLayoutPanel1.Controls.Add(this.lbName, 0, 1);
            this.tableLayoutPanel1.Controls.Add(this.labelWithImage1, 0, 2);
            this.tableLayoutPanel1.Controls.Add(this.labelWithImage2, 0, 3);
            this.tableLayoutPanel1.Controls.Add(this.labelWithImage3, 0, 4);
            this.tableLayoutPanel1.Controls.Add(this.labelWithImage4, 0, 5);
            this.tableLayoutPanel1.Controls.Add(this.labelWithImage5, 0, 6);
            this.tableLayoutPanel1.Controls.Add(this.labelWithImage6, 0, 7);
            this.tableLayoutPanel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel1.Location = new System.Drawing.Point(0, 0);
            this.tableLayoutPanel1.Name = "tableLayoutPanel1";
            this.tableLayoutPanel1.RowCount = 13;
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel1.Size = new System.Drawing.Size(524, 899);
            this.tableLayoutPanel1.TabIndex = 2;
            // 
            // lbShortDescription
            // 
            this.lbShortDescription.AllowParentOverrides = false;
            this.lbShortDescription.AutoEllipsis = false;
            this.lbShortDescription.AutoSize = false;
            this.lbShortDescription.AutoSizeHeightOnly = true;
            this.tableLayoutPanel1.SetColumnSpan(this.lbShortDescription, 2);
            this.lbShortDescription.Cursor = System.Windows.Forms.Cursors.Default;
            this.lbShortDescription.CursorType = System.Windows.Forms.Cursors.Default;
            this.lbShortDescription.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lbShortDescription.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.lbShortDescription.ForeColor = System.Drawing.SystemColors.ButtonShadow;
            this.lbShortDescription.Location = new System.Drawing.Point(10, 10);
            this.lbShortDescription.Margin = new System.Windows.Forms.Padding(10);
            this.lbShortDescription.Name = "lbShortDescription";
            this.lbShortDescription.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.lbShortDescription.Size = new System.Drawing.Size(504, 20);
            this.lbShortDescription.TabIndex = 26;
            this.lbShortDescription.Text = "Project P001";
            this.lbShortDescription.TextAlignment = System.Drawing.ContentAlignment.TopLeft;
            this.lbShortDescription.TextFormat = Bunifu.UI.WinForms.BunifuLabel.TextFormattingOptions.Default;
            // 
            // lbPriority
            // 
            this.lbPriority._BackColor = System.Drawing.Color.Empty;
            this.lbPriority._TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lbPriority.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.lbPriority.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbPriority.Location = new System.Drawing.Point(272, 309);
            this.lbPriority.Margin = new System.Windows.Forms.Padding(10);
            this.lbPriority.Name = "lbPriority";
            this.lbPriority.Padding = new System.Windows.Forms.Padding(10, 5, 10, 5);
            this.lbPriority.Size = new System.Drawing.Size(206, 30);
            this.lbPriority.TabIndex = 25;
            this.lbPriority.Text = "Priority";
            this.lbPriority.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // lbStatus
            // 
            this.lbStatus._BackColor = System.Drawing.Color.Empty;
            this.lbStatus._TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lbStatus.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.lbStatus.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbStatus.Location = new System.Drawing.Point(272, 250);
            this.lbStatus.Margin = new System.Windows.Forms.Padding(10);
            this.lbStatus.Name = "lbStatus";
            this.lbStatus.Padding = new System.Windows.Forms.Padding(10, 5, 10, 5);
            this.lbStatus.Size = new System.Drawing.Size(206, 30);
            this.lbStatus.TabIndex = 24;
            this.lbStatus.Text = "Status";
            this.lbStatus.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // tbProjectDesrciption
            // 
            this.tbProjectDesrciption.AcceptsReturn = false;
            this.tbProjectDesrciption.AcceptsTab = false;
            this.tbProjectDesrciption.AnimationSpeed = 200;
            this.tbProjectDesrciption.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.None;
            this.tbProjectDesrciption.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.None;
            this.tbProjectDesrciption.AutoSizeHeight = true;
            this.tbProjectDesrciption.BackColor = System.Drawing.Color.Transparent;
            this.tbProjectDesrciption.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("tbProjectDesrciption.BackgroundImage")));
            this.tbProjectDesrciption.BorderColorActive = System.Drawing.Color.DodgerBlue;
            this.tbProjectDesrciption.BorderColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(204)))), ((int)(((byte)(204)))));
            this.tbProjectDesrciption.BorderColorHover = System.Drawing.Color.FromArgb(((int)(((byte)(105)))), ((int)(((byte)(181)))), ((int)(((byte)(255)))));
            this.tbProjectDesrciption.BorderColorIdle = System.Drawing.Color.Silver;
            this.tbProjectDesrciption.BorderRadius = 30;
            this.tbProjectDesrciption.BorderThickness = 1;
            this.tbProjectDesrciption.CharacterCase = Bunifu.UI.WinForms.BunifuTextBox.CharacterCases.Normal;
            this.tbProjectDesrciption.CharacterCasing = System.Windows.Forms.CharacterCasing.Normal;
            this.tableLayoutPanel1.SetColumnSpan(this.tbProjectDesrciption, 2);
            this.tbProjectDesrciption.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.tbProjectDesrciption.DefaultFont = new System.Drawing.Font("Segoe UI", 9.25F);
            this.tbProjectDesrciption.DefaultText = "";
            this.tbProjectDesrciption.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tbProjectDesrciption.FillColor = System.Drawing.Color.White;
            this.tbProjectDesrciption.HideSelection = true;
            this.tbProjectDesrciption.IconLeft = null;
            this.tbProjectDesrciption.IconLeftCursor = System.Windows.Forms.Cursors.IBeam;
            this.tbProjectDesrciption.IconPadding = 10;
            this.tbProjectDesrciption.IconRight = null;
            this.tbProjectDesrciption.IconRightCursor = System.Windows.Forms.Cursors.IBeam;
            this.tbProjectDesrciption.Lines = new string[0];
            this.tbProjectDesrciption.Location = new System.Drawing.Point(10, 806);
            this.tbProjectDesrciption.Margin = new System.Windows.Forms.Padding(10);
            this.tbProjectDesrciption.MaxLength = 32767;
            this.tbProjectDesrciption.MinimumSize = new System.Drawing.Size(1, 1);
            this.tbProjectDesrciption.Modified = false;
            this.tbProjectDesrciption.Multiline = true;
            this.tbProjectDesrciption.Name = "tbProjectDesrciption";
            stateProperties5.BorderColor = System.Drawing.Color.DodgerBlue;
            stateProperties5.FillColor = System.Drawing.Color.Empty;
            stateProperties5.ForeColor = System.Drawing.Color.Empty;
            stateProperties5.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.tbProjectDesrciption.OnActiveState = stateProperties5;
            stateProperties6.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(204)))), ((int)(((byte)(204)))));
            stateProperties6.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(240)))), ((int)(((byte)(240)))), ((int)(((byte)(240)))));
            stateProperties6.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            stateProperties6.PlaceholderForeColor = System.Drawing.Color.DarkGray;
            this.tbProjectDesrciption.OnDisabledState = stateProperties6;
            stateProperties7.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(105)))), ((int)(((byte)(181)))), ((int)(((byte)(255)))));
            stateProperties7.FillColor = System.Drawing.Color.Empty;
            stateProperties7.ForeColor = System.Drawing.Color.Empty;
            stateProperties7.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.tbProjectDesrciption.OnHoverState = stateProperties7;
            stateProperties8.BorderColor = System.Drawing.Color.Silver;
            stateProperties8.FillColor = System.Drawing.Color.White;
            stateProperties8.ForeColor = System.Drawing.Color.Empty;
            stateProperties8.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.tbProjectDesrciption.OnIdleState = stateProperties8;
            this.tbProjectDesrciption.Padding = new System.Windows.Forms.Padding(3);
            this.tbProjectDesrciption.PasswordChar = '\0';
            this.tbProjectDesrciption.PlaceholderForeColor = System.Drawing.Color.Silver;
            this.tbProjectDesrciption.PlaceholderText = "";
            this.tbProjectDesrciption.ReadOnly = true;
            this.tbProjectDesrciption.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.tbProjectDesrciption.SelectedText = "";
            this.tbProjectDesrciption.SelectionLength = 0;
            this.tbProjectDesrciption.SelectionStart = 0;
            this.tbProjectDesrciption.ShortcutsEnabled = true;
            this.tbProjectDesrciption.Size = new System.Drawing.Size(504, 86);
            this.tbProjectDesrciption.Style = Bunifu.UI.WinForms.BunifuTextBox._Style.Bunifu;
            this.tbProjectDesrciption.TabIndex = 16;
            this.tbProjectDesrciption.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.tbProjectDesrciption.TextMarginBottom = 0;
            this.tbProjectDesrciption.TextMarginLeft = 3;
            this.tbProjectDesrciption.TextMarginTop = 1;
            this.tbProjectDesrciption.TextPlaceholder = "";
            this.tbProjectDesrciption.UseSystemPasswordChar = false;
            this.tbProjectDesrciption.WordWrap = true;
            // 
            // bunifuCustomLabel6
            // 
            this.bunifuCustomLabel6.BackColor = System.Drawing.Color.Transparent;
            this.bunifuCustomLabel6.Dock = System.Windows.Forms.DockStyle.Fill;
            this.bunifuCustomLabel6.Font = new System.Drawing.Font("Segoe UI", 15.75F, System.Drawing.FontStyle.Bold);
            this.bunifuCustomLabel6.Location = new System.Drawing.Point(10, 752);
            this.bunifuCustomLabel6.Margin = new System.Windows.Forms.Padding(10);
            this.bunifuCustomLabel6.Name = "bunifuCustomLabel6";
            this.bunifuCustomLabel6.Size = new System.Drawing.Size(242, 34);
            this.bunifuCustomLabel6.TabIndex = 17;
            this.bunifuCustomLabel6.Text = "Project Description";
            this.bunifuCustomLabel6.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // listviewMembers
            // 
            this.listviewMembers.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.id,
            this.name,
            this.role});
            this.tableLayoutPanel1.SetColumnSpan(this.listviewMembers, 2);
            this.listviewMembers.Dock = System.Windows.Forms.DockStyle.Fill;
            this.listviewMembers.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.listviewMembers.HideSelection = false;
            this.listviewMembers.Location = new System.Drawing.Point(10, 532);
            this.listviewMembers.Margin = new System.Windows.Forms.Padding(10);
            this.listviewMembers.Name = "listviewMembers";
            this.listviewMembers.Size = new System.Drawing.Size(504, 200);
            this.listviewMembers.TabIndex = 22;
            this.listviewMembers.UseCompatibleStateImageBehavior = false;
            this.listviewMembers.View = System.Windows.Forms.View.Details;
            // 
            // id
            // 
            this.id.Text = "ID";
            this.id.Width = 123;
            // 
            // name
            // 
            this.name.Text = "Name";
            this.name.Width = 137;
            // 
            // role
            // 
            this.role.Text = "Role";
            this.role.Width = 136;
            // 
            // bunifuCustomLabel11
            // 
            this.bunifuCustomLabel11.AutoSize = true;
            this.bunifuCustomLabel11.BackColor = System.Drawing.Color.Transparent;
            this.bunifuCustomLabel11.Dock = System.Windows.Forms.DockStyle.Fill;
            this.bunifuCustomLabel11.Font = new System.Drawing.Font("Segoe UI", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuCustomLabel11.Location = new System.Drawing.Point(10, 482);
            this.bunifuCustomLabel11.Margin = new System.Windows.Forms.Padding(10);
            this.bunifuCustomLabel11.Name = "bunifuCustomLabel11";
            this.bunifuCustomLabel11.Size = new System.Drawing.Size(242, 30);
            this.bunifuCustomLabel11.TabIndex = 2;
            this.bunifuCustomLabel11.Text = "Members List";
            this.bunifuCustomLabel11.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // datePickerEnd
            // 
            this.datePickerEnd.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.datePickerEnd.BackColor = System.Drawing.Color.White;
            this.datePickerEnd.BorderColor = System.Drawing.Color.Silver;
            this.datePickerEnd.BorderRadius = 17;
            this.datePickerEnd.CalendarFont = new System.Drawing.Font("Segoe UI", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.datePickerEnd.CausesValidation = false;
            this.datePickerEnd.Color = System.Drawing.Color.Silver;
            this.datePickerEnd.CustomFormat = "DD/MM/YYYY";
            this.datePickerEnd.DateBorderThickness = Bunifu.UI.WinForms.BunifuDatePicker.BorderThickness.Thin;
            this.datePickerEnd.DateTextAlign = Bunifu.UI.WinForms.BunifuDatePicker.TextAlign.Left;
            this.datePickerEnd.DisabledColor = System.Drawing.Color.Gray;
            this.datePickerEnd.DisplayWeekNumbers = false;
            this.datePickerEnd.DPHeight = 0;
            this.datePickerEnd.DropDownAlign = System.Windows.Forms.LeftRightAlignment.Right;
            this.datePickerEnd.Enabled = false;
            this.datePickerEnd.FillDatePicker = false;
            this.datePickerEnd.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.datePickerEnd.ForeColor = System.Drawing.Color.Black;
            this.datePickerEnd.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.datePickerEnd.Icon = ((System.Drawing.Image)(resources.GetObject("datePickerEnd.Icon")));
            this.datePickerEnd.IconColor = System.Drawing.Color.Gray;
            this.datePickerEnd.IconLocation = Bunifu.UI.WinForms.BunifuDatePicker.Indicator.Right;
            this.datePickerEnd.LeftTextMargin = 0;
            this.datePickerEnd.Location = new System.Drawing.Point(272, 426);
            this.datePickerEnd.Margin = new System.Windows.Forms.Padding(10);
            this.datePickerEnd.MinimumSize = new System.Drawing.Size(4, 32);
            this.datePickerEnd.Name = "datePickerEnd";
            this.datePickerEnd.Size = new System.Drawing.Size(207, 32);
            this.datePickerEnd.TabIndex = 3;
            this.datePickerEnd.Value = new System.DateTime(2025, 4, 27, 0, 0, 0, 0);
            // 
            // datePickerStart
            // 
            this.datePickerStart.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.datePickerStart.BackColor = System.Drawing.Color.White;
            this.datePickerStart.BorderColor = System.Drawing.Color.Silver;
            this.datePickerStart.BorderRadius = 17;
            this.datePickerStart.CalendarFont = new System.Drawing.Font("Segoe UI", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.datePickerStart.Color = System.Drawing.Color.Silver;
            this.datePickerStart.DateBorderThickness = Bunifu.UI.WinForms.BunifuDatePicker.BorderThickness.Thin;
            this.datePickerStart.DateTextAlign = Bunifu.UI.WinForms.BunifuDatePicker.TextAlign.Left;
            this.datePickerStart.DisabledColor = System.Drawing.Color.Gray;
            this.datePickerStart.DisplayWeekNumbers = false;
            this.datePickerStart.DPHeight = 0;
            this.datePickerStart.DropDownAlign = System.Windows.Forms.LeftRightAlignment.Right;
            this.datePickerStart.Enabled = false;
            this.datePickerStart.FillDatePicker = false;
            this.datePickerStart.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.datePickerStart.ForeColor = System.Drawing.Color.Black;
            this.datePickerStart.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.datePickerStart.Icon = ((System.Drawing.Image)(resources.GetObject("datePickerStart.Icon")));
            this.datePickerStart.IconColor = System.Drawing.Color.Gray;
            this.datePickerStart.IconLocation = Bunifu.UI.WinForms.BunifuDatePicker.Indicator.Right;
            this.datePickerStart.LeftTextMargin = 0;
            this.datePickerStart.Location = new System.Drawing.Point(272, 367);
            this.datePickerStart.Margin = new System.Windows.Forms.Padding(10);
            this.datePickerStart.MinimumSize = new System.Drawing.Size(4, 32);
            this.datePickerStart.Name = "datePickerStart";
            this.datePickerStart.Size = new System.Drawing.Size(206, 32);
            this.datePickerStart.TabIndex = 3;
            this.datePickerStart.Value = new System.DateTime(2025, 4, 9, 21, 27, 0, 0);
            // 
            // tbProjectCode
            // 
            this.tbProjectCode.AcceptsReturn = false;
            this.tbProjectCode.AcceptsTab = false;
            this.tbProjectCode.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.tbProjectCode.AnimationSpeed = 200;
            this.tbProjectCode.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.None;
            this.tbProjectCode.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.None;
            this.tbProjectCode.AutoSizeHeight = true;
            this.tbProjectCode.BackColor = System.Drawing.Color.Transparent;
            this.tbProjectCode.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("tbProjectCode.BackgroundImage")));
            this.tbProjectCode.BorderColorActive = System.Drawing.Color.DodgerBlue;
            this.tbProjectCode.BorderColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(204)))), ((int)(((byte)(204)))));
            this.tbProjectCode.BorderColorHover = System.Drawing.Color.FromArgb(((int)(((byte)(105)))), ((int)(((byte)(181)))), ((int)(((byte)(255)))));
            this.tbProjectCode.BorderColorIdle = System.Drawing.Color.Silver;
            this.tbProjectCode.BorderRadius = 30;
            this.tbProjectCode.BorderThickness = 1;
            this.tbProjectCode.CharacterCase = Bunifu.UI.WinForms.BunifuTextBox.CharacterCases.Normal;
            this.tbProjectCode.CharacterCasing = System.Windows.Forms.CharacterCasing.Normal;
            this.tbProjectCode.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.tbProjectCode.DefaultFont = new System.Drawing.Font("Segoe UI", 9.25F);
            this.tbProjectCode.DefaultText = "";
            this.tbProjectCode.FillColor = System.Drawing.Color.White;
            this.tbProjectCode.HideSelection = true;
            this.tbProjectCode.IconLeft = null;
            this.tbProjectCode.IconLeftCursor = System.Windows.Forms.Cursors.IBeam;
            this.tbProjectCode.IconPadding = 10;
            this.tbProjectCode.IconRight = null;
            this.tbProjectCode.IconRightCursor = System.Windows.Forms.Cursors.IBeam;
            this.tbProjectCode.Lines = new string[0];
            this.tbProjectCode.Location = new System.Drawing.Point(272, 126);
            this.tbProjectCode.Margin = new System.Windows.Forms.Padding(10);
            this.tbProjectCode.MaxLength = 32767;
            this.tbProjectCode.MinimumSize = new System.Drawing.Size(1, 1);
            this.tbProjectCode.Modified = false;
            this.tbProjectCode.Multiline = false;
            this.tbProjectCode.Name = "tbProjectCode";
            stateProperties9.BorderColor = System.Drawing.Color.DodgerBlue;
            stateProperties9.FillColor = System.Drawing.Color.Empty;
            stateProperties9.ForeColor = System.Drawing.Color.Empty;
            stateProperties9.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.tbProjectCode.OnActiveState = stateProperties9;
            stateProperties10.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(204)))), ((int)(((byte)(204)))));
            stateProperties10.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(240)))), ((int)(((byte)(240)))), ((int)(((byte)(240)))));
            stateProperties10.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            stateProperties10.PlaceholderForeColor = System.Drawing.Color.DarkGray;
            this.tbProjectCode.OnDisabledState = stateProperties10;
            stateProperties11.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(105)))), ((int)(((byte)(181)))), ((int)(((byte)(255)))));
            stateProperties11.FillColor = System.Drawing.Color.Empty;
            stateProperties11.ForeColor = System.Drawing.Color.Empty;
            stateProperties11.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.tbProjectCode.OnHoverState = stateProperties11;
            stateProperties12.BorderColor = System.Drawing.Color.Silver;
            stateProperties12.FillColor = System.Drawing.Color.White;
            stateProperties12.ForeColor = System.Drawing.Color.Empty;
            stateProperties12.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.tbProjectCode.OnIdleState = stateProperties12;
            this.tbProjectCode.Padding = new System.Windows.Forms.Padding(3);
            this.tbProjectCode.PasswordChar = '\0';
            this.tbProjectCode.PlaceholderForeColor = System.Drawing.Color.Silver;
            this.tbProjectCode.PlaceholderText = "";
            this.tbProjectCode.ReadOnly = true;
            this.tbProjectCode.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.tbProjectCode.SelectedText = "";
            this.tbProjectCode.SelectionLength = 0;
            this.tbProjectCode.SelectionStart = 0;
            this.tbProjectCode.ShortcutsEnabled = true;
            this.tbProjectCode.Size = new System.Drawing.Size(206, 40);
            this.tbProjectCode.Style = Bunifu.UI.WinForms.BunifuTextBox._Style.Bunifu;
            this.tbProjectCode.TabIndex = 4;
            this.tbProjectCode.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.tbProjectCode.TextMarginBottom = 0;
            this.tbProjectCode.TextMarginLeft = 3;
            this.tbProjectCode.TextMarginTop = 1;
            this.tbProjectCode.TextPlaceholder = "";
            this.tbProjectCode.UseSystemPasswordChar = false;
            this.tbProjectCode.WordWrap = true;
            // 
            // tbBudget
            // 
            this.tbBudget.AcceptsReturn = false;
            this.tbBudget.AcceptsTab = false;
            this.tbBudget.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.tbBudget.AnimationSpeed = 200;
            this.tbBudget.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.None;
            this.tbBudget.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.None;
            this.tbBudget.AutoSizeHeight = true;
            this.tbBudget.BackColor = System.Drawing.Color.Transparent;
            this.tbBudget.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("tbBudget.BackgroundImage")));
            this.tbBudget.BorderColorActive = System.Drawing.Color.DodgerBlue;
            this.tbBudget.BorderColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(204)))), ((int)(((byte)(204)))));
            this.tbBudget.BorderColorHover = System.Drawing.Color.FromArgb(((int)(((byte)(105)))), ((int)(((byte)(181)))), ((int)(((byte)(255)))));
            this.tbBudget.BorderColorIdle = System.Drawing.Color.Silver;
            this.tbBudget.BorderRadius = 30;
            this.tbBudget.BorderThickness = 1;
            this.tbBudget.CharacterCase = Bunifu.UI.WinForms.BunifuTextBox.CharacterCases.Normal;
            this.tbBudget.CharacterCasing = System.Windows.Forms.CharacterCasing.Normal;
            this.tbBudget.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.tbBudget.DefaultFont = new System.Drawing.Font("Segoe UI", 9.25F);
            this.tbBudget.DefaultText = "";
            this.tbBudget.FillColor = System.Drawing.Color.White;
            this.tbBudget.HideSelection = true;
            this.tbBudget.IconLeft = null;
            this.tbBudget.IconLeftCursor = System.Windows.Forms.Cursors.IBeam;
            this.tbBudget.IconPadding = 10;
            this.tbBudget.IconRight = null;
            this.tbBudget.IconRightCursor = System.Windows.Forms.Cursors.IBeam;
            this.tbBudget.Lines = new string[0];
            this.tbBudget.Location = new System.Drawing.Point(272, 186);
            this.tbBudget.Margin = new System.Windows.Forms.Padding(10);
            this.tbBudget.MaxLength = 32767;
            this.tbBudget.MinimumSize = new System.Drawing.Size(1, 1);
            this.tbBudget.Modified = false;
            this.tbBudget.Multiline = false;
            this.tbBudget.Name = "tbBudget";
            stateProperties13.BorderColor = System.Drawing.Color.DodgerBlue;
            stateProperties13.FillColor = System.Drawing.Color.Empty;
            stateProperties13.ForeColor = System.Drawing.Color.Empty;
            stateProperties13.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.tbBudget.OnActiveState = stateProperties13;
            stateProperties14.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(204)))), ((int)(((byte)(204)))));
            stateProperties14.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(240)))), ((int)(((byte)(240)))), ((int)(((byte)(240)))));
            stateProperties14.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            stateProperties14.PlaceholderForeColor = System.Drawing.Color.DarkGray;
            this.tbBudget.OnDisabledState = stateProperties14;
            stateProperties15.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(105)))), ((int)(((byte)(181)))), ((int)(((byte)(255)))));
            stateProperties15.FillColor = System.Drawing.Color.Empty;
            stateProperties15.ForeColor = System.Drawing.Color.Empty;
            stateProperties15.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.tbBudget.OnHoverState = stateProperties15;
            stateProperties16.BorderColor = System.Drawing.Color.Silver;
            stateProperties16.FillColor = System.Drawing.Color.White;
            stateProperties16.ForeColor = System.Drawing.Color.Empty;
            stateProperties16.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.tbBudget.OnIdleState = stateProperties16;
            this.tbBudget.Padding = new System.Windows.Forms.Padding(3);
            this.tbBudget.PasswordChar = '\0';
            this.tbBudget.PlaceholderForeColor = System.Drawing.Color.Silver;
            this.tbBudget.PlaceholderText = "";
            this.tbBudget.ReadOnly = true;
            this.tbBudget.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.tbBudget.SelectedText = "";
            this.tbBudget.SelectionLength = 0;
            this.tbBudget.SelectionStart = 0;
            this.tbBudget.ShortcutsEnabled = true;
            this.tbBudget.Size = new System.Drawing.Size(206, 40);
            this.tbBudget.Style = Bunifu.UI.WinForms.BunifuTextBox._Style.Bunifu;
            this.tbBudget.TabIndex = 8;
            this.tbBudget.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.tbBudget.TextMarginBottom = 0;
            this.tbBudget.TextMarginLeft = 3;
            this.tbBudget.TextMarginTop = 1;
            this.tbBudget.TextPlaceholder = "";
            this.tbBudget.UseSystemPasswordChar = false;
            this.tbBudget.WordWrap = true;
            // 
            // lbName
            // 
            this.lbName.BackColor = System.Drawing.Color.Transparent;
            this.tableLayoutPanel1.SetColumnSpan(this.lbName, 2);
            this.lbName.Font = new System.Drawing.Font("Segoe UI Semibold", 25F, System.Drawing.FontStyle.Bold);
            this.lbName.Location = new System.Drawing.Point(10, 50);
            this.lbName.Margin = new System.Windows.Forms.Padding(10);
            this.lbName.Name = "lbName";
            this.lbName.Size = new System.Drawing.Size(486, 56);
            this.lbName.TabIndex = 28;
            this.lbName.Text = "Make a Suitable form";
            this.lbName.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // labelWithImage1
            // 
            this.labelWithImage1.Image = global::PresentationLayer.Properties.Resources.hashtag;
            this.labelWithImage1.Location = new System.Drawing.Point(10, 126);
            this.labelWithImage1.Margin = new System.Windows.Forms.Padding(10);
            this.labelWithImage1.Name = "labelWithImage1";
            this.labelWithImage1.Size = new System.Drawing.Size(166, 39);
            this.labelWithImage1.TabIndex = 36;
            this.labelWithImage1.TextLabel = "Code";
            // 
            // labelWithImage2
            // 
            this.labelWithImage2.Image = global::PresentationLayer.Properties.Resources.budget;
            this.labelWithImage2.Location = new System.Drawing.Point(10, 186);
            this.labelWithImage2.Margin = new System.Windows.Forms.Padding(10);
            this.labelWithImage2.Name = "labelWithImage2";
            this.labelWithImage2.Size = new System.Drawing.Size(166, 39);
            this.labelWithImage2.TabIndex = 36;
            this.labelWithImage2.TextLabel = "Budget";
            // 
            // labelWithImage3
            // 
            this.labelWithImage3.Image = global::PresentationLayer.Properties.Resources.status;
            this.labelWithImage3.Location = new System.Drawing.Point(10, 246);
            this.labelWithImage3.Margin = new System.Windows.Forms.Padding(10);
            this.labelWithImage3.Name = "labelWithImage3";
            this.labelWithImage3.Size = new System.Drawing.Size(166, 39);
            this.labelWithImage3.TabIndex = 36;
            this.labelWithImage3.TextLabel = "Status";
            // 
            // labelWithImage4
            // 
            this.labelWithImage4.Image = global::PresentationLayer.Properties.Resources.priority;
            this.labelWithImage4.Location = new System.Drawing.Point(10, 305);
            this.labelWithImage4.Margin = new System.Windows.Forms.Padding(10);
            this.labelWithImage4.Name = "labelWithImage4";
            this.labelWithImage4.Size = new System.Drawing.Size(166, 39);
            this.labelWithImage4.TabIndex = 36;
            this.labelWithImage4.TextLabel = "Priority";
            // 
            // labelWithImage5
            // 
            this.labelWithImage5.Image = global::PresentationLayer.Properties.Resources.startDate;
            this.labelWithImage5.Location = new System.Drawing.Point(10, 364);
            this.labelWithImage5.Margin = new System.Windows.Forms.Padding(10);
            this.labelWithImage5.Name = "labelWithImage5";
            this.labelWithImage5.Size = new System.Drawing.Size(166, 39);
            this.labelWithImage5.TabIndex = 36;
            this.labelWithImage5.TextLabel = "Start";
            // 
            // labelWithImage6
            // 
            this.labelWithImage6.Image = global::PresentationLayer.Properties.Resources.endDate;
            this.labelWithImage6.Location = new System.Drawing.Point(10, 423);
            this.labelWithImage6.Margin = new System.Windows.Forms.Padding(10);
            this.labelWithImage6.Name = "labelWithImage6";
            this.labelWithImage6.Size = new System.Drawing.Size(166, 39);
            this.labelWithImage6.TabIndex = 36;
            this.labelWithImage6.TextLabel = "End";
            // 
            // CtrlPanelProjectNew
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.Controls.Add(this.splitContainer1);
            this.DoubleBuffered = true;
            this.Name = "CtrlPanelProjectNew";
            this.Size = new System.Drawing.Size(1535, 899);
            this.Load += new System.EventHandler(this.CtrlPanelTaskAdminNew_Load);
            this.splitContainer1.Panel1.ResumeLayout(false);
            this.splitContainer1.Panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer1)).EndInit();
            this.splitContainer1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgvItems)).EndInit();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.tableLayoutPanel1.ResumeLayout(false);
            this.tableLayoutPanel1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.SplitContainer splitContainer1;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel1;
        private Bunifu.UI.WinForms.BunifuTextBox tbBudget;
        private Bunifu.UI.WinForms.BunifuDatePicker datePickerEnd;
        private Bunifu.UI.WinForms.BunifuDatePicker datePickerStart;
        private Bunifu.Framework.UI.BunifuCustomLabel bunifuCustomLabel6;
        private Bunifu.UI.WinForms.BunifuTextBox tbProjectDesrciption;
        private Bunifu.Framework.UI.BunifuCustomLabel bunifuCustomLabel11;
        private Bunifu.UI.WinForms.BunifuDataGridView dgvItems;
        private System.Windows.Forms.ListView listviewMembers;
        private System.Windows.Forms.ColumnHeader id;
        private System.Windows.Forms.ColumnHeader name;
        private System.Windows.Forms.ColumnHeader role;
        private CustomControls.RoundedLabel lbPriority;
        private CustomControls.RoundedLabel lbStatus;
        private Bunifu.UI.WinForms.BunifuTextBox tbSearch;
        private CustomControls.RoundedLabel lbProjects;
        private Bunifu.UI.WinForms.BunifuLabel lbShortDescription;
        private Bunifu.UI.WinForms.BunifuTextBox tbProjectCode;
        private Bunifu.Framework.UI.BunifuCustomLabel lbName;
        private Others.LabelWithImage labelWithImage1;
        private Others.LabelWithImage labelWithImage2;
        private Others.LabelWithImage labelWithImage3;
        private Others.LabelWithImage labelWithImage4;
        private Others.LabelWithImage labelWithImage5;
        private Others.LabelWithImage labelWithImage6;
    }
}
