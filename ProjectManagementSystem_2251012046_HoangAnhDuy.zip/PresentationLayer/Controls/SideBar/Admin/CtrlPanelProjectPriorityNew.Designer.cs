﻿namespace PresentationLayer.Controls.SideBar.Admin
{
    partial class CtrlPanelProjectPriorityNew
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(CtrlPanelProjectPriorityNew));
            Bunifu.UI.WinForms.BunifuTextBox.StateProperties stateProperties1 = new Bunifu.UI.WinForms.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextBox.StateProperties stateProperties2 = new Bunifu.UI.WinForms.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextBox.StateProperties stateProperties3 = new Bunifu.UI.WinForms.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextBox.StateProperties stateProperties4 = new Bunifu.UI.WinForms.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextBox.StateProperties stateProperties5 = new Bunifu.UI.WinForms.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextBox.StateProperties stateProperties6 = new Bunifu.UI.WinForms.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextBox.StateProperties stateProperties7 = new Bunifu.UI.WinForms.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextBox.StateProperties stateProperties8 = new Bunifu.UI.WinForms.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextBox.StateProperties stateProperties9 = new Bunifu.UI.WinForms.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextBox.StateProperties stateProperties10 = new Bunifu.UI.WinForms.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextBox.StateProperties stateProperties11 = new Bunifu.UI.WinForms.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextBox.StateProperties stateProperties12 = new Bunifu.UI.WinForms.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextBox.StateProperties stateProperties13 = new Bunifu.UI.WinForms.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextBox.StateProperties stateProperties14 = new Bunifu.UI.WinForms.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextBox.StateProperties stateProperties15 = new Bunifu.UI.WinForms.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextBox.StateProperties stateProperties16 = new Bunifu.UI.WinForms.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuButton.BunifuButton2.BorderEdges borderEdges1 = new Bunifu.UI.WinForms.BunifuButton.BunifuButton2.BorderEdges();
            Bunifu.UI.WinForms.BunifuButton.BunifuButton2.BorderEdges borderEdges2 = new Bunifu.UI.WinForms.BunifuButton.BunifuButton2.BorderEdges();
            Bunifu.UI.WinForms.BunifuButton.BunifuButton2.BorderEdges borderEdges3 = new Bunifu.UI.WinForms.BunifuButton.BunifuButton2.BorderEdges();
            this.splitContainer1 = new System.Windows.Forms.SplitContainer();
            this.dgvItems = new Bunifu.UI.WinForms.BunifuDataGridView();
            this.panel1 = new System.Windows.Forms.Panel();
            this.tbSearch = new Bunifu.UI.WinForms.BunifuTextBox();
            this.tableLayoutPanel1 = new System.Windows.Forms.TableLayoutPanel();
            this.bunifuCustomLabel5 = new Bunifu.Framework.UI.BunifuCustomLabel();
            this.bunifuCustomLabel1 = new Bunifu.Framework.UI.BunifuCustomLabel();
            this.tbName = new Bunifu.UI.WinForms.BunifuTextBox();
            this.tbId = new Bunifu.UI.WinForms.BunifuTextBox();
            this.bunifuCustomLabel6 = new Bunifu.Framework.UI.BunifuCustomLabel();
            this.tbDescription = new Bunifu.UI.WinForms.BunifuTextBox();
            this.btCreateProject = new Bunifu.UI.WinForms.BunifuButton.BunifuButton2();
            this.flowLayoutPanel1 = new System.Windows.Forms.FlowLayoutPanel();
            this.btnUpdate = new Bunifu.UI.WinForms.BunifuButton.BunifuButton2();
            this.btCancel = new Bunifu.UI.WinForms.BunifuButton.BunifuButton2();
            this.lbProjects = new PresentationLayer.CustomControls.RoundedLabel();
            this.roundedLabel1 = new PresentationLayer.CustomControls.RoundedLabel();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer1)).BeginInit();
            this.splitContainer1.Panel1.SuspendLayout();
            this.splitContainer1.Panel2.SuspendLayout();
            this.splitContainer1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvItems)).BeginInit();
            this.panel1.SuspendLayout();
            this.tableLayoutPanel1.SuspendLayout();
            this.flowLayoutPanel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // splitContainer1
            // 
            this.splitContainer1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitContainer1.Location = new System.Drawing.Point(0, 0);
            this.splitContainer1.Name = "splitContainer1";
            // 
            // splitContainer1.Panel1
            // 
            this.splitContainer1.Panel1.Controls.Add(this.dgvItems);
            this.splitContainer1.Panel1.Controls.Add(this.panel1);
            this.splitContainer1.Panel1.Padding = new System.Windows.Forms.Padding(10, 10, 10, 10);
            // 
            // splitContainer1.Panel2
            // 
            this.splitContainer1.Panel2.AutoScroll = true;
            this.splitContainer1.Panel2.Controls.Add(this.tableLayoutPanel1);
            this.splitContainer1.Size = new System.Drawing.Size(1535, 899);
            this.splitContainer1.SplitterDistance = 787;
            this.splitContainer1.TabIndex = 0;
            this.splitContainer1.Paint += new System.Windows.Forms.PaintEventHandler(this.splitContainer1_Paint);
            // 
            // dgvItems
            // 
            this.dgvItems.AllowCustomTheming = false;
            dataGridViewCellStyle1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(248)))), ((int)(((byte)(251)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle1.ForeColor = System.Drawing.Color.Black;
            this.dgvItems.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle1;
            this.dgvItems.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgvItems.BackgroundColor = System.Drawing.Color.WhiteSmoke;
            this.dgvItems.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.dgvItems.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.SingleHorizontal;
            this.dgvItems.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle2.BackColor = System.Drawing.Color.DodgerBlue;
            dataGridViewCellStyle2.Font = new System.Drawing.Font("Segoe UI Semibold", 11.75F, System.Drawing.FontStyle.Bold);
            dataGridViewCellStyle2.ForeColor = System.Drawing.Color.White;
            dataGridViewCellStyle2.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(24)))), ((int)(((byte)(115)))), ((int)(((byte)(204)))));
            dataGridViewCellStyle2.SelectionForeColor = System.Drawing.Color.White;
            dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvItems.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle2;
            this.dgvItems.ColumnHeadersHeight = 40;
            this.dgvItems.CurrentTheme.AlternatingRowsStyle.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(248)))), ((int)(((byte)(251)))), ((int)(((byte)(255)))));
            this.dgvItems.CurrentTheme.AlternatingRowsStyle.Font = new System.Drawing.Font("Segoe UI Semibold", 9.75F, System.Drawing.FontStyle.Bold);
            this.dgvItems.CurrentTheme.AlternatingRowsStyle.ForeColor = System.Drawing.Color.Black;
            this.dgvItems.CurrentTheme.AlternatingRowsStyle.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(210)))), ((int)(((byte)(232)))), ((int)(((byte)(255)))));
            this.dgvItems.CurrentTheme.AlternatingRowsStyle.SelectionForeColor = System.Drawing.Color.Black;
            this.dgvItems.CurrentTheme.BackColor = System.Drawing.Color.White;
            this.dgvItems.CurrentTheme.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(221)))), ((int)(((byte)(238)))), ((int)(((byte)(255)))));
            this.dgvItems.CurrentTheme.HeaderStyle.BackColor = System.Drawing.Color.DodgerBlue;
            this.dgvItems.CurrentTheme.HeaderStyle.Font = new System.Drawing.Font("Segoe UI Semibold", 11.75F, System.Drawing.FontStyle.Bold);
            this.dgvItems.CurrentTheme.HeaderStyle.ForeColor = System.Drawing.Color.White;
            this.dgvItems.CurrentTheme.HeaderStyle.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(24)))), ((int)(((byte)(115)))), ((int)(((byte)(204)))));
            this.dgvItems.CurrentTheme.HeaderStyle.SelectionForeColor = System.Drawing.Color.White;
            this.dgvItems.CurrentTheme.Name = null;
            this.dgvItems.CurrentTheme.RowsStyle.BackColor = System.Drawing.Color.White;
            this.dgvItems.CurrentTheme.RowsStyle.Font = new System.Drawing.Font("Segoe UI Semibold", 9.75F, System.Drawing.FontStyle.Bold);
            this.dgvItems.CurrentTheme.RowsStyle.ForeColor = System.Drawing.Color.Black;
            this.dgvItems.CurrentTheme.RowsStyle.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(210)))), ((int)(((byte)(232)))), ((int)(((byte)(255)))));
            this.dgvItems.CurrentTheme.RowsStyle.SelectionForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle3.BackColor = System.Drawing.Color.White;
            dataGridViewCellStyle3.Font = new System.Drawing.Font("Segoe UI Semibold", 9.75F, System.Drawing.FontStyle.Bold);
            dataGridViewCellStyle3.ForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle3.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(210)))), ((int)(((byte)(232)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle3.SelectionForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle3.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dgvItems.DefaultCellStyle = dataGridViewCellStyle3;
            this.dgvItems.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dgvItems.EnableHeadersVisualStyles = false;
            this.dgvItems.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(221)))), ((int)(((byte)(238)))), ((int)(((byte)(255)))));
            this.dgvItems.HeaderBackColor = System.Drawing.Color.DodgerBlue;
            this.dgvItems.HeaderBgColor = System.Drawing.Color.Empty;
            this.dgvItems.HeaderForeColor = System.Drawing.Color.White;
            this.dgvItems.Location = new System.Drawing.Point(10, 99);
            this.dgvItems.Name = "dgvItems";
            this.dgvItems.RowHeadersVisible = false;
            this.dgvItems.RowHeadersWidth = 62;
            this.dgvItems.RowTemplate.Height = 40;
            this.dgvItems.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvItems.Size = new System.Drawing.Size(767, 790);
            this.dgvItems.TabIndex = 6;
            this.dgvItems.Theme = Bunifu.UI.WinForms.BunifuDataGridView.PresetThemes.Light;
            this.dgvItems.SelectionChanged += new System.EventHandler(this.dgvItems_SelectionChanged);
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.tbSearch);
            this.panel1.Controls.Add(this.roundedLabel1);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel1.Location = new System.Drawing.Point(10, 10);
            this.panel1.Name = "panel1";
            this.panel1.Padding = new System.Windows.Forms.Padding(0, 0, 0, 8);
            this.panel1.Size = new System.Drawing.Size(767, 89);
            this.panel1.TabIndex = 5;
            // 
            // tbSearch
            // 
            this.tbSearch.AcceptsReturn = false;
            this.tbSearch.AcceptsTab = false;
            this.tbSearch.AnimationSpeed = 200;
            this.tbSearch.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.None;
            this.tbSearch.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.None;
            this.tbSearch.AutoSizeHeight = true;
            this.tbSearch.BackColor = System.Drawing.Color.Transparent;
            this.tbSearch.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("tbSearch.BackgroundImage")));
            this.tbSearch.BorderColorActive = System.Drawing.Color.DodgerBlue;
            this.tbSearch.BorderColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(204)))), ((int)(((byte)(204)))));
            this.tbSearch.BorderColorHover = System.Drawing.Color.FromArgb(((int)(((byte)(105)))), ((int)(((byte)(181)))), ((int)(((byte)(255)))));
            this.tbSearch.BorderColorIdle = System.Drawing.Color.Silver;
            this.tbSearch.BorderRadius = 25;
            this.tbSearch.BorderThickness = 1;
            this.tbSearch.CharacterCase = Bunifu.UI.WinForms.BunifuTextBox.CharacterCases.Normal;
            this.tbSearch.CharacterCasing = System.Windows.Forms.CharacterCasing.Normal;
            this.tbSearch.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.tbSearch.DefaultFont = new System.Drawing.Font("Segoe UI", 9.25F);
            this.tbSearch.DefaultText = "";
            this.tbSearch.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tbSearch.FillColor = System.Drawing.Color.White;
            this.tbSearch.HideSelection = true;
            this.tbSearch.IconLeft = null;
            this.tbSearch.IconLeftCursor = System.Windows.Forms.Cursors.IBeam;
            this.tbSearch.IconPadding = 10;
            this.tbSearch.IconRight = null;
            this.tbSearch.IconRightCursor = System.Windows.Forms.Cursors.IBeam;
            this.tbSearch.Lines = new string[0];
            this.tbSearch.Location = new System.Drawing.Point(0, 34);
            this.tbSearch.MaxLength = 32767;
            this.tbSearch.MinimumSize = new System.Drawing.Size(1, 1);
            this.tbSearch.Modified = false;
            this.tbSearch.Multiline = false;
            this.tbSearch.Name = "tbSearch";
            stateProperties1.BorderColor = System.Drawing.Color.DodgerBlue;
            stateProperties1.FillColor = System.Drawing.Color.Empty;
            stateProperties1.ForeColor = System.Drawing.Color.Empty;
            stateProperties1.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.tbSearch.OnActiveState = stateProperties1;
            stateProperties2.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(204)))), ((int)(((byte)(204)))));
            stateProperties2.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(240)))), ((int)(((byte)(240)))), ((int)(((byte)(240)))));
            stateProperties2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            stateProperties2.PlaceholderForeColor = System.Drawing.Color.DarkGray;
            this.tbSearch.OnDisabledState = stateProperties2;
            stateProperties3.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(105)))), ((int)(((byte)(181)))), ((int)(((byte)(255)))));
            stateProperties3.FillColor = System.Drawing.Color.Empty;
            stateProperties3.ForeColor = System.Drawing.Color.Empty;
            stateProperties3.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.tbSearch.OnHoverState = stateProperties3;
            stateProperties4.BorderColor = System.Drawing.Color.Silver;
            stateProperties4.FillColor = System.Drawing.Color.White;
            stateProperties4.ForeColor = System.Drawing.Color.Empty;
            stateProperties4.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.tbSearch.OnIdleState = stateProperties4;
            this.tbSearch.Padding = new System.Windows.Forms.Padding(3, 3, 3, 3);
            this.tbSearch.PasswordChar = '\0';
            this.tbSearch.PlaceholderForeColor = System.Drawing.Color.Silver;
            this.tbSearch.PlaceholderText = "Enter text";
            this.tbSearch.ReadOnly = false;
            this.tbSearch.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.tbSearch.SelectedText = "";
            this.tbSearch.SelectionLength = 0;
            this.tbSearch.SelectionStart = 0;
            this.tbSearch.ShortcutsEnabled = true;
            this.tbSearch.Size = new System.Drawing.Size(767, 47);
            this.tbSearch.Style = Bunifu.UI.WinForms.BunifuTextBox._Style.Bunifu;
            this.tbSearch.TabIndex = 4;
            this.tbSearch.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.tbSearch.TextMarginBottom = 0;
            this.tbSearch.TextMarginLeft = 3;
            this.tbSearch.TextMarginTop = 1;
            this.tbSearch.TextPlaceholder = "Enter text";
            this.tbSearch.UseSystemPasswordChar = false;
            this.tbSearch.WordWrap = true;
            this.tbSearch.KeyDown += new System.Windows.Forms.KeyEventHandler(this.tbSearch_KeyDown);
            // 
            // tableLayoutPanel1
            // 
            this.tableLayoutPanel1.ColumnCount = 3;
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle());
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle());
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 10F));
            this.tableLayoutPanel1.Controls.Add(this.bunifuCustomLabel5, 1, 0);
            this.tableLayoutPanel1.Controls.Add(this.bunifuCustomLabel1, 0, 0);
            this.tableLayoutPanel1.Controls.Add(this.tbName, 1, 1);
            this.tableLayoutPanel1.Controls.Add(this.tbId, 0, 1);
            this.tableLayoutPanel1.Controls.Add(this.bunifuCustomLabel6, 0, 2);
            this.tableLayoutPanel1.Controls.Add(this.tbDescription, 0, 3);
            this.tableLayoutPanel1.Controls.Add(this.btCreateProject, 0, 6);
            this.tableLayoutPanel1.Controls.Add(this.flowLayoutPanel1, 1, 6);
            this.tableLayoutPanel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel1.Location = new System.Drawing.Point(0, 0);
            this.tableLayoutPanel1.Name = "tableLayoutPanel1";
            this.tableLayoutPanel1.RowCount = 8;
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel1.Size = new System.Drawing.Size(744, 899);
            this.tableLayoutPanel1.TabIndex = 2;
            // 
            // bunifuCustomLabel5
            // 
            this.bunifuCustomLabel5.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.bunifuCustomLabel5.AutoSize = true;
            this.bunifuCustomLabel5.BackColor = System.Drawing.Color.Transparent;
            this.bunifuCustomLabel5.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuCustomLabel5.Location = new System.Drawing.Point(271, 10);
            this.bunifuCustomLabel5.Margin = new System.Windows.Forms.Padding(10, 10, 10, 10);
            this.bunifuCustomLabel5.Name = "bunifuCustomLabel5";
            this.bunifuCustomLabel5.Size = new System.Drawing.Size(55, 20);
            this.bunifuCustomLabel5.TabIndex = 7;
            this.bunifuCustomLabel5.Text = "Name";
            this.bunifuCustomLabel5.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // bunifuCustomLabel1
            // 
            this.bunifuCustomLabel1.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.bunifuCustomLabel1.BackColor = System.Drawing.Color.Transparent;
            this.bunifuCustomLabel1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuCustomLabel1.Location = new System.Drawing.Point(10, 10);
            this.bunifuCustomLabel1.Margin = new System.Windows.Forms.Padding(10, 10, 10, 10);
            this.bunifuCustomLabel1.Name = "bunifuCustomLabel1";
            this.bunifuCustomLabel1.Size = new System.Drawing.Size(51, 20);
            this.bunifuCustomLabel1.TabIndex = 2;
            this.bunifuCustomLabel1.Text = "Id";
            this.bunifuCustomLabel1.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // tbName
            // 
            this.tbName.AcceptsReturn = false;
            this.tbName.AcceptsTab = false;
            this.tbName.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.tbName.AnimationSpeed = 200;
            this.tbName.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.None;
            this.tbName.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.None;
            this.tbName.AutoSizeHeight = true;
            this.tbName.BackColor = System.Drawing.Color.Transparent;
            this.tbName.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("tbName.BackgroundImage")));
            this.tbName.BorderColorActive = System.Drawing.Color.DodgerBlue;
            this.tbName.BorderColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(204)))), ((int)(((byte)(204)))));
            this.tbName.BorderColorHover = System.Drawing.Color.FromArgb(((int)(((byte)(105)))), ((int)(((byte)(181)))), ((int)(((byte)(255)))));
            this.tbName.BorderColorIdle = System.Drawing.Color.Silver;
            this.tbName.BorderRadius = 30;
            this.tbName.BorderThickness = 1;
            this.tbName.CharacterCase = Bunifu.UI.WinForms.BunifuTextBox.CharacterCases.Normal;
            this.tbName.CharacterCasing = System.Windows.Forms.CharacterCasing.Normal;
            this.tbName.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.tbName.DefaultFont = new System.Drawing.Font("Segoe UI", 9.25F);
            this.tbName.DefaultText = "";
            this.tbName.FillColor = System.Drawing.Color.White;
            this.tbName.HideSelection = true;
            this.tbName.IconLeft = null;
            this.tbName.IconLeftCursor = System.Windows.Forms.Cursors.IBeam;
            this.tbName.IconPadding = 10;
            this.tbName.IconRight = null;
            this.tbName.IconRightCursor = System.Windows.Forms.Cursors.IBeam;
            this.tbName.Lines = new string[0];
            this.tbName.Location = new System.Drawing.Point(271, 50);
            this.tbName.Margin = new System.Windows.Forms.Padding(10, 10, 10, 10);
            this.tbName.MaxLength = 32767;
            this.tbName.MinimumSize = new System.Drawing.Size(1, 1);
            this.tbName.Modified = false;
            this.tbName.Multiline = false;
            this.tbName.Name = "tbName";
            stateProperties5.BorderColor = System.Drawing.Color.DodgerBlue;
            stateProperties5.FillColor = System.Drawing.Color.Empty;
            stateProperties5.ForeColor = System.Drawing.Color.Empty;
            stateProperties5.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.tbName.OnActiveState = stateProperties5;
            stateProperties6.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(204)))), ((int)(((byte)(204)))));
            stateProperties6.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(240)))), ((int)(((byte)(240)))), ((int)(((byte)(240)))));
            stateProperties6.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            stateProperties6.PlaceholderForeColor = System.Drawing.Color.DarkGray;
            this.tbName.OnDisabledState = stateProperties6;
            stateProperties7.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(105)))), ((int)(((byte)(181)))), ((int)(((byte)(255)))));
            stateProperties7.FillColor = System.Drawing.Color.Empty;
            stateProperties7.ForeColor = System.Drawing.Color.Empty;
            stateProperties7.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.tbName.OnHoverState = stateProperties7;
            stateProperties8.BorderColor = System.Drawing.Color.Silver;
            stateProperties8.FillColor = System.Drawing.Color.White;
            stateProperties8.ForeColor = System.Drawing.Color.Empty;
            stateProperties8.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.tbName.OnIdleState = stateProperties8;
            this.tbName.Padding = new System.Windows.Forms.Padding(3, 3, 3, 3);
            this.tbName.PasswordChar = '\0';
            this.tbName.PlaceholderForeColor = System.Drawing.Color.Silver;
            this.tbName.PlaceholderText = "";
            this.tbName.ReadOnly = false;
            this.tbName.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.tbName.SelectedText = "";
            this.tbName.SelectionLength = 0;
            this.tbName.SelectionStart = 0;
            this.tbName.ShortcutsEnabled = true;
            this.tbName.Size = new System.Drawing.Size(206, 39);
            this.tbName.Style = Bunifu.UI.WinForms.BunifuTextBox._Style.Bunifu;
            this.tbName.TabIndex = 3;
            this.tbName.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.tbName.TextMarginBottom = 0;
            this.tbName.TextMarginLeft = 3;
            this.tbName.TextMarginTop = 1;
            this.tbName.TextPlaceholder = "";
            this.tbName.UseSystemPasswordChar = false;
            this.tbName.WordWrap = true;
            // 
            // tbId
            // 
            this.tbId.AcceptsReturn = false;
            this.tbId.AcceptsTab = false;
            this.tbId.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.tbId.AnimationSpeed = 200;
            this.tbId.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.None;
            this.tbId.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.None;
            this.tbId.AutoSizeHeight = true;
            this.tbId.BackColor = System.Drawing.Color.Transparent;
            this.tbId.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("tbId.BackgroundImage")));
            this.tbId.BorderColorActive = System.Drawing.Color.DodgerBlue;
            this.tbId.BorderColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(204)))), ((int)(((byte)(204)))));
            this.tbId.BorderColorHover = System.Drawing.Color.FromArgb(((int)(((byte)(105)))), ((int)(((byte)(181)))), ((int)(((byte)(255)))));
            this.tbId.BorderColorIdle = System.Drawing.Color.Silver;
            this.tbId.BorderRadius = 30;
            this.tbId.BorderThickness = 1;
            this.tbId.CharacterCase = Bunifu.UI.WinForms.BunifuTextBox.CharacterCases.Normal;
            this.tbId.CharacterCasing = System.Windows.Forms.CharacterCasing.Normal;
            this.tbId.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.tbId.DefaultFont = new System.Drawing.Font("Segoe UI", 9.25F);
            this.tbId.DefaultText = "";
            this.tbId.FillColor = System.Drawing.Color.White;
            this.tbId.HideSelection = true;
            this.tbId.IconLeft = null;
            this.tbId.IconLeftCursor = System.Windows.Forms.Cursors.IBeam;
            this.tbId.IconPadding = 10;
            this.tbId.IconRight = null;
            this.tbId.IconRightCursor = System.Windows.Forms.Cursors.IBeam;
            this.tbId.Lines = new string[0];
            this.tbId.Location = new System.Drawing.Point(10, 50);
            this.tbId.Margin = new System.Windows.Forms.Padding(10, 10, 10, 10);
            this.tbId.MaxLength = 32767;
            this.tbId.MinimumSize = new System.Drawing.Size(1, 1);
            this.tbId.Modified = false;
            this.tbId.Multiline = false;
            this.tbId.Name = "tbId";
            stateProperties9.BorderColor = System.Drawing.Color.DodgerBlue;
            stateProperties9.FillColor = System.Drawing.Color.Empty;
            stateProperties9.ForeColor = System.Drawing.Color.Empty;
            stateProperties9.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.tbId.OnActiveState = stateProperties9;
            stateProperties10.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(204)))), ((int)(((byte)(204)))));
            stateProperties10.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(240)))), ((int)(((byte)(240)))), ((int)(((byte)(240)))));
            stateProperties10.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            stateProperties10.PlaceholderForeColor = System.Drawing.Color.DarkGray;
            this.tbId.OnDisabledState = stateProperties10;
            stateProperties11.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(105)))), ((int)(((byte)(181)))), ((int)(((byte)(255)))));
            stateProperties11.FillColor = System.Drawing.Color.Empty;
            stateProperties11.ForeColor = System.Drawing.Color.Empty;
            stateProperties11.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.tbId.OnHoverState = stateProperties11;
            stateProperties12.BorderColor = System.Drawing.Color.Silver;
            stateProperties12.FillColor = System.Drawing.Color.White;
            stateProperties12.ForeColor = System.Drawing.Color.Empty;
            stateProperties12.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.tbId.OnIdleState = stateProperties12;
            this.tbId.Padding = new System.Windows.Forms.Padding(3, 3, 3, 3);
            this.tbId.PasswordChar = '\0';
            this.tbId.PlaceholderForeColor = System.Drawing.Color.Silver;
            this.tbId.PlaceholderText = "";
            this.tbId.ReadOnly = false;
            this.tbId.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.tbId.SelectedText = "";
            this.tbId.SelectionLength = 0;
            this.tbId.SelectionStart = 0;
            this.tbId.ShortcutsEnabled = true;
            this.tbId.Size = new System.Drawing.Size(227, 39);
            this.tbId.Style = Bunifu.UI.WinForms.BunifuTextBox._Style.Bunifu;
            this.tbId.TabIndex = 4;
            this.tbId.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.tbId.TextMarginBottom = 0;
            this.tbId.TextMarginLeft = 3;
            this.tbId.TextMarginTop = 1;
            this.tbId.TextPlaceholder = "";
            this.tbId.UseSystemPasswordChar = false;
            this.tbId.WordWrap = true;
            // 
            // bunifuCustomLabel6
            // 
            this.bunifuCustomLabel6.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.bunifuCustomLabel6.BackColor = System.Drawing.Color.Transparent;
            this.bunifuCustomLabel6.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuCustomLabel6.Location = new System.Drawing.Point(10, 109);
            this.bunifuCustomLabel6.Margin = new System.Windows.Forms.Padding(10, 10, 10, 10);
            this.bunifuCustomLabel6.Name = "bunifuCustomLabel6";
            this.bunifuCustomLabel6.Size = new System.Drawing.Size(241, 34);
            this.bunifuCustomLabel6.TabIndex = 17;
            this.bunifuCustomLabel6.Text = "Project Priority Description";
            this.bunifuCustomLabel6.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // tbDescription
            // 
            this.tbDescription.AcceptsReturn = false;
            this.tbDescription.AcceptsTab = false;
            this.tbDescription.AnimationSpeed = 200;
            this.tbDescription.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.None;
            this.tbDescription.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.None;
            this.tbDescription.AutoSizeHeight = true;
            this.tbDescription.BackColor = System.Drawing.Color.Transparent;
            this.tbDescription.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("tbDescription.BackgroundImage")));
            this.tbDescription.BorderColorActive = System.Drawing.Color.DodgerBlue;
            this.tbDescription.BorderColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(204)))), ((int)(((byte)(204)))));
            this.tbDescription.BorderColorHover = System.Drawing.Color.FromArgb(((int)(((byte)(105)))), ((int)(((byte)(181)))), ((int)(((byte)(255)))));
            this.tbDescription.BorderColorIdle = System.Drawing.Color.Silver;
            this.tbDescription.BorderRadius = 30;
            this.tbDescription.BorderThickness = 1;
            this.tbDescription.CharacterCase = Bunifu.UI.WinForms.BunifuTextBox.CharacterCases.Normal;
            this.tbDescription.CharacterCasing = System.Windows.Forms.CharacterCasing.Normal;
            this.tableLayoutPanel1.SetColumnSpan(this.tbDescription, 2);
            this.tbDescription.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.tbDescription.DefaultFont = new System.Drawing.Font("Segoe UI", 9.25F);
            this.tbDescription.DefaultText = "";
            this.tbDescription.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tbDescription.FillColor = System.Drawing.Color.White;
            this.tbDescription.HideSelection = true;
            this.tbDescription.IconLeft = null;
            this.tbDescription.IconLeftCursor = System.Windows.Forms.Cursors.IBeam;
            this.tbDescription.IconPadding = 10;
            this.tbDescription.IconRight = null;
            this.tbDescription.IconRightCursor = System.Windows.Forms.Cursors.IBeam;
            this.tbDescription.Lines = new string[0];
            this.tbDescription.Location = new System.Drawing.Point(10, 163);
            this.tbDescription.Margin = new System.Windows.Forms.Padding(10, 10, 10, 10);
            this.tbDescription.MaxLength = 32767;
            this.tbDescription.MinimumSize = new System.Drawing.Size(1, 1);
            this.tbDescription.Modified = false;
            this.tbDescription.Multiline = true;
            this.tbDescription.Name = "tbDescription";
            stateProperties13.BorderColor = System.Drawing.Color.DodgerBlue;
            stateProperties13.FillColor = System.Drawing.Color.Empty;
            stateProperties13.ForeColor = System.Drawing.Color.Empty;
            stateProperties13.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.tbDescription.OnActiveState = stateProperties13;
            stateProperties14.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(204)))), ((int)(((byte)(204)))));
            stateProperties14.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(240)))), ((int)(((byte)(240)))), ((int)(((byte)(240)))));
            stateProperties14.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            stateProperties14.PlaceholderForeColor = System.Drawing.Color.DarkGray;
            this.tbDescription.OnDisabledState = stateProperties14;
            stateProperties15.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(105)))), ((int)(((byte)(181)))), ((int)(((byte)(255)))));
            stateProperties15.FillColor = System.Drawing.Color.Empty;
            stateProperties15.ForeColor = System.Drawing.Color.Empty;
            stateProperties15.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.tbDescription.OnHoverState = stateProperties15;
            stateProperties16.BorderColor = System.Drawing.Color.Silver;
            stateProperties16.FillColor = System.Drawing.Color.White;
            stateProperties16.ForeColor = System.Drawing.Color.Empty;
            stateProperties16.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.tbDescription.OnIdleState = stateProperties16;
            this.tbDescription.Padding = new System.Windows.Forms.Padding(3, 3, 3, 3);
            this.tbDescription.PasswordChar = '\0';
            this.tbDescription.PlaceholderForeColor = System.Drawing.Color.Silver;
            this.tbDescription.PlaceholderText = "";
            this.tbDescription.ReadOnly = false;
            this.tbDescription.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.tbDescription.SelectedText = "";
            this.tbDescription.SelectionLength = 0;
            this.tbDescription.SelectionStart = 0;
            this.tbDescription.ShortcutsEnabled = true;
            this.tbDescription.Size = new System.Drawing.Size(690, 196);
            this.tbDescription.Style = Bunifu.UI.WinForms.BunifuTextBox._Style.Bunifu;
            this.tbDescription.TabIndex = 16;
            this.tbDescription.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.tbDescription.TextMarginBottom = 0;
            this.tbDescription.TextMarginLeft = 3;
            this.tbDescription.TextMarginTop = 1;
            this.tbDescription.TextPlaceholder = "";
            this.tbDescription.UseSystemPasswordChar = false;
            this.tbDescription.WordWrap = true;
            // 
            // btCreateProject
            // 
            this.btCreateProject.AllowAnimations = true;
            this.btCreateProject.AllowMouseEffects = true;
            this.btCreateProject.AllowToggling = false;
            this.btCreateProject.Anchor = System.Windows.Forms.AnchorStyles.Right;
            this.btCreateProject.AnimationSpeed = 200;
            this.btCreateProject.AutoGenerateColors = false;
            this.btCreateProject.AutoRoundBorders = false;
            this.btCreateProject.AutoSizeLeftIcon = true;
            this.btCreateProject.AutoSizeRightIcon = true;
            this.btCreateProject.BackColor = System.Drawing.Color.Transparent;
            this.btCreateProject.BackColor1 = System.Drawing.Color.DodgerBlue;
            this.btCreateProject.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btCreateProject.BackgroundImage")));
            this.btCreateProject.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton2.BorderStyles.Solid;
            this.btCreateProject.ButtonText = "New";
            this.btCreateProject.ButtonTextMarginLeft = 0;
            this.btCreateProject.ColorContrastOnClick = 45;
            this.btCreateProject.ColorContrastOnHover = 45;
            this.btCreateProject.Cursor = System.Windows.Forms.Cursors.Default;
            borderEdges1.BottomLeft = true;
            borderEdges1.BottomRight = true;
            borderEdges1.TopLeft = true;
            borderEdges1.TopRight = true;
            this.btCreateProject.CustomizableEdges = borderEdges1;
            this.btCreateProject.DialogResult = System.Windows.Forms.DialogResult.None;
            this.btCreateProject.DisabledBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(191)))), ((int)(((byte)(191)))), ((int)(((byte)(191)))));
            this.btCreateProject.DisabledFillColor = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(204)))), ((int)(((byte)(204)))));
            this.btCreateProject.DisabledForecolor = System.Drawing.Color.FromArgb(((int)(((byte)(168)))), ((int)(((byte)(160)))), ((int)(((byte)(168)))));
            this.btCreateProject.FocusState = Bunifu.UI.WinForms.BunifuButton.BunifuButton2.ButtonStates.Pressed;
            this.btCreateProject.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold);
            this.btCreateProject.ForeColor = System.Drawing.Color.White;
            this.btCreateProject.IconLeftAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btCreateProject.IconLeftCursor = System.Windows.Forms.Cursors.Default;
            this.btCreateProject.IconLeftPadding = new System.Windows.Forms.Padding(11, 3, 3, 3);
            this.btCreateProject.IconMarginLeft = 11;
            this.btCreateProject.IconPadding = 10;
            this.btCreateProject.IconRightAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btCreateProject.IconRightCursor = System.Windows.Forms.Cursors.Default;
            this.btCreateProject.IconRightPadding = new System.Windows.Forms.Padding(3, 3, 7, 3);
            this.btCreateProject.IconSize = 25;
            this.btCreateProject.IdleBorderColor = System.Drawing.Color.DodgerBlue;
            this.btCreateProject.IdleBorderRadius = 40;
            this.btCreateProject.IdleBorderThickness = 1;
            this.btCreateProject.IdleFillColor = System.Drawing.Color.DodgerBlue;
            this.btCreateProject.IdleIconLeftImage = null;
            this.btCreateProject.IdleIconRightImage = null;
            this.btCreateProject.IndicateFocus = false;
            this.btCreateProject.Location = new System.Drawing.Point(142, 381);
            this.btCreateProject.Margin = new System.Windows.Forms.Padding(10, 10, 10, 10);
            this.btCreateProject.Name = "btCreateProject";
            this.btCreateProject.OnDisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(191)))), ((int)(((byte)(191)))), ((int)(((byte)(191)))));
            this.btCreateProject.OnDisabledState.BorderRadius = 40;
            this.btCreateProject.OnDisabledState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton2.BorderStyles.Solid;
            this.btCreateProject.OnDisabledState.BorderThickness = 1;
            this.btCreateProject.OnDisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(204)))), ((int)(((byte)(204)))));
            this.btCreateProject.OnDisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(168)))), ((int)(((byte)(160)))), ((int)(((byte)(168)))));
            this.btCreateProject.OnDisabledState.IconLeftImage = null;
            this.btCreateProject.OnDisabledState.IconRightImage = null;
            this.btCreateProject.onHoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(105)))), ((int)(((byte)(181)))), ((int)(((byte)(255)))));
            this.btCreateProject.onHoverState.BorderRadius = 40;
            this.btCreateProject.onHoverState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton2.BorderStyles.Solid;
            this.btCreateProject.onHoverState.BorderThickness = 1;
            this.btCreateProject.onHoverState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(105)))), ((int)(((byte)(181)))), ((int)(((byte)(255)))));
            this.btCreateProject.onHoverState.ForeColor = System.Drawing.Color.White;
            this.btCreateProject.onHoverState.IconLeftImage = null;
            this.btCreateProject.onHoverState.IconRightImage = null;
            this.btCreateProject.OnIdleState.BorderColor = System.Drawing.Color.DodgerBlue;
            this.btCreateProject.OnIdleState.BorderRadius = 40;
            this.btCreateProject.OnIdleState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton2.BorderStyles.Solid;
            this.btCreateProject.OnIdleState.BorderThickness = 1;
            this.btCreateProject.OnIdleState.FillColor = System.Drawing.Color.DodgerBlue;
            this.btCreateProject.OnIdleState.ForeColor = System.Drawing.Color.White;
            this.btCreateProject.OnIdleState.IconLeftImage = null;
            this.btCreateProject.OnIdleState.IconRightImage = null;
            this.btCreateProject.OnPressedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(96)))), ((int)(((byte)(144)))));
            this.btCreateProject.OnPressedState.BorderRadius = 40;
            this.btCreateProject.OnPressedState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton2.BorderStyles.Solid;
            this.btCreateProject.OnPressedState.BorderThickness = 1;
            this.btCreateProject.OnPressedState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(96)))), ((int)(((byte)(144)))));
            this.btCreateProject.OnPressedState.ForeColor = System.Drawing.Color.White;
            this.btCreateProject.OnPressedState.IconLeftImage = null;
            this.btCreateProject.OnPressedState.IconRightImage = null;
            this.btCreateProject.Size = new System.Drawing.Size(109, 38);
            this.btCreateProject.TabIndex = 19;
            this.btCreateProject.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.btCreateProject.TextAlignment = System.Windows.Forms.HorizontalAlignment.Center;
            this.btCreateProject.TextMarginLeft = 0;
            this.btCreateProject.TextPadding = new System.Windows.Forms.Padding(0);
            this.btCreateProject.UseDefaultRadiusAndThickness = true;
            this.btCreateProject.Click += new System.EventHandler(this.btCreateProject_Click);
            // 
            // flowLayoutPanel1
            // 
            this.flowLayoutPanel1.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.flowLayoutPanel1.Controls.Add(this.btnUpdate);
            this.flowLayoutPanel1.Controls.Add(this.btCancel);
            this.flowLayoutPanel1.Location = new System.Drawing.Point(264, 372);
            this.flowLayoutPanel1.Name = "flowLayoutPanel1";
            this.flowLayoutPanel1.Size = new System.Drawing.Size(252, 57);
            this.flowLayoutPanel1.TabIndex = 31;
            // 
            // btnUpdate
            // 
            this.btnUpdate.AllowAnimations = true;
            this.btnUpdate.AllowMouseEffects = true;
            this.btnUpdate.AllowToggling = false;
            this.btnUpdate.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.btnUpdate.AnimationSpeed = 200;
            this.btnUpdate.AutoGenerateColors = false;
            this.btnUpdate.AutoRoundBorders = false;
            this.btnUpdate.AutoSizeLeftIcon = true;
            this.btnUpdate.AutoSizeRightIcon = true;
            this.btnUpdate.BackColor = System.Drawing.Color.Transparent;
            this.btnUpdate.BackColor1 = System.Drawing.Color.DodgerBlue;
            this.btnUpdate.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnUpdate.BackgroundImage")));
            this.btnUpdate.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton2.BorderStyles.Solid;
            this.btnUpdate.ButtonText = "Save";
            this.btnUpdate.ButtonTextMarginLeft = 0;
            this.btnUpdate.ColorContrastOnClick = 45;
            this.btnUpdate.ColorContrastOnHover = 45;
            this.btnUpdate.Cursor = System.Windows.Forms.Cursors.Default;
            borderEdges2.BottomLeft = true;
            borderEdges2.BottomRight = true;
            borderEdges2.TopLeft = true;
            borderEdges2.TopRight = true;
            this.btnUpdate.CustomizableEdges = borderEdges2;
            this.btnUpdate.DialogResult = System.Windows.Forms.DialogResult.None;
            this.btnUpdate.DisabledBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(191)))), ((int)(((byte)(191)))), ((int)(((byte)(191)))));
            this.btnUpdate.DisabledFillColor = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(204)))), ((int)(((byte)(204)))));
            this.btnUpdate.DisabledForecolor = System.Drawing.Color.FromArgb(((int)(((byte)(168)))), ((int)(((byte)(160)))), ((int)(((byte)(168)))));
            this.btnUpdate.FocusState = Bunifu.UI.WinForms.BunifuButton.BunifuButton2.ButtonStates.Pressed;
            this.btnUpdate.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold);
            this.btnUpdate.ForeColor = System.Drawing.Color.White;
            this.btnUpdate.IconLeftAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnUpdate.IconLeftCursor = System.Windows.Forms.Cursors.Default;
            this.btnUpdate.IconLeftPadding = new System.Windows.Forms.Padding(11, 3, 3, 3);
            this.btnUpdate.IconMarginLeft = 11;
            this.btnUpdate.IconPadding = 10;
            this.btnUpdate.IconRightAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnUpdate.IconRightCursor = System.Windows.Forms.Cursors.Default;
            this.btnUpdate.IconRightPadding = new System.Windows.Forms.Padding(3, 3, 7, 3);
            this.btnUpdate.IconSize = 25;
            this.btnUpdate.IdleBorderColor = System.Drawing.Color.DodgerBlue;
            this.btnUpdate.IdleBorderRadius = 40;
            this.btnUpdate.IdleBorderThickness = 1;
            this.btnUpdate.IdleFillColor = System.Drawing.Color.DodgerBlue;
            this.btnUpdate.IdleIconLeftImage = null;
            this.btnUpdate.IdleIconRightImage = null;
            this.btnUpdate.IndicateFocus = false;
            this.btnUpdate.Location = new System.Drawing.Point(10, 10);
            this.btnUpdate.Margin = new System.Windows.Forms.Padding(10, 10, 10, 10);
            this.btnUpdate.Name = "btnUpdate";
            this.btnUpdate.OnDisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(191)))), ((int)(((byte)(191)))), ((int)(((byte)(191)))));
            this.btnUpdate.OnDisabledState.BorderRadius = 40;
            this.btnUpdate.OnDisabledState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton2.BorderStyles.Solid;
            this.btnUpdate.OnDisabledState.BorderThickness = 1;
            this.btnUpdate.OnDisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(204)))), ((int)(((byte)(204)))));
            this.btnUpdate.OnDisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(168)))), ((int)(((byte)(160)))), ((int)(((byte)(168)))));
            this.btnUpdate.OnDisabledState.IconLeftImage = null;
            this.btnUpdate.OnDisabledState.IconRightImage = null;
            this.btnUpdate.onHoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(105)))), ((int)(((byte)(181)))), ((int)(((byte)(255)))));
            this.btnUpdate.onHoverState.BorderRadius = 40;
            this.btnUpdate.onHoverState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton2.BorderStyles.Solid;
            this.btnUpdate.onHoverState.BorderThickness = 1;
            this.btnUpdate.onHoverState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(105)))), ((int)(((byte)(181)))), ((int)(((byte)(255)))));
            this.btnUpdate.onHoverState.ForeColor = System.Drawing.Color.White;
            this.btnUpdate.onHoverState.IconLeftImage = null;
            this.btnUpdate.onHoverState.IconRightImage = null;
            this.btnUpdate.OnIdleState.BorderColor = System.Drawing.Color.DodgerBlue;
            this.btnUpdate.OnIdleState.BorderRadius = 40;
            this.btnUpdate.OnIdleState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton2.BorderStyles.Solid;
            this.btnUpdate.OnIdleState.BorderThickness = 1;
            this.btnUpdate.OnIdleState.FillColor = System.Drawing.Color.DodgerBlue;
            this.btnUpdate.OnIdleState.ForeColor = System.Drawing.Color.White;
            this.btnUpdate.OnIdleState.IconLeftImage = null;
            this.btnUpdate.OnIdleState.IconRightImage = null;
            this.btnUpdate.OnPressedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(96)))), ((int)(((byte)(144)))));
            this.btnUpdate.OnPressedState.BorderRadius = 40;
            this.btnUpdate.OnPressedState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton2.BorderStyles.Solid;
            this.btnUpdate.OnPressedState.BorderThickness = 1;
            this.btnUpdate.OnPressedState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(96)))), ((int)(((byte)(144)))));
            this.btnUpdate.OnPressedState.ForeColor = System.Drawing.Color.White;
            this.btnUpdate.OnPressedState.IconLeftImage = null;
            this.btnUpdate.OnPressedState.IconRightImage = null;
            this.btnUpdate.Size = new System.Drawing.Size(109, 38);
            this.btnUpdate.TabIndex = 19;
            this.btnUpdate.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.btnUpdate.TextAlignment = System.Windows.Forms.HorizontalAlignment.Center;
            this.btnUpdate.TextMarginLeft = 0;
            this.btnUpdate.TextPadding = new System.Windows.Forms.Padding(0);
            this.btnUpdate.UseDefaultRadiusAndThickness = true;
            this.btnUpdate.Click += new System.EventHandler(this.btnSave_Click);
            // 
            // btCancel
            // 
            this.btCancel.AllowAnimations = true;
            this.btCancel.AllowMouseEffects = true;
            this.btCancel.AllowToggling = false;
            this.btCancel.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.btCancel.AnimationSpeed = 200;
            this.btCancel.AutoGenerateColors = false;
            this.btCancel.AutoRoundBorders = false;
            this.btCancel.AutoSizeLeftIcon = true;
            this.btCancel.AutoSizeRightIcon = true;
            this.btCancel.BackColor = System.Drawing.Color.Transparent;
            this.btCancel.BackColor1 = System.Drawing.Color.Gainsboro;
            this.btCancel.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btCancel.BackgroundImage")));
            this.btCancel.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton2.BorderStyles.Solid;
            this.btCancel.ButtonText = "Cancel";
            this.btCancel.ButtonTextMarginLeft = 0;
            this.btCancel.ColorContrastOnClick = 45;
            this.btCancel.ColorContrastOnHover = 45;
            this.btCancel.Cursor = System.Windows.Forms.Cursors.Default;
            borderEdges3.BottomLeft = true;
            borderEdges3.BottomRight = true;
            borderEdges3.TopLeft = true;
            borderEdges3.TopRight = true;
            this.btCancel.CustomizableEdges = borderEdges3;
            this.btCancel.DialogResult = System.Windows.Forms.DialogResult.None;
            this.btCancel.DisabledBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(191)))), ((int)(((byte)(191)))), ((int)(((byte)(191)))));
            this.btCancel.DisabledFillColor = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(204)))), ((int)(((byte)(204)))));
            this.btCancel.DisabledForecolor = System.Drawing.Color.FromArgb(((int)(((byte)(168)))), ((int)(((byte)(160)))), ((int)(((byte)(168)))));
            this.btCancel.FocusState = Bunifu.UI.WinForms.BunifuButton.BunifuButton2.ButtonStates.Pressed;
            this.btCancel.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btCancel.ForeColor = System.Drawing.Color.DodgerBlue;
            this.btCancel.IconLeftAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btCancel.IconLeftCursor = System.Windows.Forms.Cursors.Default;
            this.btCancel.IconLeftPadding = new System.Windows.Forms.Padding(11, 3, 3, 3);
            this.btCancel.IconMarginLeft = 11;
            this.btCancel.IconPadding = 10;
            this.btCancel.IconRightAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btCancel.IconRightCursor = System.Windows.Forms.Cursors.Default;
            this.btCancel.IconRightPadding = new System.Windows.Forms.Padding(3, 3, 7, 3);
            this.btCancel.IconSize = 25;
            this.btCancel.IdleBorderColor = System.Drawing.Color.Gainsboro;
            this.btCancel.IdleBorderRadius = 40;
            this.btCancel.IdleBorderThickness = 1;
            this.btCancel.IdleFillColor = System.Drawing.Color.Gainsboro;
            this.btCancel.IdleIconLeftImage = null;
            this.btCancel.IdleIconRightImage = null;
            this.btCancel.IndicateFocus = false;
            this.btCancel.Location = new System.Drawing.Point(135, 10);
            this.btCancel.Margin = new System.Windows.Forms.Padding(6, 4, 6, 4);
            this.btCancel.Name = "btCancel";
            this.btCancel.OnDisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(191)))), ((int)(((byte)(191)))), ((int)(((byte)(191)))));
            this.btCancel.OnDisabledState.BorderRadius = 40;
            this.btCancel.OnDisabledState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton2.BorderStyles.Solid;
            this.btCancel.OnDisabledState.BorderThickness = 1;
            this.btCancel.OnDisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(204)))), ((int)(((byte)(204)))));
            this.btCancel.OnDisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(168)))), ((int)(((byte)(160)))), ((int)(((byte)(168)))));
            this.btCancel.OnDisabledState.IconLeftImage = null;
            this.btCancel.OnDisabledState.IconRightImage = null;
            this.btCancel.onHoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(105)))), ((int)(((byte)(181)))), ((int)(((byte)(255)))));
            this.btCancel.onHoverState.BorderRadius = 40;
            this.btCancel.onHoverState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton2.BorderStyles.Solid;
            this.btCancel.onHoverState.BorderThickness = 1;
            this.btCancel.onHoverState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(105)))), ((int)(((byte)(181)))), ((int)(((byte)(255)))));
            this.btCancel.onHoverState.ForeColor = System.Drawing.Color.White;
            this.btCancel.onHoverState.IconLeftImage = null;
            this.btCancel.onHoverState.IconRightImage = null;
            this.btCancel.OnIdleState.BorderColor = System.Drawing.Color.Gainsboro;
            this.btCancel.OnIdleState.BorderRadius = 40;
            this.btCancel.OnIdleState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton2.BorderStyles.Solid;
            this.btCancel.OnIdleState.BorderThickness = 1;
            this.btCancel.OnIdleState.FillColor = System.Drawing.Color.Gainsboro;
            this.btCancel.OnIdleState.ForeColor = System.Drawing.Color.DodgerBlue;
            this.btCancel.OnIdleState.IconLeftImage = null;
            this.btCancel.OnIdleState.IconRightImage = null;
            this.btCancel.OnPressedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(96)))), ((int)(((byte)(144)))));
            this.btCancel.OnPressedState.BorderRadius = 40;
            this.btCancel.OnPressedState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton2.BorderStyles.Solid;
            this.btCancel.OnPressedState.BorderThickness = 1;
            this.btCancel.OnPressedState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(96)))), ((int)(((byte)(144)))));
            this.btCancel.OnPressedState.ForeColor = System.Drawing.Color.White;
            this.btCancel.OnPressedState.IconLeftImage = null;
            this.btCancel.OnPressedState.IconRightImage = null;
            this.btCancel.Size = new System.Drawing.Size(109, 38);
            this.btCancel.TabIndex = 11;
            this.btCancel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.btCancel.TextAlignment = System.Windows.Forms.HorizontalAlignment.Center;
            this.btCancel.TextMarginLeft = 0;
            this.btCancel.TextPadding = new System.Windows.Forms.Padding(0);
            this.btCancel.UseDefaultRadiusAndThickness = true;
            // 
            // lbProjects
            // 
            this.lbProjects._BackColor = System.Drawing.Color.Empty;
            this.lbProjects._TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.lbProjects.AutoSize = true;
            this.lbProjects.Dock = System.Windows.Forms.DockStyle.Top;
            this.lbProjects.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbProjects.Location = new System.Drawing.Point(0, 0);
            this.lbProjects.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbProjects.Name = "lbProjects";
            this.lbProjects.Padding = new System.Windows.Forms.Padding(0, 6, 0, 6);
            this.lbProjects.Size = new System.Drawing.Size(234, 41);
            this.lbProjects.TabIndex = 3;
            this.lbProjects.Text = "Project Priority List";
            // 
            // roundedLabel1
            // 
            this.roundedLabel1._BackColor = System.Drawing.Color.Empty;
            this.roundedLabel1._TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.roundedLabel1.AutoSize = true;
            this.roundedLabel1.Dock = System.Windows.Forms.DockStyle.Top;
            this.roundedLabel1.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.roundedLabel1.Location = new System.Drawing.Point(0, 0);
            this.roundedLabel1.Name = "roundedLabel1";
            this.roundedLabel1.Padding = new System.Windows.Forms.Padding(0, 5, 0, 5);
            this.roundedLabel1.Size = new System.Drawing.Size(182, 34);
            this.roundedLabel1.TabIndex = 36;
            this.roundedLabel1.Text = "Project Priority List";
            // 
            // CtrlPanelProjectPriorityNew
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.Controls.Add(this.splitContainer1);
            this.DoubleBuffered = true;
            this.Name = "CtrlPanelProjectPriorityNew";
            this.Size = new System.Drawing.Size(1535, 899);
            this.Load += new System.EventHandler(this.CtrlPanelProjectPriorityNew_Load);
            this.splitContainer1.Panel1.ResumeLayout(false);
            this.splitContainer1.Panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer1)).EndInit();
            this.splitContainer1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgvItems)).EndInit();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.tableLayoutPanel1.ResumeLayout(false);
            this.tableLayoutPanel1.PerformLayout();
            this.flowLayoutPanel1.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.SplitContainer splitContainer1;
        private CustomControls.RoundedLabel lbProjects;
        private Bunifu.UI.WinForms.BunifuTextBox tbSearch;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel1;
        private Bunifu.Framework.UI.BunifuCustomLabel bunifuCustomLabel5;
        private Bunifu.Framework.UI.BunifuCustomLabel bunifuCustomLabel1;
        private Bunifu.UI.WinForms.BunifuTextBox tbName;
        private Bunifu.UI.WinForms.BunifuTextBox tbId;
        private Bunifu.Framework.UI.BunifuCustomLabel bunifuCustomLabel6;
        private Bunifu.UI.WinForms.BunifuTextBox tbDescription;
        private Bunifu.UI.WinForms.BunifuButton.BunifuButton2 btCreateProject;
        private Bunifu.UI.WinForms.BunifuDataGridView dgvItems;
        private Bunifu.UI.WinForms.BunifuButton.BunifuButton2 btnUpdate;
        private System.Windows.Forms.FlowLayoutPanel flowLayoutPanel1;
        private Bunifu.UI.WinForms.BunifuButton.BunifuButton2 btCancel;
        private CustomControls.RoundedLabel roundedLabel1;
    }
}
