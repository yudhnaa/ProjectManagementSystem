﻿namespace PresentationLayer.Controls.SideBar.Admin
{
    partial class CtrlPanelTaskAdminNew
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle4 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle5 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle6 = new System.Windows.Forms.DataGridViewCellStyle();
            Bunifu.UI.WinForms.BunifuTextBox.StateProperties stateProperties37 = new Bunifu.UI.WinForms.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextBox.StateProperties stateProperties38 = new Bunifu.UI.WinForms.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextBox.StateProperties stateProperties39 = new Bunifu.UI.WinForms.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextBox.StateProperties stateProperties40 = new Bunifu.UI.WinForms.BunifuTextBox.StateProperties();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(CtrlPanelTaskAdminNew));
            Bunifu.UI.WinForms.BunifuTextBox.StateProperties stateProperties21 = new Bunifu.UI.WinForms.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextBox.StateProperties stateProperties22 = new Bunifu.UI.WinForms.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextBox.StateProperties stateProperties23 = new Bunifu.UI.WinForms.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextBox.StateProperties stateProperties24 = new Bunifu.UI.WinForms.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextBox.StateProperties stateProperties25 = new Bunifu.UI.WinForms.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextBox.StateProperties stateProperties26 = new Bunifu.UI.WinForms.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextBox.StateProperties stateProperties27 = new Bunifu.UI.WinForms.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextBox.StateProperties stateProperties28 = new Bunifu.UI.WinForms.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextBox.StateProperties stateProperties29 = new Bunifu.UI.WinForms.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextBox.StateProperties stateProperties30 = new Bunifu.UI.WinForms.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextBox.StateProperties stateProperties31 = new Bunifu.UI.WinForms.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextBox.StateProperties stateProperties32 = new Bunifu.UI.WinForms.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuButton.BunifuButton2.BorderEdges borderEdges4 = new Bunifu.UI.WinForms.BunifuButton.BunifuButton2.BorderEdges();
            Bunifu.UI.WinForms.BunifuTextBox.StateProperties stateProperties33 = new Bunifu.UI.WinForms.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextBox.StateProperties stateProperties34 = new Bunifu.UI.WinForms.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextBox.StateProperties stateProperties35 = new Bunifu.UI.WinForms.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextBox.StateProperties stateProperties36 = new Bunifu.UI.WinForms.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuButton.BunifuButton2.BorderEdges borderEdges5 = new Bunifu.UI.WinForms.BunifuButton.BunifuButton2.BorderEdges();
            Bunifu.UI.WinForms.BunifuButton.BunifuButton2.BorderEdges borderEdges6 = new Bunifu.UI.WinForms.BunifuButton.BunifuButton2.BorderEdges();
            this.splitContainer1 = new System.Windows.Forms.SplitContainer();
            this.dgvItems = new Bunifu.UI.WinForms.BunifuDataGridView();
            this.panel1 = new System.Windows.Forms.Panel();
            this.tbSearch = new Bunifu.UI.WinForms.BunifuTextBox();
            this.roundedLabel1 = new PresentationLayer.CustomControls.RoundedLabel();
            this.tableLayoutPanel1 = new System.Windows.Forms.TableLayoutPanel();
            this.bunifuLabel1 = new Bunifu.UI.WinForms.BunifuLabel();
            this.tbCode = new Bunifu.UI.WinForms.BunifuTextBox();
            this.bunifuLabel9 = new Bunifu.UI.WinForms.BunifuLabel();
            this.tbTitle = new Bunifu.UI.WinForms.BunifuTextBox();
            this.tbDescription = new Bunifu.UI.WinForms.BunifuTextBox();
            this.bunifuLabel5 = new Bunifu.UI.WinForms.BunifuLabel();
            this.cbParentTask = new System.Windows.Forms.ComboBox();
            this.bunifuLabel10 = new Bunifu.UI.WinForms.BunifuLabel();
            this.datepickerStart = new Bunifu.UI.WinForms.BunifuDatePicker();
            this.datepickerEnd = new Bunifu.UI.WinForms.BunifuDatePicker();
            this.bunifuLabel3 = new Bunifu.UI.WinForms.BunifuLabel();
            this.bunifuLabel4 = new Bunifu.UI.WinForms.BunifuLabel();
            this.btCreate = new Bunifu.UI.WinForms.BunifuButton.BunifuButton2();
            this.cbStatus = new Bunifu.UI.WinForms.BunifuDropdown();
            this.bunifuLabel7 = new Bunifu.UI.WinForms.BunifuLabel();
            this.cbPriority = new Bunifu.UI.WinForms.BunifuDropdown();
            this.bunifuLabel6 = new Bunifu.UI.WinForms.BunifuLabel();
            this.cbProject = new System.Windows.Forms.ComboBox();
            this.bunifuLabel11 = new Bunifu.UI.WinForms.BunifuLabel();
            this.tbEstimate = new Bunifu.UI.WinForms.BunifuTextBox();
            this.bunifuLabel2 = new Bunifu.UI.WinForms.BunifuLabel();
            this.bunifuLabel8 = new Bunifu.UI.WinForms.BunifuLabel();
            this.CbUser = new System.Windows.Forms.ComboBox();
            this.flowLayoutPanel1 = new System.Windows.Forms.FlowLayoutPanel();
            this.btnUpdate = new Bunifu.UI.WinForms.BunifuButton.BunifuButton2();
            this.btCancel = new Bunifu.UI.WinForms.BunifuButton.BunifuButton2();
            this.lbProjects = new PresentationLayer.CustomControls.RoundedLabel();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer1)).BeginInit();
            this.splitContainer1.Panel1.SuspendLayout();
            this.splitContainer1.Panel2.SuspendLayout();
            this.splitContainer1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvItems)).BeginInit();
            this.panel1.SuspendLayout();
            this.tableLayoutPanel1.SuspendLayout();
            this.flowLayoutPanel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // splitContainer1
            // 
            this.splitContainer1.BackColor = System.Drawing.Color.White;
            this.splitContainer1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitContainer1.Location = new System.Drawing.Point(0, 0);
            this.splitContainer1.Name = "splitContainer1";
            // 
            // splitContainer1.Panel1
            // 
            this.splitContainer1.Panel1.Controls.Add(this.dgvItems);
            this.splitContainer1.Panel1.Controls.Add(this.panel1);
            this.splitContainer1.Panel1.Cursor = System.Windows.Forms.Cursors.Default;
            this.splitContainer1.Panel1.Padding = new System.Windows.Forms.Padding(10);
            // 
            // splitContainer1.Panel2
            // 
            this.splitContainer1.Panel2.AutoScroll = true;
            this.splitContainer1.Panel2.Controls.Add(this.tableLayoutPanel1);
            this.splitContainer1.Size = new System.Drawing.Size(1485, 931);
            this.splitContainer1.SplitterDistance = 840;
            this.splitContainer1.TabIndex = 0;
            this.splitContainer1.Paint += new System.Windows.Forms.PaintEventHandler(this.splitContainer1_Paint);
            // 
            // dgvItems
            // 
            this.dgvItems.AllowCustomTheming = false;
            dataGridViewCellStyle4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(248)))), ((int)(((byte)(251)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle4.ForeColor = System.Drawing.Color.Black;
            this.dgvItems.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle4;
            this.dgvItems.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgvItems.BackgroundColor = System.Drawing.Color.WhiteSmoke;
            this.dgvItems.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.dgvItems.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.SingleHorizontal;
            this.dgvItems.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle5.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle5.BackColor = System.Drawing.Color.DodgerBlue;
            dataGridViewCellStyle5.Font = new System.Drawing.Font("Segoe UI Semibold", 11.75F, System.Drawing.FontStyle.Bold);
            dataGridViewCellStyle5.ForeColor = System.Drawing.Color.White;
            dataGridViewCellStyle5.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(24)))), ((int)(((byte)(115)))), ((int)(((byte)(204)))));
            dataGridViewCellStyle5.SelectionForeColor = System.Drawing.Color.White;
            dataGridViewCellStyle5.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvItems.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle5;
            this.dgvItems.ColumnHeadersHeight = 40;
            this.dgvItems.CurrentTheme.AlternatingRowsStyle.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(248)))), ((int)(((byte)(251)))), ((int)(((byte)(255)))));
            this.dgvItems.CurrentTheme.AlternatingRowsStyle.Font = new System.Drawing.Font("Segoe UI Semibold", 9.75F, System.Drawing.FontStyle.Bold);
            this.dgvItems.CurrentTheme.AlternatingRowsStyle.ForeColor = System.Drawing.Color.Black;
            this.dgvItems.CurrentTheme.AlternatingRowsStyle.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(210)))), ((int)(((byte)(232)))), ((int)(((byte)(255)))));
            this.dgvItems.CurrentTheme.AlternatingRowsStyle.SelectionForeColor = System.Drawing.Color.Black;
            this.dgvItems.CurrentTheme.BackColor = System.Drawing.Color.White;
            this.dgvItems.CurrentTheme.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(221)))), ((int)(((byte)(238)))), ((int)(((byte)(255)))));
            this.dgvItems.CurrentTheme.HeaderStyle.BackColor = System.Drawing.Color.DodgerBlue;
            this.dgvItems.CurrentTheme.HeaderStyle.Font = new System.Drawing.Font("Segoe UI Semibold", 11.75F, System.Drawing.FontStyle.Bold);
            this.dgvItems.CurrentTheme.HeaderStyle.ForeColor = System.Drawing.Color.White;
            this.dgvItems.CurrentTheme.HeaderStyle.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(24)))), ((int)(((byte)(115)))), ((int)(((byte)(204)))));
            this.dgvItems.CurrentTheme.HeaderStyle.SelectionForeColor = System.Drawing.Color.White;
            this.dgvItems.CurrentTheme.Name = null;
            this.dgvItems.CurrentTheme.RowsStyle.BackColor = System.Drawing.Color.White;
            this.dgvItems.CurrentTheme.RowsStyle.Font = new System.Drawing.Font("Segoe UI Semibold", 9.75F, System.Drawing.FontStyle.Bold);
            this.dgvItems.CurrentTheme.RowsStyle.ForeColor = System.Drawing.Color.Black;
            this.dgvItems.CurrentTheme.RowsStyle.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(210)))), ((int)(((byte)(232)))), ((int)(((byte)(255)))));
            this.dgvItems.CurrentTheme.RowsStyle.SelectionForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle6.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle6.BackColor = System.Drawing.Color.White;
            dataGridViewCellStyle6.Font = new System.Drawing.Font("Segoe UI Semibold", 9.75F, System.Drawing.FontStyle.Bold);
            dataGridViewCellStyle6.ForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle6.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(210)))), ((int)(((byte)(232)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle6.SelectionForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle6.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dgvItems.DefaultCellStyle = dataGridViewCellStyle6;
            this.dgvItems.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dgvItems.EnableHeadersVisualStyles = false;
            this.dgvItems.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(221)))), ((int)(((byte)(238)))), ((int)(((byte)(255)))));
            this.dgvItems.HeaderBackColor = System.Drawing.Color.DodgerBlue;
            this.dgvItems.HeaderBgColor = System.Drawing.Color.Empty;
            this.dgvItems.HeaderForeColor = System.Drawing.Color.White;
            this.dgvItems.Location = new System.Drawing.Point(10, 99);
            this.dgvItems.Name = "dgvItems";
            this.dgvItems.RowHeadersVisible = false;
            this.dgvItems.RowHeadersWidth = 62;
            this.dgvItems.RowTemplate.Height = 40;
            this.dgvItems.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvItems.Size = new System.Drawing.Size(820, 822);
            this.dgvItems.TabIndex = 8;
            this.dgvItems.Theme = Bunifu.UI.WinForms.BunifuDataGridView.PresetThemes.Light;
            this.dgvItems.SelectionChanged += new System.EventHandler(this.dgvItems_SelectionChanged);
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.White;
            this.panel1.Controls.Add(this.tbSearch);
            this.panel1.Controls.Add(this.roundedLabel1);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel1.Location = new System.Drawing.Point(10, 10);
            this.panel1.Name = "panel1";
            this.panel1.Padding = new System.Windows.Forms.Padding(0, 0, 0, 8);
            this.panel1.Size = new System.Drawing.Size(820, 89);
            this.panel1.TabIndex = 7;
            // 
            // tbSearch
            // 
            this.tbSearch.AcceptsReturn = false;
            this.tbSearch.AcceptsTab = false;
            this.tbSearch.AnimationSpeed = 200;
            this.tbSearch.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.None;
            this.tbSearch.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.None;
            this.tbSearch.AutoSizeHeight = true;
            this.tbSearch.BackColor = System.Drawing.Color.Transparent;
            this.tbSearch.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("tbSearch.BackgroundImage")));
            this.tbSearch.BorderColorActive = System.Drawing.Color.DodgerBlue;
            this.tbSearch.BorderColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(204)))), ((int)(((byte)(204)))));
            this.tbSearch.BorderColorHover = System.Drawing.Color.FromArgb(((int)(((byte)(105)))), ((int)(((byte)(181)))), ((int)(((byte)(255)))));
            this.tbSearch.BorderColorIdle = System.Drawing.Color.Silver;
            this.tbSearch.BorderRadius = 25;
            this.tbSearch.BorderThickness = 1;
            this.tbSearch.CharacterCase = Bunifu.UI.WinForms.BunifuTextBox.CharacterCases.Normal;
            this.tbSearch.CharacterCasing = System.Windows.Forms.CharacterCasing.Normal;
            this.tbSearch.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.tbSearch.DefaultFont = new System.Drawing.Font("Segoe UI", 9.25F);
            this.tbSearch.DefaultText = "";
            this.tbSearch.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tbSearch.FillColor = System.Drawing.Color.White;
            this.tbSearch.HideSelection = true;
            this.tbSearch.IconLeft = null;
            this.tbSearch.IconLeftCursor = System.Windows.Forms.Cursors.IBeam;
            this.tbSearch.IconPadding = 10;
            this.tbSearch.IconRight = null;
            this.tbSearch.IconRightCursor = System.Windows.Forms.Cursors.IBeam;
            this.tbSearch.Lines = new string[0];
            this.tbSearch.Location = new System.Drawing.Point(0, 34);
            this.tbSearch.MaxLength = 32767;
            this.tbSearch.MinimumSize = new System.Drawing.Size(1, 1);
            this.tbSearch.Modified = false;
            this.tbSearch.Multiline = false;
            this.tbSearch.Name = "tbSearch";
            stateProperties37.BorderColor = System.Drawing.Color.DodgerBlue;
            stateProperties37.FillColor = System.Drawing.Color.Empty;
            stateProperties37.ForeColor = System.Drawing.Color.Empty;
            stateProperties37.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.tbSearch.OnActiveState = stateProperties37;
            stateProperties38.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(204)))), ((int)(((byte)(204)))));
            stateProperties38.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(240)))), ((int)(((byte)(240)))), ((int)(((byte)(240)))));
            stateProperties38.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            stateProperties38.PlaceholderForeColor = System.Drawing.Color.DarkGray;
            this.tbSearch.OnDisabledState = stateProperties38;
            stateProperties39.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(105)))), ((int)(((byte)(181)))), ((int)(((byte)(255)))));
            stateProperties39.FillColor = System.Drawing.Color.Empty;
            stateProperties39.ForeColor = System.Drawing.Color.Empty;
            stateProperties39.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.tbSearch.OnHoverState = stateProperties39;
            stateProperties40.BorderColor = System.Drawing.Color.Silver;
            stateProperties40.FillColor = System.Drawing.Color.White;
            stateProperties40.ForeColor = System.Drawing.Color.Empty;
            stateProperties40.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.tbSearch.OnIdleState = stateProperties40;
            this.tbSearch.Padding = new System.Windows.Forms.Padding(3);
            this.tbSearch.PasswordChar = '\0';
            this.tbSearch.PlaceholderForeColor = System.Drawing.Color.Silver;
            this.tbSearch.PlaceholderText = "Enter text";
            this.tbSearch.ReadOnly = false;
            this.tbSearch.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.tbSearch.SelectedText = "";
            this.tbSearch.SelectionLength = 0;
            this.tbSearch.SelectionStart = 0;
            this.tbSearch.ShortcutsEnabled = true;
            this.tbSearch.Size = new System.Drawing.Size(820, 47);
            this.tbSearch.Style = Bunifu.UI.WinForms.BunifuTextBox._Style.Bunifu;
            this.tbSearch.TabIndex = 4;
            this.tbSearch.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.tbSearch.TextMarginBottom = 0;
            this.tbSearch.TextMarginLeft = 3;
            this.tbSearch.TextMarginTop = 1;
            this.tbSearch.TextPlaceholder = "Enter text";
            this.tbSearch.UseSystemPasswordChar = false;
            this.tbSearch.WordWrap = true;
            this.tbSearch.KeyDown += new System.Windows.Forms.KeyEventHandler(this.tbSearch_KeyDown);
            // 
            // roundedLabel1
            // 
            this.roundedLabel1._BackColor = System.Drawing.Color.Empty;
            this.roundedLabel1._TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.roundedLabel1.AutoSize = true;
            this.roundedLabel1.Dock = System.Windows.Forms.DockStyle.Top;
            this.roundedLabel1.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.roundedLabel1.Location = new System.Drawing.Point(0, 0);
            this.roundedLabel1.Name = "roundedLabel1";
            this.roundedLabel1.Padding = new System.Windows.Forms.Padding(0, 5, 0, 5);
            this.roundedLabel1.Size = new System.Drawing.Size(91, 34);
            this.roundedLabel1.TabIndex = 36;
            this.roundedLabel1.Text = "Task List";
            // 
            // tableLayoutPanel1
            // 
            this.tableLayoutPanel1.ColumnCount = 3;
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle());
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle());
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 62F));
            this.tableLayoutPanel1.Controls.Add(this.bunifuLabel1, 0, 0);
            this.tableLayoutPanel1.Controls.Add(this.tbCode, 1, 1);
            this.tableLayoutPanel1.Controls.Add(this.bunifuLabel9, 1, 0);
            this.tableLayoutPanel1.Controls.Add(this.tbTitle, 0, 1);
            this.tableLayoutPanel1.Controls.Add(this.tbDescription, 0, 11);
            this.tableLayoutPanel1.Controls.Add(this.bunifuLabel5, 0, 10);
            this.tableLayoutPanel1.Controls.Add(this.cbParentTask, 1, 9);
            this.tableLayoutPanel1.Controls.Add(this.bunifuLabel10, 1, 8);
            this.tableLayoutPanel1.Controls.Add(this.datepickerStart, 0, 3);
            this.tableLayoutPanel1.Controls.Add(this.datepickerEnd, 1, 3);
            this.tableLayoutPanel1.Controls.Add(this.bunifuLabel3, 0, 2);
            this.tableLayoutPanel1.Controls.Add(this.bunifuLabel4, 1, 2);
            this.tableLayoutPanel1.Controls.Add(this.btCreate, 0, 12);
            this.tableLayoutPanel1.Controls.Add(this.cbStatus, 0, 9);
            this.tableLayoutPanel1.Controls.Add(this.bunifuLabel7, 0, 8);
            this.tableLayoutPanel1.Controls.Add(this.cbPriority, 0, 7);
            this.tableLayoutPanel1.Controls.Add(this.bunifuLabel6, 0, 6);
            this.tableLayoutPanel1.Controls.Add(this.cbProject, 1, 7);
            this.tableLayoutPanel1.Controls.Add(this.bunifuLabel11, 1, 6);
            this.tableLayoutPanel1.Controls.Add(this.tbEstimate, 0, 5);
            this.tableLayoutPanel1.Controls.Add(this.bunifuLabel2, 0, 4);
            this.tableLayoutPanel1.Controls.Add(this.bunifuLabel8, 1, 4);
            this.tableLayoutPanel1.Controls.Add(this.CbUser, 1, 5);
            this.tableLayoutPanel1.Controls.Add(this.flowLayoutPanel1, 1, 12);
            this.tableLayoutPanel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel1.ForeColor = System.Drawing.SystemColors.ControlText;
            this.tableLayoutPanel1.Location = new System.Drawing.Point(0, 0);
            this.tableLayoutPanel1.Margin = new System.Windows.Forms.Padding(0);
            this.tableLayoutPanel1.Name = "tableLayoutPanel1";
            this.tableLayoutPanel1.RowCount = 14;
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel1.Size = new System.Drawing.Size(641, 931);
            this.tableLayoutPanel1.TabIndex = 7;
            // 
            // bunifuLabel1
            // 
            this.bunifuLabel1.AllowParentOverrides = false;
            this.bunifuLabel1.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.bunifuLabel1.AutoEllipsis = false;
            this.bunifuLabel1.AutoSize = false;
            this.bunifuLabel1.AutoSizeHeightOnly = true;
            this.bunifuLabel1.Cursor = System.Windows.Forms.Cursors.Default;
            this.bunifuLabel1.CursorType = System.Windows.Forms.Cursors.Default;
            this.bunifuLabel1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuLabel1.Location = new System.Drawing.Point(5, 5);
            this.bunifuLabel1.Margin = new System.Windows.Forms.Padding(5);
            this.bunifuLabel1.Name = "bunifuLabel1";
            this.bunifuLabel1.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.bunifuLabel1.Size = new System.Drawing.Size(251, 20);
            this.bunifuLabel1.TabIndex = 0;
            this.bunifuLabel1.Text = "Task Title";
            this.bunifuLabel1.TextAlignment = System.Drawing.ContentAlignment.TopLeft;
            this.bunifuLabel1.TextFormat = Bunifu.UI.WinForms.BunifuLabel.TextFormattingOptions.Default;
            // 
            // tbCode
            // 
            this.tbCode.AcceptsReturn = false;
            this.tbCode.AcceptsTab = false;
            this.tbCode.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.tbCode.AnimationSpeed = 200;
            this.tbCode.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.None;
            this.tbCode.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.None;
            this.tbCode.AutoSizeHeight = true;
            this.tbCode.BackColor = System.Drawing.Color.Transparent;
            this.tbCode.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("tbCode.BackgroundImage")));
            this.tbCode.BorderColorActive = System.Drawing.Color.DodgerBlue;
            this.tbCode.BorderColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(204)))), ((int)(((byte)(204)))));
            this.tbCode.BorderColorHover = System.Drawing.Color.FromArgb(((int)(((byte)(105)))), ((int)(((byte)(181)))), ((int)(((byte)(255)))));
            this.tbCode.BorderColorIdle = System.Drawing.Color.Silver;
            this.tbCode.BorderRadius = 15;
            this.tbCode.BorderThickness = 1;
            this.tbCode.CharacterCase = Bunifu.UI.WinForms.BunifuTextBox.CharacterCases.Normal;
            this.tbCode.CharacterCasing = System.Windows.Forms.CharacterCasing.Normal;
            this.tbCode.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.tbCode.DefaultFont = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbCode.DefaultText = "";
            this.tbCode.FillColor = System.Drawing.Color.White;
            this.tbCode.HideSelection = true;
            this.tbCode.IconLeft = null;
            this.tbCode.IconLeftCursor = System.Windows.Forms.Cursors.IBeam;
            this.tbCode.IconPadding = 10;
            this.tbCode.IconRight = null;
            this.tbCode.IconRightCursor = System.Windows.Forms.Cursors.IBeam;
            this.tbCode.Lines = new string[0];
            this.tbCode.Location = new System.Drawing.Point(318, 33);
            this.tbCode.MaxLength = 32767;
            this.tbCode.MinimumSize = new System.Drawing.Size(1, 1);
            this.tbCode.Modified = false;
            this.tbCode.Multiline = true;
            this.tbCode.Name = "tbCode";
            stateProperties21.BorderColor = System.Drawing.Color.DodgerBlue;
            stateProperties21.FillColor = System.Drawing.Color.Empty;
            stateProperties21.ForeColor = System.Drawing.Color.Empty;
            stateProperties21.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.tbCode.OnActiveState = stateProperties21;
            stateProperties22.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(204)))), ((int)(((byte)(204)))));
            stateProperties22.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(240)))), ((int)(((byte)(240)))), ((int)(((byte)(240)))));
            stateProperties22.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            stateProperties22.PlaceholderForeColor = System.Drawing.Color.DarkGray;
            this.tbCode.OnDisabledState = stateProperties22;
            stateProperties23.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(105)))), ((int)(((byte)(181)))), ((int)(((byte)(255)))));
            stateProperties23.FillColor = System.Drawing.Color.Empty;
            stateProperties23.ForeColor = System.Drawing.Color.Empty;
            stateProperties23.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.tbCode.OnHoverState = stateProperties23;
            stateProperties24.BorderColor = System.Drawing.Color.Silver;
            stateProperties24.FillColor = System.Drawing.Color.White;
            stateProperties24.ForeColor = System.Drawing.Color.Empty;
            stateProperties24.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.tbCode.OnIdleState = stateProperties24;
            this.tbCode.Padding = new System.Windows.Forms.Padding(3);
            this.tbCode.PasswordChar = '\0';
            this.tbCode.PlaceholderForeColor = System.Drawing.Color.Silver;
            this.tbCode.PlaceholderText = "";
            this.tbCode.ReadOnly = false;
            this.tbCode.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.tbCode.SelectedText = "";
            this.tbCode.SelectionLength = 0;
            this.tbCode.SelectionStart = 0;
            this.tbCode.ShortcutsEnabled = true;
            this.tbCode.Size = new System.Drawing.Size(203, 32);
            this.tbCode.Style = Bunifu.UI.WinForms.BunifuTextBox._Style.Bunifu;
            this.tbCode.TabIndex = 1;
            this.tbCode.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.tbCode.TextMarginBottom = 0;
            this.tbCode.TextMarginLeft = 3;
            this.tbCode.TextMarginTop = 1;
            this.tbCode.TextPlaceholder = "";
            this.tbCode.UseSystemPasswordChar = false;
            this.tbCode.WordWrap = true;
            // 
            // bunifuLabel9
            // 
            this.bunifuLabel9.AllowParentOverrides = false;
            this.bunifuLabel9.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.bunifuLabel9.AutoEllipsis = false;
            this.bunifuLabel9.AutoSize = false;
            this.bunifuLabel9.AutoSizeHeightOnly = true;
            this.bunifuLabel9.CursorType = null;
            this.bunifuLabel9.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuLabel9.Location = new System.Drawing.Point(266, 5);
            this.bunifuLabel9.Margin = new System.Windows.Forms.Padding(5);
            this.bunifuLabel9.Name = "bunifuLabel9";
            this.bunifuLabel9.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.bunifuLabel9.Size = new System.Drawing.Size(251, 20);
            this.bunifuLabel9.TabIndex = 0;
            this.bunifuLabel9.Text = "Code";
            this.bunifuLabel9.TextAlignment = System.Drawing.ContentAlignment.TopLeft;
            this.bunifuLabel9.TextFormat = Bunifu.UI.WinForms.BunifuLabel.TextFormattingOptions.Default;
            // 
            // tbTitle
            // 
            this.tbTitle.AcceptsReturn = false;
            this.tbTitle.AcceptsTab = false;
            this.tbTitle.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.tbTitle.AnimationSpeed = 200;
            this.tbTitle.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.None;
            this.tbTitle.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.None;
            this.tbTitle.AutoSizeHeight = true;
            this.tbTitle.BackColor = System.Drawing.Color.Transparent;
            this.tbTitle.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("tbTitle.BackgroundImage")));
            this.tbTitle.BorderColorActive = System.Drawing.Color.DodgerBlue;
            this.tbTitle.BorderColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(204)))), ((int)(((byte)(204)))));
            this.tbTitle.BorderColorHover = System.Drawing.Color.FromArgb(((int)(((byte)(105)))), ((int)(((byte)(181)))), ((int)(((byte)(255)))));
            this.tbTitle.BorderColorIdle = System.Drawing.Color.Silver;
            this.tbTitle.BorderRadius = 15;
            this.tbTitle.BorderThickness = 1;
            this.tbTitle.CharacterCase = Bunifu.UI.WinForms.BunifuTextBox.CharacterCases.Normal;
            this.tbTitle.CharacterCasing = System.Windows.Forms.CharacterCasing.Normal;
            this.tbTitle.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.tbTitle.DefaultFont = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbTitle.DefaultText = "";
            this.tbTitle.FillColor = System.Drawing.Color.White;
            this.tbTitle.HideSelection = true;
            this.tbTitle.IconLeft = null;
            this.tbTitle.IconLeftCursor = System.Windows.Forms.Cursors.IBeam;
            this.tbTitle.IconPadding = 10;
            this.tbTitle.IconRight = null;
            this.tbTitle.IconRightCursor = System.Windows.Forms.Cursors.IBeam;
            this.tbTitle.Lines = new string[0];
            this.tbTitle.Location = new System.Drawing.Point(29, 33);
            this.tbTitle.MaxLength = 32767;
            this.tbTitle.MinimumSize = new System.Drawing.Size(1, 1);
            this.tbTitle.Modified = false;
            this.tbTitle.Multiline = true;
            this.tbTitle.Name = "tbTitle";
            stateProperties25.BorderColor = System.Drawing.Color.DodgerBlue;
            stateProperties25.FillColor = System.Drawing.Color.Empty;
            stateProperties25.ForeColor = System.Drawing.Color.Empty;
            stateProperties25.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.tbTitle.OnActiveState = stateProperties25;
            stateProperties26.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(204)))), ((int)(((byte)(204)))));
            stateProperties26.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(240)))), ((int)(((byte)(240)))), ((int)(((byte)(240)))));
            stateProperties26.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            stateProperties26.PlaceholderForeColor = System.Drawing.Color.DarkGray;
            this.tbTitle.OnDisabledState = stateProperties26;
            stateProperties27.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(105)))), ((int)(((byte)(181)))), ((int)(((byte)(255)))));
            stateProperties27.FillColor = System.Drawing.Color.Empty;
            stateProperties27.ForeColor = System.Drawing.Color.Empty;
            stateProperties27.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.tbTitle.OnHoverState = stateProperties27;
            stateProperties28.BorderColor = System.Drawing.Color.Silver;
            stateProperties28.FillColor = System.Drawing.Color.White;
            stateProperties28.ForeColor = System.Drawing.Color.Empty;
            stateProperties28.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.tbTitle.OnIdleState = stateProperties28;
            this.tbTitle.Padding = new System.Windows.Forms.Padding(3);
            this.tbTitle.PasswordChar = '\0';
            this.tbTitle.PlaceholderForeColor = System.Drawing.Color.Silver;
            this.tbTitle.PlaceholderText = "";
            this.tbTitle.ReadOnly = false;
            this.tbTitle.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.tbTitle.SelectedText = "";
            this.tbTitle.SelectionLength = 0;
            this.tbTitle.SelectionStart = 0;
            this.tbTitle.ShortcutsEnabled = true;
            this.tbTitle.Size = new System.Drawing.Size(203, 32);
            this.tbTitle.Style = Bunifu.UI.WinForms.BunifuTextBox._Style.Bunifu;
            this.tbTitle.TabIndex = 1;
            this.tbTitle.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.tbTitle.TextMarginBottom = 0;
            this.tbTitle.TextMarginLeft = 3;
            this.tbTitle.TextMarginTop = 1;
            this.tbTitle.TextPlaceholder = "";
            this.tbTitle.UseSystemPasswordChar = false;
            this.tbTitle.WordWrap = true;
            // 
            // tbDescription
            // 
            this.tbDescription.AcceptsReturn = false;
            this.tbDescription.AcceptsTab = false;
            this.tbDescription.AnimationSpeed = 200;
            this.tbDescription.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.None;
            this.tbDescription.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.None;
            this.tbDescription.AutoSizeHeight = true;
            this.tbDescription.BackColor = System.Drawing.Color.Transparent;
            this.tbDescription.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("tbDescription.BackgroundImage")));
            this.tbDescription.BorderColorActive = System.Drawing.Color.DodgerBlue;
            this.tbDescription.BorderColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(204)))), ((int)(((byte)(204)))));
            this.tbDescription.BorderColorHover = System.Drawing.Color.FromArgb(((int)(((byte)(105)))), ((int)(((byte)(181)))), ((int)(((byte)(255)))));
            this.tbDescription.BorderColorIdle = System.Drawing.Color.Silver;
            this.tbDescription.BorderRadius = 15;
            this.tbDescription.BorderThickness = 1;
            this.tbDescription.CharacterCase = Bunifu.UI.WinForms.BunifuTextBox.CharacterCases.Normal;
            this.tbDescription.CharacterCasing = System.Windows.Forms.CharacterCasing.Normal;
            this.tableLayoutPanel1.SetColumnSpan(this.tbDescription, 2);
            this.tbDescription.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.tbDescription.DefaultFont = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbDescription.DefaultText = "";
            this.tbDescription.Dock = System.Windows.Forms.DockStyle.Left;
            this.tbDescription.FillColor = System.Drawing.Color.White;
            this.tbDescription.HideSelection = true;
            this.tbDescription.IconLeft = null;
            this.tbDescription.IconLeftCursor = System.Windows.Forms.Cursors.IBeam;
            this.tbDescription.IconPadding = 10;
            this.tbDescription.IconRight = null;
            this.tbDescription.IconRightCursor = System.Windows.Forms.Cursors.IBeam;
            this.tbDescription.Lines = new string[0];
            this.tbDescription.Location = new System.Drawing.Point(3, 370);
            this.tbDescription.MaxLength = 32767;
            this.tbDescription.MinimumSize = new System.Drawing.Size(1, 1);
            this.tbDescription.Modified = false;
            this.tbDescription.Multiline = true;
            this.tbDescription.Name = "tbDescription";
            stateProperties29.BorderColor = System.Drawing.Color.DodgerBlue;
            stateProperties29.FillColor = System.Drawing.Color.Empty;
            stateProperties29.ForeColor = System.Drawing.Color.Empty;
            stateProperties29.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.tbDescription.OnActiveState = stateProperties29;
            stateProperties30.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(204)))), ((int)(((byte)(204)))));
            stateProperties30.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(240)))), ((int)(((byte)(240)))), ((int)(((byte)(240)))));
            stateProperties30.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            stateProperties30.PlaceholderForeColor = System.Drawing.Color.DarkGray;
            this.tbDescription.OnDisabledState = stateProperties30;
            stateProperties31.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(105)))), ((int)(((byte)(181)))), ((int)(((byte)(255)))));
            stateProperties31.FillColor = System.Drawing.Color.Empty;
            stateProperties31.ForeColor = System.Drawing.Color.Empty;
            stateProperties31.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.tbDescription.OnHoverState = stateProperties31;
            stateProperties32.BorderColor = System.Drawing.Color.Silver;
            stateProperties32.FillColor = System.Drawing.Color.White;
            stateProperties32.ForeColor = System.Drawing.Color.Empty;
            stateProperties32.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.tbDescription.OnIdleState = stateProperties32;
            this.tbDescription.Padding = new System.Windows.Forms.Padding(3);
            this.tbDescription.PasswordChar = '\0';
            this.tbDescription.PlaceholderForeColor = System.Drawing.Color.Silver;
            this.tbDescription.PlaceholderText = "";
            this.tbDescription.ReadOnly = false;
            this.tbDescription.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.tbDescription.SelectedText = "";
            this.tbDescription.SelectionLength = 0;
            this.tbDescription.SelectionStart = 0;
            this.tbDescription.ShortcutsEnabled = true;
            this.tbDescription.Size = new System.Drawing.Size(573, 162);
            this.tbDescription.Style = Bunifu.UI.WinForms.BunifuTextBox._Style.Bunifu;
            this.tbDescription.TabIndex = 1;
            this.tbDescription.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.tbDescription.TextMarginBottom = 0;
            this.tbDescription.TextMarginLeft = 3;
            this.tbDescription.TextMarginTop = 1;
            this.tbDescription.TextPlaceholder = "";
            this.tbDescription.UseSystemPasswordChar = false;
            this.tbDescription.WordWrap = true;
            // 
            // bunifuLabel5
            // 
            this.bunifuLabel5.AllowParentOverrides = false;
            this.bunifuLabel5.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.bunifuLabel5.AutoEllipsis = false;
            this.bunifuLabel5.AutoSize = false;
            this.bunifuLabel5.AutoSizeHeightOnly = true;
            this.bunifuLabel5.CursorType = null;
            this.bunifuLabel5.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuLabel5.Location = new System.Drawing.Point(5, 342);
            this.bunifuLabel5.Margin = new System.Windows.Forms.Padding(5);
            this.bunifuLabel5.Name = "bunifuLabel5";
            this.bunifuLabel5.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.bunifuLabel5.Size = new System.Drawing.Size(251, 20);
            this.bunifuLabel5.TabIndex = 0;
            this.bunifuLabel5.Text = "Task Description";
            this.bunifuLabel5.TextAlignment = System.Drawing.ContentAlignment.TopLeft;
            this.bunifuLabel5.TextFormat = Bunifu.UI.WinForms.BunifuLabel.TextFormattingOptions.Default;
            // 
            // cbParentTask
            // 
            this.cbParentTask.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.cbParentTask.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cbParentTask.FormattingEnabled = true;
            this.cbParentTask.Location = new System.Drawing.Point(318, 304);
            this.cbParentTask.Name = "cbParentTask";
            this.cbParentTask.Size = new System.Drawing.Size(203, 28);
            this.cbParentTask.TabIndex = 5;
            this.cbParentTask.KeyUp += new System.Windows.Forms.KeyEventHandler(this.cbParentTask_KeyUp);
            // 
            // bunifuLabel10
            // 
            this.bunifuLabel10.AllowParentOverrides = false;
            this.bunifuLabel10.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.bunifuLabel10.AutoEllipsis = false;
            this.bunifuLabel10.AutoSize = false;
            this.bunifuLabel10.AutoSizeHeightOnly = true;
            this.bunifuLabel10.CursorType = null;
            this.bunifuLabel10.Enabled = false;
            this.bunifuLabel10.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuLabel10.Location = new System.Drawing.Point(266, 274);
            this.bunifuLabel10.Margin = new System.Windows.Forms.Padding(5);
            this.bunifuLabel10.Name = "bunifuLabel10";
            this.bunifuLabel10.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.bunifuLabel10.Size = new System.Drawing.Size(251, 20);
            this.bunifuLabel10.TabIndex = 13;
            this.bunifuLabel10.Text = "Parent Task";
            this.bunifuLabel10.TextAlignment = System.Drawing.ContentAlignment.TopLeft;
            this.bunifuLabel10.TextFormat = Bunifu.UI.WinForms.BunifuLabel.TextFormattingOptions.Default;
            // 
            // datepickerStart
            // 
            this.datepickerStart.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.datepickerStart.BackColor = System.Drawing.Color.White;
            this.datepickerStart.BorderColor = System.Drawing.Color.Silver;
            this.datepickerStart.BorderRadius = 0;
            this.datepickerStart.Color = System.Drawing.Color.Silver;
            this.datepickerStart.DateBorderThickness = Bunifu.UI.WinForms.BunifuDatePicker.BorderThickness.Thin;
            this.datepickerStart.DateTextAlign = Bunifu.UI.WinForms.BunifuDatePicker.TextAlign.Left;
            this.datepickerStart.DisabledColor = System.Drawing.Color.Gray;
            this.datepickerStart.DisplayWeekNumbers = false;
            this.datepickerStart.DPHeight = 0;
            this.datepickerStart.DropDownAlign = System.Windows.Forms.LeftRightAlignment.Right;
            this.datepickerStart.FillDatePicker = false;
            this.datepickerStart.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.datepickerStart.ForeColor = System.Drawing.Color.Black;
            this.datepickerStart.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.datepickerStart.Icon = ((System.Drawing.Image)(resources.GetObject("datepickerStart.Icon")));
            this.datepickerStart.IconColor = System.Drawing.Color.Gray;
            this.datepickerStart.IconLocation = Bunifu.UI.WinForms.BunifuDatePicker.Indicator.Right;
            this.datepickerStart.LeftTextMargin = 5;
            this.datepickerStart.Location = new System.Drawing.Point(29, 101);
            this.datepickerStart.MinimumSize = new System.Drawing.Size(4, 32);
            this.datepickerStart.Name = "datepickerStart";
            this.datepickerStart.ShowCheckBox = true;
            this.datepickerStart.Size = new System.Drawing.Size(203, 32);
            this.datepickerStart.TabIndex = 2;
            this.datepickerStart.Value = new System.DateTime(2025, 4, 4, 13, 18, 0, 0);
            // 
            // datepickerEnd
            // 
            this.datepickerEnd.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.datepickerEnd.BackColor = System.Drawing.Color.White;
            this.datepickerEnd.BorderColor = System.Drawing.Color.Silver;
            this.datepickerEnd.BorderRadius = 0;
            this.datepickerEnd.CalendarFont = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.datepickerEnd.Color = System.Drawing.Color.Silver;
            this.datepickerEnd.DateBorderThickness = Bunifu.UI.WinForms.BunifuDatePicker.BorderThickness.Thin;
            this.datepickerEnd.DateTextAlign = Bunifu.UI.WinForms.BunifuDatePicker.TextAlign.Left;
            this.datepickerEnd.DisabledColor = System.Drawing.Color.Gray;
            this.datepickerEnd.DisplayWeekNumbers = false;
            this.datepickerEnd.DPHeight = 0;
            this.datepickerEnd.DropDownAlign = System.Windows.Forms.LeftRightAlignment.Right;
            this.datepickerEnd.FillDatePicker = false;
            this.datepickerEnd.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.datepickerEnd.ForeColor = System.Drawing.Color.Black;
            this.datepickerEnd.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.datepickerEnd.Icon = ((System.Drawing.Image)(resources.GetObject("datepickerEnd.Icon")));
            this.datepickerEnd.IconColor = System.Drawing.Color.Gray;
            this.datepickerEnd.IconLocation = Bunifu.UI.WinForms.BunifuDatePicker.Indicator.Right;
            this.datepickerEnd.LeftTextMargin = 5;
            this.datepickerEnd.Location = new System.Drawing.Point(318, 101);
            this.datepickerEnd.MinimumSize = new System.Drawing.Size(4, 32);
            this.datepickerEnd.Name = "datepickerEnd";
            this.datepickerEnd.Size = new System.Drawing.Size(203, 32);
            this.datepickerEnd.TabIndex = 3;
            this.datepickerEnd.Value = new System.DateTime(2025, 4, 4, 13, 19, 0, 0);
            // 
            // bunifuLabel3
            // 
            this.bunifuLabel3.AllowParentOverrides = false;
            this.bunifuLabel3.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.bunifuLabel3.AutoEllipsis = false;
            this.bunifuLabel3.AutoSize = false;
            this.bunifuLabel3.AutoSizeHeightOnly = true;
            this.bunifuLabel3.CursorType = null;
            this.bunifuLabel3.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuLabel3.Location = new System.Drawing.Point(5, 73);
            this.bunifuLabel3.Margin = new System.Windows.Forms.Padding(5);
            this.bunifuLabel3.Name = "bunifuLabel3";
            this.bunifuLabel3.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.bunifuLabel3.Size = new System.Drawing.Size(251, 20);
            this.bunifuLabel3.TabIndex = 0;
            this.bunifuLabel3.Text = "Task Start Date";
            this.bunifuLabel3.TextAlignment = System.Drawing.ContentAlignment.TopLeft;
            this.bunifuLabel3.TextFormat = Bunifu.UI.WinForms.BunifuLabel.TextFormattingOptions.Default;
            // 
            // bunifuLabel4
            // 
            this.bunifuLabel4.AllowParentOverrides = false;
            this.bunifuLabel4.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.bunifuLabel4.AutoEllipsis = false;
            this.bunifuLabel4.AutoSize = false;
            this.bunifuLabel4.AutoSizeHeightOnly = true;
            this.bunifuLabel4.CursorType = null;
            this.bunifuLabel4.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuLabel4.Location = new System.Drawing.Point(266, 73);
            this.bunifuLabel4.Margin = new System.Windows.Forms.Padding(5);
            this.bunifuLabel4.Name = "bunifuLabel4";
            this.bunifuLabel4.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.bunifuLabel4.Size = new System.Drawing.Size(251, 20);
            this.bunifuLabel4.TabIndex = 0;
            this.bunifuLabel4.Text = "Task End Date";
            this.bunifuLabel4.TextAlignment = System.Drawing.ContentAlignment.TopLeft;
            this.bunifuLabel4.TextFormat = Bunifu.UI.WinForms.BunifuLabel.TextFormattingOptions.Default;
            // 
            // btCreate
            // 
            this.btCreate.AllowAnimations = true;
            this.btCreate.AllowMouseEffects = true;
            this.btCreate.AllowToggling = false;
            this.btCreate.Anchor = System.Windows.Forms.AnchorStyles.Right;
            this.btCreate.AnimationSpeed = 200;
            this.btCreate.AutoGenerateColors = false;
            this.btCreate.AutoRoundBorders = false;
            this.btCreate.AutoSizeLeftIcon = true;
            this.btCreate.AutoSizeRightIcon = true;
            this.btCreate.BackColor = System.Drawing.Color.Transparent;
            this.btCreate.BackColor1 = System.Drawing.Color.DodgerBlue;
            this.btCreate.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btCreate.BackgroundImage")));
            this.btCreate.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton2.BorderStyles.Solid;
            this.btCreate.ButtonText = "Create";
            this.btCreate.ButtonTextMarginLeft = 0;
            this.btCreate.ColorContrastOnClick = 45;
            this.btCreate.ColorContrastOnHover = 45;
            this.btCreate.Cursor = System.Windows.Forms.Cursors.Default;
            borderEdges4.BottomLeft = true;
            borderEdges4.BottomRight = true;
            borderEdges4.TopLeft = true;
            borderEdges4.TopRight = true;
            this.btCreate.CustomizableEdges = borderEdges4;
            this.btCreate.DialogResult = System.Windows.Forms.DialogResult.None;
            this.btCreate.DisabledBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(191)))), ((int)(((byte)(191)))), ((int)(((byte)(191)))));
            this.btCreate.DisabledFillColor = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(204)))), ((int)(((byte)(204)))));
            this.btCreate.DisabledForecolor = System.Drawing.Color.FromArgb(((int)(((byte)(168)))), ((int)(((byte)(160)))), ((int)(((byte)(168)))));
            this.btCreate.FocusState = Bunifu.UI.WinForms.BunifuButton.BunifuButton2.ButtonStates.Pressed;
            this.btCreate.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold);
            this.btCreate.ForeColor = System.Drawing.Color.White;
            this.btCreate.IconLeftAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btCreate.IconLeftCursor = System.Windows.Forms.Cursors.Default;
            this.btCreate.IconLeftPadding = new System.Windows.Forms.Padding(11, 3, 3, 3);
            this.btCreate.IconMarginLeft = 11;
            this.btCreate.IconPadding = 10;
            this.btCreate.IconRightAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btCreate.IconRightCursor = System.Windows.Forms.Cursors.Default;
            this.btCreate.IconRightPadding = new System.Windows.Forms.Padding(3, 3, 7, 3);
            this.btCreate.IconSize = 25;
            this.btCreate.IdleBorderColor = System.Drawing.Color.DodgerBlue;
            this.btCreate.IdleBorderRadius = 40;
            this.btCreate.IdleBorderThickness = 1;
            this.btCreate.IdleFillColor = System.Drawing.Color.DodgerBlue;
            this.btCreate.IdleIconLeftImage = null;
            this.btCreate.IdleIconRightImage = null;
            this.btCreate.IndicateFocus = false;
            this.btCreate.Location = new System.Drawing.Point(149, 541);
            this.btCreate.Name = "btCreate";
            this.btCreate.OnDisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(191)))), ((int)(((byte)(191)))), ((int)(((byte)(191)))));
            this.btCreate.OnDisabledState.BorderRadius = 40;
            this.btCreate.OnDisabledState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton2.BorderStyles.Solid;
            this.btCreate.OnDisabledState.BorderThickness = 1;
            this.btCreate.OnDisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(204)))), ((int)(((byte)(204)))));
            this.btCreate.OnDisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(168)))), ((int)(((byte)(160)))), ((int)(((byte)(168)))));
            this.btCreate.OnDisabledState.IconLeftImage = null;
            this.btCreate.OnDisabledState.IconRightImage = null;
            this.btCreate.onHoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(105)))), ((int)(((byte)(181)))), ((int)(((byte)(255)))));
            this.btCreate.onHoverState.BorderRadius = 40;
            this.btCreate.onHoverState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton2.BorderStyles.Solid;
            this.btCreate.onHoverState.BorderThickness = 1;
            this.btCreate.onHoverState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(105)))), ((int)(((byte)(181)))), ((int)(((byte)(255)))));
            this.btCreate.onHoverState.ForeColor = System.Drawing.Color.White;
            this.btCreate.onHoverState.IconLeftImage = null;
            this.btCreate.onHoverState.IconRightImage = null;
            this.btCreate.OnIdleState.BorderColor = System.Drawing.Color.DodgerBlue;
            this.btCreate.OnIdleState.BorderRadius = 40;
            this.btCreate.OnIdleState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton2.BorderStyles.Solid;
            this.btCreate.OnIdleState.BorderThickness = 1;
            this.btCreate.OnIdleState.FillColor = System.Drawing.Color.DodgerBlue;
            this.btCreate.OnIdleState.ForeColor = System.Drawing.Color.White;
            this.btCreate.OnIdleState.IconLeftImage = null;
            this.btCreate.OnIdleState.IconRightImage = null;
            this.btCreate.OnPressedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(96)))), ((int)(((byte)(144)))));
            this.btCreate.OnPressedState.BorderRadius = 40;
            this.btCreate.OnPressedState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton2.BorderStyles.Solid;
            this.btCreate.OnPressedState.BorderThickness = 1;
            this.btCreate.OnPressedState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(96)))), ((int)(((byte)(144)))));
            this.btCreate.OnPressedState.ForeColor = System.Drawing.Color.White;
            this.btCreate.OnPressedState.IconLeftImage = null;
            this.btCreate.OnPressedState.IconRightImage = null;
            this.btCreate.Size = new System.Drawing.Size(109, 38);
            this.btCreate.TabIndex = 11;
            this.btCreate.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.btCreate.TextAlignment = System.Windows.Forms.HorizontalAlignment.Center;
            this.btCreate.TextMarginLeft = 0;
            this.btCreate.TextPadding = new System.Windows.Forms.Padding(0);
            this.btCreate.UseDefaultRadiusAndThickness = true;
            this.btCreate.Click += new System.EventHandler(this.btCreate_Click);
            // 
            // cbStatus
            // 
            this.cbStatus.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.cbStatus.BackColor = System.Drawing.Color.Transparent;
            this.cbStatus.BackgroundColor = System.Drawing.Color.White;
            this.cbStatus.BorderColor = System.Drawing.Color.Silver;
            this.cbStatus.BorderRadius = 17;
            this.cbStatus.Color = System.Drawing.Color.Silver;
            this.cbStatus.Direction = Bunifu.UI.WinForms.BunifuDropdown.Directions.Down;
            this.cbStatus.DisabledBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(240)))), ((int)(((byte)(240)))), ((int)(((byte)(240)))));
            this.cbStatus.DisabledBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(204)))), ((int)(((byte)(204)))));
            this.cbStatus.DisabledColor = System.Drawing.Color.FromArgb(((int)(((byte)(240)))), ((int)(((byte)(240)))), ((int)(((byte)(240)))));
            this.cbStatus.DisabledForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            this.cbStatus.DisabledIndicatorColor = System.Drawing.Color.DarkGray;
            this.cbStatus.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawFixed;
            this.cbStatus.DropdownBorderThickness = Bunifu.UI.WinForms.BunifuDropdown.BorderThickness.Thin;
            this.cbStatus.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbStatus.DropDownTextAlign = Bunifu.UI.WinForms.BunifuDropdown.TextAlign.Left;
            this.cbStatus.FillDropDown = true;
            this.cbStatus.FillIndicator = false;
            this.cbStatus.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.cbStatus.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.cbStatus.ForeColor = System.Drawing.Color.Black;
            this.cbStatus.FormattingEnabled = true;
            this.cbStatus.Icon = null;
            this.cbStatus.IndicatorAlignment = Bunifu.UI.WinForms.BunifuDropdown.Indicator.Right;
            this.cbStatus.IndicatorColor = System.Drawing.Color.DarkGray;
            this.cbStatus.IndicatorLocation = Bunifu.UI.WinForms.BunifuDropdown.Indicator.Right;
            this.cbStatus.IndicatorThickness = 2;
            this.cbStatus.IsDropdownOpened = false;
            this.cbStatus.ItemBackColor = System.Drawing.Color.White;
            this.cbStatus.ItemBorderColor = System.Drawing.Color.White;
            this.cbStatus.ItemForeColor = System.Drawing.Color.Black;
            this.cbStatus.ItemHeight = 26;
            this.cbStatus.ItemHighLightColor = System.Drawing.Color.DodgerBlue;
            this.cbStatus.ItemHighLightForeColor = System.Drawing.Color.White;
            this.cbStatus.ItemTopMargin = 3;
            this.cbStatus.Location = new System.Drawing.Point(29, 302);
            this.cbStatus.Name = "cbStatus";
            this.cbStatus.Size = new System.Drawing.Size(203, 32);
            this.cbStatus.TabIndex = 24;
            this.cbStatus.Text = null;
            this.cbStatus.TextAlignment = Bunifu.UI.WinForms.BunifuDropdown.TextAlign.Left;
            this.cbStatus.TextLeftMargin = 5;
            // 
            // bunifuLabel7
            // 
            this.bunifuLabel7.AllowParentOverrides = false;
            this.bunifuLabel7.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.bunifuLabel7.AutoEllipsis = false;
            this.bunifuLabel7.AutoSize = false;
            this.bunifuLabel7.AutoSizeHeightOnly = true;
            this.bunifuLabel7.CursorType = null;
            this.bunifuLabel7.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuLabel7.Location = new System.Drawing.Point(5, 274);
            this.bunifuLabel7.Margin = new System.Windows.Forms.Padding(5);
            this.bunifuLabel7.Name = "bunifuLabel7";
            this.bunifuLabel7.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.bunifuLabel7.Size = new System.Drawing.Size(251, 20);
            this.bunifuLabel7.TabIndex = 0;
            this.bunifuLabel7.Text = "Status";
            this.bunifuLabel7.TextAlignment = System.Drawing.ContentAlignment.TopLeft;
            this.bunifuLabel7.TextFormat = Bunifu.UI.WinForms.BunifuLabel.TextFormattingOptions.Default;
            // 
            // cbPriority
            // 
            this.cbPriority.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.cbPriority.BackColor = System.Drawing.Color.Transparent;
            this.cbPriority.BackgroundColor = System.Drawing.Color.White;
            this.cbPriority.BorderColor = System.Drawing.Color.Silver;
            this.cbPriority.BorderRadius = 17;
            this.cbPriority.Color = System.Drawing.Color.Silver;
            this.cbPriority.Direction = Bunifu.UI.WinForms.BunifuDropdown.Directions.Down;
            this.cbPriority.DisabledBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(240)))), ((int)(((byte)(240)))), ((int)(((byte)(240)))));
            this.cbPriority.DisabledBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(204)))), ((int)(((byte)(204)))));
            this.cbPriority.DisabledColor = System.Drawing.Color.FromArgb(((int)(((byte)(240)))), ((int)(((byte)(240)))), ((int)(((byte)(240)))));
            this.cbPriority.DisabledForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            this.cbPriority.DisabledIndicatorColor = System.Drawing.Color.DarkGray;
            this.cbPriority.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawFixed;
            this.cbPriority.DropdownBorderThickness = Bunifu.UI.WinForms.BunifuDropdown.BorderThickness.Thin;
            this.cbPriority.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbPriority.DropDownTextAlign = Bunifu.UI.WinForms.BunifuDropdown.TextAlign.Left;
            this.cbPriority.FillDropDown = true;
            this.cbPriority.FillIndicator = false;
            this.cbPriority.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.cbPriority.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.cbPriority.ForeColor = System.Drawing.Color.Black;
            this.cbPriority.FormattingEnabled = true;
            this.cbPriority.Icon = null;
            this.cbPriority.IndicatorAlignment = Bunifu.UI.WinForms.BunifuDropdown.Indicator.Right;
            this.cbPriority.IndicatorColor = System.Drawing.Color.DarkGray;
            this.cbPriority.IndicatorLocation = Bunifu.UI.WinForms.BunifuDropdown.Indicator.Right;
            this.cbPriority.IndicatorThickness = 2;
            this.cbPriority.IsDropdownOpened = false;
            this.cbPriority.ItemBackColor = System.Drawing.Color.White;
            this.cbPriority.ItemBorderColor = System.Drawing.Color.White;
            this.cbPriority.ItemForeColor = System.Drawing.Color.Black;
            this.cbPriority.ItemHeight = 26;
            this.cbPriority.ItemHighLightColor = System.Drawing.Color.DodgerBlue;
            this.cbPriority.ItemHighLightForeColor = System.Drawing.Color.White;
            this.cbPriority.ItemTopMargin = 3;
            this.cbPriority.Location = new System.Drawing.Point(29, 234);
            this.cbPriority.Name = "cbPriority";
            this.cbPriority.Size = new System.Drawing.Size(203, 32);
            this.cbPriority.TabIndex = 24;
            this.cbPriority.Text = null;
            this.cbPriority.TextAlignment = Bunifu.UI.WinForms.BunifuDropdown.TextAlign.Left;
            this.cbPriority.TextLeftMargin = 5;
            // 
            // bunifuLabel6
            // 
            this.bunifuLabel6.AllowParentOverrides = false;
            this.bunifuLabel6.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.bunifuLabel6.AutoEllipsis = false;
            this.bunifuLabel6.AutoSize = false;
            this.bunifuLabel6.AutoSizeHeightOnly = true;
            this.bunifuLabel6.CursorType = null;
            this.bunifuLabel6.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuLabel6.Location = new System.Drawing.Point(5, 206);
            this.bunifuLabel6.Margin = new System.Windows.Forms.Padding(5);
            this.bunifuLabel6.Name = "bunifuLabel6";
            this.bunifuLabel6.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.bunifuLabel6.Size = new System.Drawing.Size(251, 20);
            this.bunifuLabel6.TabIndex = 0;
            this.bunifuLabel6.Text = "Priority";
            this.bunifuLabel6.TextAlignment = System.Drawing.ContentAlignment.TopLeft;
            this.bunifuLabel6.TextFormat = Bunifu.UI.WinForms.BunifuLabel.TextFormattingOptions.Default;
            // 
            // cbProject
            // 
            this.cbProject.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.cbProject.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cbProject.FormattingEnabled = true;
            this.cbProject.Location = new System.Drawing.Point(318, 236);
            this.cbProject.Name = "cbProject";
            this.cbProject.Size = new System.Drawing.Size(203, 28);
            this.cbProject.TabIndex = 6;
            this.cbProject.KeyUp += new System.Windows.Forms.KeyEventHandler(this.cbProject_KeyUp);
            // 
            // bunifuLabel11
            // 
            this.bunifuLabel11.AllowParentOverrides = false;
            this.bunifuLabel11.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.bunifuLabel11.AutoEllipsis = false;
            this.bunifuLabel11.AutoSize = false;
            this.bunifuLabel11.AutoSizeHeightOnly = true;
            this.bunifuLabel11.CursorType = null;
            this.bunifuLabel11.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuLabel11.Location = new System.Drawing.Point(266, 206);
            this.bunifuLabel11.Margin = new System.Windows.Forms.Padding(5);
            this.bunifuLabel11.Name = "bunifuLabel11";
            this.bunifuLabel11.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.bunifuLabel11.Size = new System.Drawing.Size(251, 20);
            this.bunifuLabel11.TabIndex = 0;
            this.bunifuLabel11.Text = "Project";
            this.bunifuLabel11.TextAlignment = System.Drawing.ContentAlignment.TopLeft;
            this.bunifuLabel11.TextFormat = Bunifu.UI.WinForms.BunifuLabel.TextFormattingOptions.Default;
            // 
            // tbEstimate
            // 
            this.tbEstimate.AcceptsReturn = false;
            this.tbEstimate.AcceptsTab = false;
            this.tbEstimate.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.tbEstimate.AnimationSpeed = 200;
            this.tbEstimate.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.None;
            this.tbEstimate.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.None;
            this.tbEstimate.AutoSizeHeight = true;
            this.tbEstimate.BackColor = System.Drawing.Color.Transparent;
            this.tbEstimate.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("tbEstimate.BackgroundImage")));
            this.tbEstimate.BorderColorActive = System.Drawing.Color.DodgerBlue;
            this.tbEstimate.BorderColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(204)))), ((int)(((byte)(204)))));
            this.tbEstimate.BorderColorHover = System.Drawing.Color.FromArgb(((int)(((byte)(105)))), ((int)(((byte)(181)))), ((int)(((byte)(255)))));
            this.tbEstimate.BorderColorIdle = System.Drawing.Color.Silver;
            this.tbEstimate.BorderRadius = 15;
            this.tbEstimate.BorderThickness = 1;
            this.tbEstimate.CharacterCase = Bunifu.UI.WinForms.BunifuTextBox.CharacterCases.Normal;
            this.tbEstimate.CharacterCasing = System.Windows.Forms.CharacterCasing.Normal;
            this.tbEstimate.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.tbEstimate.DefaultFont = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbEstimate.DefaultText = "";
            this.tbEstimate.FillColor = System.Drawing.Color.White;
            this.tbEstimate.HideSelection = true;
            this.tbEstimate.IconLeft = null;
            this.tbEstimate.IconLeftCursor = System.Windows.Forms.Cursors.IBeam;
            this.tbEstimate.IconPadding = 10;
            this.tbEstimate.IconRight = null;
            this.tbEstimate.IconRightCursor = System.Windows.Forms.Cursors.IBeam;
            this.tbEstimate.Lines = new string[0];
            this.tbEstimate.Location = new System.Drawing.Point(29, 169);
            this.tbEstimate.MaxLength = 32767;
            this.tbEstimate.MinimumSize = new System.Drawing.Size(1, 1);
            this.tbEstimate.Modified = false;
            this.tbEstimate.Multiline = false;
            this.tbEstimate.Name = "tbEstimate";
            stateProperties33.BorderColor = System.Drawing.Color.DodgerBlue;
            stateProperties33.FillColor = System.Drawing.Color.Empty;
            stateProperties33.ForeColor = System.Drawing.Color.Empty;
            stateProperties33.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.tbEstimate.OnActiveState = stateProperties33;
            stateProperties34.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(204)))), ((int)(((byte)(204)))));
            stateProperties34.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(240)))), ((int)(((byte)(240)))), ((int)(((byte)(240)))));
            stateProperties34.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            stateProperties34.PlaceholderForeColor = System.Drawing.Color.DarkGray;
            this.tbEstimate.OnDisabledState = stateProperties34;
            stateProperties35.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(105)))), ((int)(((byte)(181)))), ((int)(((byte)(255)))));
            stateProperties35.FillColor = System.Drawing.Color.Empty;
            stateProperties35.ForeColor = System.Drawing.Color.Empty;
            stateProperties35.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.tbEstimate.OnHoverState = stateProperties35;
            stateProperties36.BorderColor = System.Drawing.Color.Silver;
            stateProperties36.FillColor = System.Drawing.Color.White;
            stateProperties36.ForeColor = System.Drawing.Color.Empty;
            stateProperties36.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.tbEstimate.OnIdleState = stateProperties36;
            this.tbEstimate.Padding = new System.Windows.Forms.Padding(3);
            this.tbEstimate.PasswordChar = '\0';
            this.tbEstimate.PlaceholderForeColor = System.Drawing.Color.Silver;
            this.tbEstimate.PlaceholderText = "";
            this.tbEstimate.ReadOnly = false;
            this.tbEstimate.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.tbEstimate.SelectedText = "";
            this.tbEstimate.SelectionLength = 0;
            this.tbEstimate.SelectionStart = 0;
            this.tbEstimate.ShortcutsEnabled = true;
            this.tbEstimate.Size = new System.Drawing.Size(203, 29);
            this.tbEstimate.Style = Bunifu.UI.WinForms.BunifuTextBox._Style.Bunifu;
            this.tbEstimate.TabIndex = 1;
            this.tbEstimate.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.tbEstimate.TextMarginBottom = 0;
            this.tbEstimate.TextMarginLeft = 3;
            this.tbEstimate.TextMarginTop = 1;
            this.tbEstimate.TextPlaceholder = "";
            this.tbEstimate.UseSystemPasswordChar = false;
            this.tbEstimate.WordWrap = true;
            // 
            // bunifuLabel2
            // 
            this.bunifuLabel2.AllowParentOverrides = false;
            this.bunifuLabel2.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.bunifuLabel2.AutoEllipsis = false;
            this.bunifuLabel2.AutoSize = false;
            this.bunifuLabel2.AutoSizeHeightOnly = true;
            this.bunifuLabel2.CursorType = null;
            this.bunifuLabel2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuLabel2.Location = new System.Drawing.Point(5, 141);
            this.bunifuLabel2.Margin = new System.Windows.Forms.Padding(5);
            this.bunifuLabel2.Name = "bunifuLabel2";
            this.bunifuLabel2.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.bunifuLabel2.Size = new System.Drawing.Size(251, 20);
            this.bunifuLabel2.TabIndex = 0;
            this.bunifuLabel2.Text = "Estimate Time (Hour)";
            this.bunifuLabel2.TextAlignment = System.Drawing.ContentAlignment.TopLeft;
            this.bunifuLabel2.TextFormat = Bunifu.UI.WinForms.BunifuLabel.TextFormattingOptions.Default;
            // 
            // bunifuLabel8
            // 
            this.bunifuLabel8.AllowParentOverrides = false;
            this.bunifuLabel8.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.bunifuLabel8.AutoEllipsis = false;
            this.bunifuLabel8.AutoSize = false;
            this.bunifuLabel8.AutoSizeHeightOnly = true;
            this.bunifuLabel8.CursorType = null;
            this.bunifuLabel8.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuLabel8.Location = new System.Drawing.Point(266, 141);
            this.bunifuLabel8.Margin = new System.Windows.Forms.Padding(5);
            this.bunifuLabel8.Name = "bunifuLabel8";
            this.bunifuLabel8.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.bunifuLabel8.Size = new System.Drawing.Size(251, 20);
            this.bunifuLabel8.TabIndex = 0;
            this.bunifuLabel8.Text = "Assign To User";
            this.bunifuLabel8.TextAlignment = System.Drawing.ContentAlignment.TopLeft;
            this.bunifuLabel8.TextFormat = Bunifu.UI.WinForms.BunifuLabel.TextFormattingOptions.Default;
            // 
            // CbUser
            // 
            this.CbUser.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.CbUser.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.CbUser.FormattingEnabled = true;
            this.CbUser.Location = new System.Drawing.Point(318, 169);
            this.CbUser.Name = "CbUser";
            this.CbUser.Size = new System.Drawing.Size(203, 28);
            this.CbUser.TabIndex = 5;
            this.CbUser.KeyUp += new System.Windows.Forms.KeyEventHandler(this.CbUser_KeyUp);
            // 
            // flowLayoutPanel1
            // 
            this.flowLayoutPanel1.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.flowLayoutPanel1.Controls.Add(this.btnUpdate);
            this.flowLayoutPanel1.Controls.Add(this.btCancel);
            this.flowLayoutPanel1.Location = new System.Drawing.Point(264, 538);
            this.flowLayoutPanel1.Name = "flowLayoutPanel1";
            this.flowLayoutPanel1.Size = new System.Drawing.Size(252, 44);
            this.flowLayoutPanel1.TabIndex = 29;
            // 
            // btnUpdate
            // 
            this.btnUpdate.AllowAnimations = true;
            this.btnUpdate.AllowMouseEffects = true;
            this.btnUpdate.AllowToggling = false;
            this.btnUpdate.AnimationSpeed = 200;
            this.btnUpdate.AutoGenerateColors = false;
            this.btnUpdate.AutoRoundBorders = false;
            this.btnUpdate.AutoSizeLeftIcon = true;
            this.btnUpdate.AutoSizeRightIcon = true;
            this.btnUpdate.BackColor = System.Drawing.Color.Transparent;
            this.btnUpdate.BackColor1 = System.Drawing.Color.DodgerBlue;
            this.btnUpdate.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnUpdate.BackgroundImage")));
            this.btnUpdate.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton2.BorderStyles.Solid;
            this.btnUpdate.ButtonText = "Save";
            this.btnUpdate.ButtonTextMarginLeft = 0;
            this.btnUpdate.ColorContrastOnClick = 45;
            this.btnUpdate.ColorContrastOnHover = 45;
            this.btnUpdate.Cursor = System.Windows.Forms.Cursors.Default;
            borderEdges5.BottomLeft = true;
            borderEdges5.BottomRight = true;
            borderEdges5.TopLeft = true;
            borderEdges5.TopRight = true;
            this.btnUpdate.CustomizableEdges = borderEdges5;
            this.btnUpdate.DialogResult = System.Windows.Forms.DialogResult.None;
            this.btnUpdate.DisabledBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(191)))), ((int)(((byte)(191)))), ((int)(((byte)(191)))));
            this.btnUpdate.DisabledFillColor = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(204)))), ((int)(((byte)(204)))));
            this.btnUpdate.DisabledForecolor = System.Drawing.Color.FromArgb(((int)(((byte)(168)))), ((int)(((byte)(160)))), ((int)(((byte)(168)))));
            this.btnUpdate.FocusState = Bunifu.UI.WinForms.BunifuButton.BunifuButton2.ButtonStates.Pressed;
            this.btnUpdate.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold);
            this.btnUpdate.ForeColor = System.Drawing.Color.White;
            this.btnUpdate.IconLeftAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnUpdate.IconLeftCursor = System.Windows.Forms.Cursors.Default;
            this.btnUpdate.IconLeftPadding = new System.Windows.Forms.Padding(11, 3, 3, 3);
            this.btnUpdate.IconMarginLeft = 11;
            this.btnUpdate.IconPadding = 10;
            this.btnUpdate.IconRightAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnUpdate.IconRightCursor = System.Windows.Forms.Cursors.Default;
            this.btnUpdate.IconRightPadding = new System.Windows.Forms.Padding(3, 3, 7, 3);
            this.btnUpdate.IconSize = 25;
            this.btnUpdate.IdleBorderColor = System.Drawing.Color.DodgerBlue;
            this.btnUpdate.IdleBorderRadius = 40;
            this.btnUpdate.IdleBorderThickness = 1;
            this.btnUpdate.IdleFillColor = System.Drawing.Color.DodgerBlue;
            this.btnUpdate.IdleIconLeftImage = null;
            this.btnUpdate.IdleIconRightImage = null;
            this.btnUpdate.IndicateFocus = false;
            this.btnUpdate.Location = new System.Drawing.Point(3, 3);
            this.btnUpdate.Name = "btnUpdate";
            this.btnUpdate.OnDisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(191)))), ((int)(((byte)(191)))), ((int)(((byte)(191)))));
            this.btnUpdate.OnDisabledState.BorderRadius = 40;
            this.btnUpdate.OnDisabledState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton2.BorderStyles.Solid;
            this.btnUpdate.OnDisabledState.BorderThickness = 1;
            this.btnUpdate.OnDisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(204)))), ((int)(((byte)(204)))));
            this.btnUpdate.OnDisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(168)))), ((int)(((byte)(160)))), ((int)(((byte)(168)))));
            this.btnUpdate.OnDisabledState.IconLeftImage = null;
            this.btnUpdate.OnDisabledState.IconRightImage = null;
            this.btnUpdate.onHoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(105)))), ((int)(((byte)(181)))), ((int)(((byte)(255)))));
            this.btnUpdate.onHoverState.BorderRadius = 40;
            this.btnUpdate.onHoverState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton2.BorderStyles.Solid;
            this.btnUpdate.onHoverState.BorderThickness = 1;
            this.btnUpdate.onHoverState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(105)))), ((int)(((byte)(181)))), ((int)(((byte)(255)))));
            this.btnUpdate.onHoverState.ForeColor = System.Drawing.Color.White;
            this.btnUpdate.onHoverState.IconLeftImage = null;
            this.btnUpdate.onHoverState.IconRightImage = null;
            this.btnUpdate.OnIdleState.BorderColor = System.Drawing.Color.DodgerBlue;
            this.btnUpdate.OnIdleState.BorderRadius = 40;
            this.btnUpdate.OnIdleState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton2.BorderStyles.Solid;
            this.btnUpdate.OnIdleState.BorderThickness = 1;
            this.btnUpdate.OnIdleState.FillColor = System.Drawing.Color.DodgerBlue;
            this.btnUpdate.OnIdleState.ForeColor = System.Drawing.Color.White;
            this.btnUpdate.OnIdleState.IconLeftImage = null;
            this.btnUpdate.OnIdleState.IconRightImage = null;
            this.btnUpdate.OnPressedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(96)))), ((int)(((byte)(144)))));
            this.btnUpdate.OnPressedState.BorderRadius = 40;
            this.btnUpdate.OnPressedState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton2.BorderStyles.Solid;
            this.btnUpdate.OnPressedState.BorderThickness = 1;
            this.btnUpdate.OnPressedState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(96)))), ((int)(((byte)(144)))));
            this.btnUpdate.OnPressedState.ForeColor = System.Drawing.Color.White;
            this.btnUpdate.OnPressedState.IconLeftImage = null;
            this.btnUpdate.OnPressedState.IconRightImage = null;
            this.btnUpdate.Size = new System.Drawing.Size(109, 38);
            this.btnUpdate.TabIndex = 11;
            this.btnUpdate.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.btnUpdate.TextAlignment = System.Windows.Forms.HorizontalAlignment.Center;
            this.btnUpdate.TextMarginLeft = 0;
            this.btnUpdate.TextPadding = new System.Windows.Forms.Padding(0);
            this.btnUpdate.UseDefaultRadiusAndThickness = true;
            this.btnUpdate.Click += new System.EventHandler(this.btnUpdate_Click);
            // 
            // btCancel
            // 
            this.btCancel.AllowAnimations = true;
            this.btCancel.AllowMouseEffects = true;
            this.btCancel.AllowToggling = false;
            this.btCancel.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.btCancel.AnimationSpeed = 200;
            this.btCancel.AutoGenerateColors = false;
            this.btCancel.AutoRoundBorders = false;
            this.btCancel.AutoSizeLeftIcon = true;
            this.btCancel.AutoSizeRightIcon = true;
            this.btCancel.BackColor = System.Drawing.Color.Transparent;
            this.btCancel.BackColor1 = System.Drawing.Color.Gainsboro;
            this.btCancel.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btCancel.BackgroundImage")));
            this.btCancel.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton2.BorderStyles.Solid;
            this.btCancel.ButtonText = "Cancel";
            this.btCancel.ButtonTextMarginLeft = 0;
            this.btCancel.ColorContrastOnClick = 45;
            this.btCancel.ColorContrastOnHover = 45;
            this.btCancel.Cursor = System.Windows.Forms.Cursors.Default;
            borderEdges6.BottomLeft = true;
            borderEdges6.BottomRight = true;
            borderEdges6.TopLeft = true;
            borderEdges6.TopRight = true;
            this.btCancel.CustomizableEdges = borderEdges6;
            this.btCancel.DialogResult = System.Windows.Forms.DialogResult.None;
            this.btCancel.DisabledBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(191)))), ((int)(((byte)(191)))), ((int)(((byte)(191)))));
            this.btCancel.DisabledFillColor = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(204)))), ((int)(((byte)(204)))));
            this.btCancel.DisabledForecolor = System.Drawing.Color.FromArgb(((int)(((byte)(168)))), ((int)(((byte)(160)))), ((int)(((byte)(168)))));
            this.btCancel.FocusState = Bunifu.UI.WinForms.BunifuButton.BunifuButton2.ButtonStates.Pressed;
            this.btCancel.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btCancel.ForeColor = System.Drawing.Color.DodgerBlue;
            this.btCancel.IconLeftAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btCancel.IconLeftCursor = System.Windows.Forms.Cursors.Default;
            this.btCancel.IconLeftPadding = new System.Windows.Forms.Padding(11, 3, 3, 3);
            this.btCancel.IconMarginLeft = 11;
            this.btCancel.IconPadding = 10;
            this.btCancel.IconRightAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btCancel.IconRightCursor = System.Windows.Forms.Cursors.Default;
            this.btCancel.IconRightPadding = new System.Windows.Forms.Padding(3, 3, 7, 3);
            this.btCancel.IconSize = 25;
            this.btCancel.IdleBorderColor = System.Drawing.Color.Gainsboro;
            this.btCancel.IdleBorderRadius = 40;
            this.btCancel.IdleBorderThickness = 1;
            this.btCancel.IdleFillColor = System.Drawing.Color.Gainsboro;
            this.btCancel.IdleIconLeftImage = null;
            this.btCancel.IdleIconRightImage = null;
            this.btCancel.IndicateFocus = false;
            this.btCancel.Location = new System.Drawing.Point(121, 4);
            this.btCancel.Margin = new System.Windows.Forms.Padding(6, 4, 6, 4);
            this.btCancel.Name = "btCancel";
            this.btCancel.OnDisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(191)))), ((int)(((byte)(191)))), ((int)(((byte)(191)))));
            this.btCancel.OnDisabledState.BorderRadius = 40;
            this.btCancel.OnDisabledState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton2.BorderStyles.Solid;
            this.btCancel.OnDisabledState.BorderThickness = 1;
            this.btCancel.OnDisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(204)))), ((int)(((byte)(204)))));
            this.btCancel.OnDisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(168)))), ((int)(((byte)(160)))), ((int)(((byte)(168)))));
            this.btCancel.OnDisabledState.IconLeftImage = null;
            this.btCancel.OnDisabledState.IconRightImage = null;
            this.btCancel.onHoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(105)))), ((int)(((byte)(181)))), ((int)(((byte)(255)))));
            this.btCancel.onHoverState.BorderRadius = 40;
            this.btCancel.onHoverState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton2.BorderStyles.Solid;
            this.btCancel.onHoverState.BorderThickness = 1;
            this.btCancel.onHoverState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(105)))), ((int)(((byte)(181)))), ((int)(((byte)(255)))));
            this.btCancel.onHoverState.ForeColor = System.Drawing.Color.White;
            this.btCancel.onHoverState.IconLeftImage = null;
            this.btCancel.onHoverState.IconRightImage = null;
            this.btCancel.OnIdleState.BorderColor = System.Drawing.Color.Gainsboro;
            this.btCancel.OnIdleState.BorderRadius = 40;
            this.btCancel.OnIdleState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton2.BorderStyles.Solid;
            this.btCancel.OnIdleState.BorderThickness = 1;
            this.btCancel.OnIdleState.FillColor = System.Drawing.Color.Gainsboro;
            this.btCancel.OnIdleState.ForeColor = System.Drawing.Color.DodgerBlue;
            this.btCancel.OnIdleState.IconLeftImage = null;
            this.btCancel.OnIdleState.IconRightImage = null;
            this.btCancel.OnPressedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(96)))), ((int)(((byte)(144)))));
            this.btCancel.OnPressedState.BorderRadius = 40;
            this.btCancel.OnPressedState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton2.BorderStyles.Solid;
            this.btCancel.OnPressedState.BorderThickness = 1;
            this.btCancel.OnPressedState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(96)))), ((int)(((byte)(144)))));
            this.btCancel.OnPressedState.ForeColor = System.Drawing.Color.White;
            this.btCancel.OnPressedState.IconLeftImage = null;
            this.btCancel.OnPressedState.IconRightImage = null;
            this.btCancel.Size = new System.Drawing.Size(109, 38);
            this.btCancel.TabIndex = 11;
            this.btCancel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.btCancel.TextAlignment = System.Windows.Forms.HorizontalAlignment.Center;
            this.btCancel.TextMarginLeft = 0;
            this.btCancel.TextPadding = new System.Windows.Forms.Padding(0);
            this.btCancel.UseDefaultRadiusAndThickness = true;
            // 
            // lbProjects
            // 
            this.lbProjects._BackColor = System.Drawing.Color.Empty;
            this.lbProjects._TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.lbProjects.AutoSize = true;
            this.lbProjects.Dock = System.Windows.Forms.DockStyle.Top;
            this.lbProjects.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbProjects.Location = new System.Drawing.Point(0, 0);
            this.lbProjects.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbProjects.Name = "lbProjects";
            this.lbProjects.Padding = new System.Windows.Forms.Padding(0, 6, 0, 6);
            this.lbProjects.Size = new System.Drawing.Size(118, 41);
            this.lbProjects.TabIndex = 3;
            this.lbProjects.Text = "Task List";
            // 
            // CtrlPanelTaskAdminNew
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.splitContainer1);
            this.Name = "CtrlPanelTaskAdminNew";
            this.Size = new System.Drawing.Size(1485, 931);
            this.Load += new System.EventHandler(this.CtrlPanelTaskAdminNew_Load);
            this.splitContainer1.Panel1.ResumeLayout(false);
            this.splitContainer1.Panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer1)).EndInit();
            this.splitContainer1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgvItems)).EndInit();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.tableLayoutPanel1.ResumeLayout(false);
            this.flowLayoutPanel1.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.SplitContainer splitContainer1;
        private System.Windows.Forms.Panel panel1;
        private Bunifu.UI.WinForms.BunifuTextBox tbSearch;
        private CustomControls.RoundedLabel lbProjects;
        private Bunifu.UI.WinForms.BunifuDataGridView dgvItems;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel1;
        private Bunifu.UI.WinForms.BunifuLabel bunifuLabel1;
        private Bunifu.UI.WinForms.BunifuDatePicker datepickerEnd;
        private Bunifu.UI.WinForms.BunifuDatePicker datepickerStart;
        private Bunifu.UI.WinForms.BunifuLabel bunifuLabel4;
        private Bunifu.UI.WinForms.BunifuTextBox tbCode;
        private Bunifu.UI.WinForms.BunifuLabel bunifuLabel9;
        private Bunifu.UI.WinForms.BunifuLabel bunifuLabel8;
        private Bunifu.UI.WinForms.BunifuLabel bunifuLabel7;
        private Bunifu.UI.WinForms.BunifuLabel bunifuLabel6;
        private Bunifu.UI.WinForms.BunifuLabel bunifuLabel5;
        private Bunifu.UI.WinForms.BunifuTextBox tbTitle;
        private Bunifu.UI.WinForms.BunifuButton.BunifuButton2 btCreate;
        private Bunifu.UI.WinForms.BunifuLabel bunifuLabel10;
        private Bunifu.UI.WinForms.BunifuLabel bunifuLabel11;
        private Bunifu.UI.WinForms.BunifuLabel bunifuLabel2;
        private Bunifu.UI.WinForms.BunifuTextBox tbEstimate;
        private Bunifu.UI.WinForms.BunifuLabel bunifuLabel3;
        private Bunifu.UI.WinForms.BunifuTextBox tbDescription;
        private Bunifu.UI.WinForms.BunifuButton.BunifuButton2 btnUpdate;
        private Bunifu.UI.WinForms.BunifuDropdown cbStatus;
        private Bunifu.UI.WinForms.BunifuDropdown cbPriority;
        private System.Windows.Forms.ComboBox cbParentTask;
        private System.Windows.Forms.ComboBox cbProject;
        private System.Windows.Forms.ComboBox CbUser;
        private System.Windows.Forms.FlowLayoutPanel flowLayoutPanel1;
        private Bunifu.UI.WinForms.BunifuButton.BunifuButton2 btCancel;
        private CustomControls.RoundedLabel roundedLabel1;
    }
}
