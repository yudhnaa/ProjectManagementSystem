# BunifuUiCrack
Bunifu UI Cracked (First non-virus version lol...)<br>
You can use this with the 7.2.0 version of the Bunifu UI Library.<br>
(Or, you can use this with any version with Bunifu UI that **uses Bunifu.Licensing 6.0.4**)<br>
<br>
# .NET Framework
**This method is for .NET Framework**<br>
1. Go to your project's folder (On Windows: C:\Users\yourusername\source\repo\ProjectName)
2. Find the packages folder (If you cant find it go one folder down it should be in the solution's folder)
3. Find Bunifu.Licensing.6.0.4
4. **Overwrite the net45 folder with the one from this repo**
5. Done! Enjoy

# .NET Core
**This method is for .NET Core**<br>
1. Go to your bunifu licensing nuget package folder (`C:\Users\yourusername\.nuget\packages\bunifu.licensing\6.0.4\lib`) 
2. Download net8.0-windows7.0 folder from this repo
3. Overwrite the folder.
4. Done! Enjoy


If you have problems, you can [create an issue](https://github.com/t0int1337/BunifuUiCrack/issues/new). 
### Star the repo ⭐

